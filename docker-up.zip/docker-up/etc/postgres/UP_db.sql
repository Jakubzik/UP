--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.13
-- Dumped by pg_dump version 9.1.13
-- Started on 2016-06-27 20:20:24 CEST

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 2815 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- TOC entry 212 (class 3079 OID 11693)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- TOC entry 2817 (class 0 OID 0)
-- Dependencies: 212
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

--
-- TOC entry 224 (class 1255 OID 219122)
-- Dependencies: 6 733
-- Name: anmeldung_swap(bigint, character varying, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "anmeldung_swap"("lseminarid" bigint, "smatrikelnummer" character varying, "lkurstypid" bigint, "lkursid" bigint, "lkursidalt" bigint) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
kurs_aktuell_count integer;
kurs_neu_count integer;
kurstyp_max_allow integer;
kurstyp_min_allow integer;
matrikelnummer varchar;
BEGIN
-- init: kurs_aktuell_count,kurs_neu_count
select count(*) from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "lngKursID"=lKursIDAlt and "blnAnmeldungZuschlag"=true into kurs_aktuell_count;
select count(*) from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "lngKursID"=lKursID and "blnAnmeldungZuschlag"=true into kurs_neu_count;

select "intKurstypTauschMin" from "tblSdKurstyp" where "lngSdSeminarID"=lSeminarID and "lngKurstypID"=lkurstypid into kurstyp_min_allow;
select "intKurstypTauschMax" from "tblSdKurstyp" where "lngSdSeminarID"=lSeminarID and "lngKurstypID"=lkurstypid into kurstyp_max_allow;

IF (kurs_neu_count>kurstyp_max_allow AND kurs_neu_count >= kurs_aktuell_count) THEN
RAISE EXCEPTION 'Fr einen Kursplatztausch sind im neuen Kurs nicht genug Pltze vorhanden, sorry.';
END IF;

IF kurs_aktuell_count<kurstyp_min_allow THEN 
RAISE EXCEPTION 'Es gibt im aktuellen Kurs nur % Teilnehmer. Ein Tausch ist erst ab sechs Teilnehmern mglich', kurs_aktuell_count;
END IF;

-- Prfe, ob der Zuschlag im ursprnglichen Kurs
-- noch existiert (und nicht zwischenzeitlich vom 
-- Admin oder sonstwie schon interveniert wurde):
perform "dtmAnmeldungDatum" from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypID and "lngKursID"=lKursIDAlt and "blnAnmeldungZuschlag"=true;
IF NOT FOUND THEN
RAISE EXCEPTION 'Sie knnen von Kurs Nr. % nicht mehr tauschen, weil Sie dort keinen Platz (mehr?) haben.', lKursIDAlt;
END IF;

RAISE WARNING 'OK, konventioneller Tausch (Tn alter Kurs %, neuer Kurs %)',kurs_aktuell_count, kurs_neu_count;

-- noch todo: berlappung berprfen
perform erzeuge_anmeldung(lSeminarID, lKurstypID, lKursID, sMatrikelnummer);
update "tblBdAnmeldung" set "blnAnmeldungZuschlag"=true, "dtmAnmeldungDatum"=now() where "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypID and "lngKursID"=lKursID;
update "tblBdAnmeldung" set "blnAnmeldungZuschlag"=false, "dtmAnmeldungDatum"=now() where "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypID and "lngKursID"=lKursIDAlt;

-- lsche eigene Tauschwnsche zu diesem Kurs sowie in diesem Kurstyp
delete from "tblBdAnmeldungSwap" where "strMatrikelnummer"=sMatrikelnummer and ("lngKurstypID"=lKurstypID OR "lngKursID"=lKursID);

-- prfe, ob sich durch den Tausch wnsche erfllen lassen.
perform pruefe_wuensche(lSeminarID, lKursIDAlt);
END;
$$;


ALTER FUNCTION "public"."anmeldung_swap"("lseminarid" bigint, "smatrikelnummer" character varying, "lkurstypid" bigint, "lkursid" bigint, "lkursidalt" bigint) OWNER TO "postgres";

--
-- TOC entry 227 (class 1255 OID 219123)
-- Dependencies: 733 6
-- Name: anmeldung_swap(bigint, character varying, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "anmeldung_swap"("lseminarid" bigint, "smatrikelnummer" character varying, "lkurstypid" bigint, "lkursid" bigint, "lkursidalt" bigint, "lkurstypidneu" bigint) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
kurs_aktuell_count integer;
kurs_neu_count integer;
kurstyp_max_allow integer;
kurstyp_min_allow integer;
matrikelnummer varchar;
BEGIN
-- init: kurs_aktuell_count,kurs_neu_count
select count(*) from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "lngKursID"=lKursIDAlt and "blnAnmeldungZuschlag"=true into kurs_aktuell_count;
select count(*) from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "lngKursID"=lKursID and "blnAnmeldungZuschlag"=true into kurs_neu_count;

select "intKurstypTauschMin" from "tblSdKurstyp" where "lngSdSeminarID"=lSeminarID and "lngKurstypID"=lkurstypid into kurstyp_min_allow;
select "intKurstypTauschMax" from "tblSdKurstyp" where "lngSdSeminarID"=lSeminarID and "lngKurstypID"=lkurstypidneu into kurstyp_max_allow;

IF (kurs_neu_count>kurstyp_max_allow AND kurs_neu_count >= kurs_aktuell_count) THEN
RAISE EXCEPTION 'Fr einen Kursplatztausch sind im neuen Kurs nicht genug Pltze vorhanden, sorry.';
END IF;

IF kurs_aktuell_count<=kurstyp_min_allow THEN 
RAISE EXCEPTION 'Es gibt im aktuellen Kurs nur % Teilnehmer. Ein Tausch ist erst ab sechs Teilnehmern mglich', kurs_aktuell_count;
END IF;

--@todo: berprfe, dass im Zielkurstyp nicht
-- schon eine erfolgreiche Anmeldung vorliegt.
if(lKurstypID != lKurstypIDNeu) THEN
     perform "dtmAnmeldungDatum" from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypIDNeu and "blnAnmeldungZuschlag"=true;
     IF FOUND THEN
  RAISE EXCEPTION 'Sie haben in diesem Kurstyp bereits einen Kursplatz. Den mssen Sie erst lschen, bevor Sie dorthin tauschen knnen.';
     END IF;
END IF;

-- Prfe, ob der Zuschlag im ursprnglichen Kurs
-- noch existiert (und nicht zwischenzeitlich vom 
-- Admin oder sonstwie schon interveniert wurde):
perform "dtmAnmeldungDatum" from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypID and "lngKursID"=lKursIDAlt and "blnAnmeldungZuschlag"=true;
IF NOT FOUND THEN
RAISE EXCEPTION 'Sie knnen von Kurs Nr. % nicht mehr tauschen, weil Sie dort keinen Platz (mehr?) haben.', lKursIDAlt;
END IF;

RAISE WARNING 'OK, konventioneller Tausch (Tn alter Kurs %, neuer Kurs %)',kurs_aktuell_count, kurs_neu_count;

-- noch todo: berlappung berprfen
perform erzeuge_anmeldung(lSeminarID, lKurstypIDNeu, lKursID, sMatrikelnummer);
update "tblBdAnmeldung" set "blnAnmeldungZuschlag"=true, "dtmAnmeldungDatum"=now() where "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypIDNeu and "lngKursID"=lKursID;
update "tblBdAnmeldung" set "blnAnmeldungZuschlag"=false, "dtmAnmeldungDatum"=now() where "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypID and "lngKursID"=lKursIDAlt;

-- lsche eigene Tauschwnsche zu diesem Kurs sowie in diesem Kurstyp
delete from "tblBdAnmeldungSwap" where "strMatrikelnummer"=sMatrikelnummer and ("lngKurstypID"=lKurstypID OR "lngKursID"=lKursID OR "lngKurstypID"=lKurstypIDNeu);

-- prfe, ob sich durch den Tausch wnsche erfllen lassen.
perform pruefe_wuensche(lSeminarID, lKursIDAlt);
END;
$$;


ALTER FUNCTION "public"."anmeldung_swap"("lseminarid" bigint, "smatrikelnummer" character varying, "lkurstypid" bigint, "lkursid" bigint, "lkursidalt" bigint, "lkurstypidneu" bigint) OWNER TO "postgres";

--
-- TOC entry 228 (class 1255 OID 219127)
-- Dependencies: 6 733
-- Name: commacat_ignore_nulls("text", "text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "commacat_ignore_nulls"("acc" "text", "instr" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
  BEGIN
    IF acc IS NULL OR acc = '' THEN
      RETURN instr;
    ELSIF instr IS NULL OR instr = '' THEN
      RETURN acc;
    ELSE
      RETURN acc || ', ' || instr;
    END IF;
  END;
$$;


ALTER FUNCTION "public"."commacat_ignore_nulls"("acc" "text", "instr" "text") OWNER TO "postgres";

--
-- TOC entry 229 (class 1255 OID 219128)
-- Dependencies: 733 6
-- Name: deleteoverlaps(bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "deleteoverlaps"("lseminarid" bigint, "lkurstypid" bigint) RETURNS integer
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    iHowManyOverlaps integer;
    rOverlaps RECORD;
BEGIN
	FOR rOverlaps in select a."strMatrikelnummer", x."lngKurstypID", x."lngKursID" from "tblBdAnmeldung" a, "tblBdKurs" k, "tblBdKursXKurstyp" x where  
		      a."lngSdSeminarID"=lSeminarID and 
		      k."lngSdSeminarID"= lSeminarID and 
		      x."lngSeminarID"= lSeminarID and 
		      k."lngKursID"=x."lngKursID" and  
		      a."blnAnmeldungZuschlag"=true and 
		      a."lngKurstypID"=x."lngKurstypID" and  
		      a."lngKursID"=x."lngKursID" and 
		      a."lngKurstypID"= lKurstypID  and 
		      exists(select 
		      ((k."dtmKursBeginn",k."dtmKursEnde") OVERLAPS (k2."dtmKursBeginn", k2."dtmKursEnde")), 
		      ((k."dtmKursBeginn2",k."dtmKursEnde2") OVERLAPS (k2."dtmKursBeginn2", k2."dtmKursEnde2")),
		      ((k."dtmKursBeginn",k."dtmKursEnde") OVERLAPS (k2."dtmKursBeginn2", k2."dtmKursEnde2")),
		      ((k."dtmKursBeginn2",k."dtmKursEnde2") OVERLAPS (k2."dtmKursBeginn", k2."dtmKursEnde")) from "tblBdAnmeldung" a2, "tblBdKurs" k2, "tblBdKursXKurstyp" x2 where  
		      a2."lngSdSeminarID"= lSeminarID and  
		      k2."lngSdSeminarID"= lSeminarID and 
		      x2."lngSeminarID"= lSeminarID and 
		      k2."lngKursID"=x2."lngKursID" and  
		      a2."blnAnmeldungZuschlag"=true and 
		      a2."lngKurstypID"=x2."lngKurstypID" and  
		      a2."lngKursID"=x2."lngKursID" and 
		      a2."strMatrikelnummer"=a."strMatrikelnummer" and  
		      k2."lngKursID" != k."lngKursID" and 
		      (
			(k2."strKursTag"=k."strKursTag" and  
			(((k."dtmKursBeginn",k."dtmKursEnde") OVERLAPS (k2."dtmKursBeginn", k2."dtmKursEnde"))=true)) or  
		
			(k2."strKursTag2"=k."strKursTag2" and 
			(((k."dtmKursBeginn2",k."dtmKursEnde2") OVERLAPS (k2."dtmKursBeginn2", k2."dtmKursEnde2"))=true)) or  
		
			(k2."strKursTag2"=k."strKursTag" and 
			(((k."dtmKursBeginn",k."dtmKursEnde") OVERLAPS (k2."dtmKursBeginn2", k2."dtmKursEnde2"))=true)) or  
		
			(k."strKursTag2"=k2."strKursTag" and 
			(((k."dtmKursBeginn2",k."dtmKursEnde2") OVERLAPS (k2."dtmKursBeginn", k2."dtmKursEnde"))=true))
		      )) order by "strMatrikelnummer" LOOP 
			
			update "tblBdAnmeldung" set "blnAnmeldungFixiert"=false, "blnAnmeldungZuschlag"=false where 
					"lngSdSeminarID\"=lSeminarID and "lngKurstypID"= lKurstypID  and  
					"strMatrikelnummer"=rOverlaps."strMatrikelnummer";
			
			iHowManyOverlaps = iHowManyOverlaps+1;
		END LOOP;
		return iHowManyOverlaps;
END;
$$;


ALTER FUNCTION "public"."deleteoverlaps"("lseminarid" bigint, "lkurstypid" bigint) OWNER TO "postgres";

--
-- TOC entry 230 (class 1255 OID 219129)
-- Dependencies: 733 6
-- Name: erzeuge_anmeldung(bigint, bigint, bigint, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "erzeuge_anmeldung"("lseminarid" bigint, "lkurstypid" bigint, "lkursid" bigint, "smatrikelnummer" character varying) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
BEGIN
	PERFORM "dtmAnmeldungDatum" from "tblBdAnmeldung" where  "lngSdSeminarID"=lSeminarID and "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypID and "lngKursID"=lKursID;
	IF NOT FOUND THEN
		RAISE WARNING 'Füge Anmeldung für Kurs % hinzu', lKursID;
		insert into "tblBdAnmeldung" ("lngSdSeminarID", "strMatrikelnummer", "lngKurstypID", "lngKursID", "intAnmeldungPrioritaet") values 
					(lSeminarID, sMatrikelnummer, lKurstypID, lKursID, -1);
	END IF;
END;
$$;


ALTER FUNCTION "public"."erzeuge_anmeldung"("lseminarid" bigint, "lkurstypid" bigint, "lkursid" bigint, "smatrikelnummer" character varying) OWNER TO "postgres";

--
-- TOC entry 225 (class 1255 OID 219131)
-- Dependencies: 733 6
-- Name: grantall(bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "grantall"("lseminarid" bigint, "lkurstypid" bigint) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    next_unique_id integer;
    feeusage_id integer;
    seminar_id integer;
    sUserName varchar;
BEGIN
	-- alle bekommen den Kurs mit Priorität 9
	update "tblBdAnmeldung" set "blnAnmeldungZuschlag"=false where "lngSdSeminarID"=lSeminarID and "lngKurstypID"=lKurstypID and "blnAnmeldungFixiert"=false;
	update "tblBdAnmeldung" set "blnAnmeldungZuschlag"=true where "lngSdSeminarID"=lSeminarID and "lngKurstypID"=lKurstypID and "blnAnmeldungFixiert"=false and "intAnmeldungPrioritaet"=9;
END;
$$;


ALTER FUNCTION "public"."grantall"("lseminarid" bigint, "lkurstypid" bigint) OWNER TO "postgres";

--
-- TOC entry 226 (class 1255 OID 219132)
-- Dependencies: 6 733
-- Name: issuepruefung(bigint, character varying, integer, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "issuepruefung"("lseminarid" bigint, "smatrikelnummer" character varying, "ifachid" integer, "lpruefungid" bigint) RETURNS boolean
    LANGUAGE "plpgsql"
    AS $$
	DECLARE
    	b_return boolean;		-- Rückgabewert
    	b_first_loop boolean;	-- Flag
    	r_MODULE RECORD;		-- }
    	r_LEISTUNG RECORD;		-- }
    	r_REGEL RECORD;			-- } für loops
    	r_REGEL_DETAIL RECORD;	-- }
    	r_PLEISTUNG RECORD;		-- }
    	f_note numeric;			-- Note einer Leistung
    	f_modulnote numeric;	-- Berechnung der Modulnote
    	f_modulnote_lp numeric;	-- Leistungspunkte des Moduls
    	f_fachnote numeric;		-- Berechnung der Prüfungsnote
    	f_fachnote_divisor numeric;	-- Berechnung der Prüfungsnote
    	l_regel_id bigint;					-- Regeln erlauben Alternativleistungen
    	l_leistung_alternative_id bigint[];	-- Regeln
    	s_leistung_exclude varchar;			-- Überspringe Leistungen, die Alternativen haben, um nicht doppelt zu zählen.
    	s_pruefung_detail_insert varchar;	-- Zwischenspeichern der Zeilen von tblBdStudentPruefungDetail
    	s_rem_modulberechnung varchar;					-- } Notiere Modulberechnung als HTML-Tabelle
    	s_rem_modulberechnung_leistungsliste varchar;	-- }
    	d_pruefung_datum date;
BEGIN
	d_pruefung_datum='1970-1-1';
	f_modulnote:=0;
	f_modulnote_lp:=0;
	f_fachnote:=0;
	f_fachnote_divisor:=0;
	s_pruefung_detail_insert:='';
	b_return:=false;
	s_rem_modulberechnung_leistungsliste:='';
	s_rem_modulberechnung:='';
	
	-- (1) durchlaufe die Module dieser Prüfung 
	--     und schaue, ob alle Leistungen 
	--     bestanden sind
	-- RAISE WARNING 'issuePruefung: durchlaufe Module..';
	FOR r_MODULE IN SELECT pxm."lngPruefungID", pxm."lngModulID", m."strModulBezeichnung", pxm."blnZulassungsvoraussetzung", pxm."sngMinCreditPtsPLeistung", pxm."sngPruefungLeistungGewichtung" 
  		FROM "tblSdPruefungXModul" pxm, "tblSdModul" m where 
  		pxm."lngSdSeminarID"=lSeminarID and 
  		pxm."lngPruefungID"=lPruefungID and 
  		pxm."blnZulassungsvoraussetzung"=true and 
  		pxm."lngSdSeminarID"=m."lngSdSeminarID" and 
  		pxm."lngModulID"=m."lngModulID" LOOP
  		
  		b_return:=true;
  		--RAISE WARNING '..Modul % (ID: %; durchlaufe Leistungen)', r_MODULE."strModulBezeichnung", r_MODULE."lngModulID";
  		s_rem_modulberechnung_leistungsliste:='';
  		-- =====================================================================
  		-- Regel: durchlaufe immer nur _eine_ der Alternativen.
  		-- 		  Dazu werden alle Alternativen (außer der 
  		--		  ersten -- b_first_loop -- in die 
  		-- 		  Ausschlussliste s_leistung_exclude
  		--		  aufgenommen (und später übersprungen)
  		-- ======================================================================
  		s_leistung_exclude:='';
  		FOR r_REGEL IN SELECT "lngRegelID" FROM "tblSdPruefungRegel" where "lngSdSeminarID"=lSeminarID and 
			  "lngPruefungID"=lPruefungID LOOP
			  
			  b_first_loop:=true;
			  FOR r_REGEL_DETAIL IN SELECT "lngLeistungsID" FROM "tblSdPruefungRegelDetail" where 
			  	"lngSdSeminarID"=lSeminarID and "lngPruefungID"=lPruefungID 
			  	and "lngModulID"=r_MODULE."lngModulID" and "lngRegelID"=r_REGEL."lngRegelID" LOOP
			  
			  	IF(b_first_loop=true) THEN 
			  		b_first_loop:=false;
			  	ELSE
			  		s_leistung_exclude:=s_leistung_exclude || r_REGEL_DETAIL."lngLeistungsID" || ',';
			  	END IF;
			  END LOOP; -- Regel Detail	  
		END LOOP; -- Regel

	   -- schließe die Ausschussliste in Kommas ein
 	   if(char_length(s_leistung_exclude)>0) THEN
		  	s_leistung_exclude:=',' || s_leistung_exclude;
		  	--RAISE WARNING '...excluding %', s_leistung_exclude;
	   END IF;

		
  		-- Nested: Leistungen dieses Moduls
		FOR r_LEISTUNG IN SELECT x."lngSdSeminarID", x."lngModulID", x."lngLeistungID", x."sngMinCreditPts", l."strLeistungBezeichnung" 
		   FROM "tblSdModulXLeistung" x, "tblSdLeistung" l where x."lngSdSeminarID"=lSeminarID and 
		   x."lngModulID"= r_MODULE."lngModulID" and l."lngSdSeminarID"=x."lngSdSeminarID" and l."lngLeistungID"=x."lngLeistungID" LOOP
	   
		-- Überspringe Leistungen, die Alternativen haben;
		-- nach den Alternativen wird nämlich weiter unten
		-- explizit gesucht
		IF (strpos(s_leistung_exclude, ',' || r_LEISTUNG."lngLeistungID" || ',')=0) THEN
		
				-- RAISE WARNING '....Leistung %..', r_LEISTUNG."lngLeistungID";
				   
				-- Hat diese(r) Studierende diese Leistung in diesem 
				-- Modul schon bestanden?
				SELECT n."sngNoteECTSCalc", x."lngLeistungsID", x."lngStudentLeistungCount", x."dtmStudentLeistungAusstellungsd" into r_PLEISTUNG 
				FROM "tblBdStudentXLeistung" x, "tblSdNote" n 
				WHERE 
				  x."lngSdSeminarID" = n."lngSdSeminarID" AND
				  x."intNoteID" = n."intNoteID" AND
				  x."strMatrikelnummer"=sMatrikelnummer and 
				  n."blnNoteBestanden" = true and 
				  x."lngSdSeminarID"=lSeminarID and 
				  x."lngLeistungsID"=r_LEISTUNG."lngLeistungID" and 
				  x."lngModulID"=r_MODULE."lngModulID"  
				ORDER BY x."dtmStudentLeistungAntragdatum" ASC;
				
				IF FOUND THEN
					-- Ja, der Studierende hat die Leistung bestanden:
					-- notiere die Leistung in s_pruefung_detail_insert und 
					-- in der Erklärung der Notenberechnung (custom2)
					s_pruefung_detail_insert:=s_pruefung_detail_insert|| 'INSERT INTO "tblBdStudentPruefungDetail"(
				            "lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", 
				            "lngLeistungsID", "lngStudentLeistungCount", "lngModulID", "blnStudentLeistungPruefung", "sngStudentLeistungCreditPts")
						    VALUES (' || lSeminarID || ', ' || lPruefungID || ', ''' || sMatrikelnummer || ''', 1, 
						            ' || r_PLEISTUNG."lngLeistungsID" || ', ' || r_PLEISTUNG."lngStudentLeistungCount" || ', 
									' || r_MODULE."lngModulID" || ', true, ' || r_LEISTUNG."sngMinCreditPts" || ');';
					s_rem_modulberechnung_leistungsliste:=s_rem_modulberechnung_leistungsliste || '<tr><td>' || r_LEISTUNG."strLeistungBezeichnung" || '</td><td>'|| r_PLEISTUNG."sngNoteECTSCalc"::numeric ||'</td><td>'|| r_LEISTUNG."sngMinCreditPts" ||'</td></tr>';
				ELSE
					--RAISE WARNING '....Leistung % ist noch nicht bestanden, suche Alternative.', r_LEISTUNG."lngLeistungID";
		
					-- die Leistung ist nicht bestanden: suche 
					-- nach einer Alternativleistung
					SELECT "lngRegelID" into l_regel_id  
					  FROM "tblSdPruefungRegelDetail" where "lngSdSeminarID"=lSeminarID and 
					  "lngPruefungID"=lPruefungID and "lngModulID"=r_MODULE."lngModulID" and 
					  "lngLeistungsID"=r_LEISTUNG."lngLeistungID";
					
					IF NOT FOUND THEN
						--RAISE WARNING '......zu Leistung % in Modul % gibt es keine Alternative...breche ab.', r_LEISTUNG."lngLeistungID", r_MODULE."lngModulID";
						RETURN FALSE;
					END IF; --not found
		
					--RAISE WARNING '......Regel Nr. % bietet eine Alternativleistung, suche...', l_regel_id;
					SELECT array_agg("lngLeistungsID") into l_leistung_alternative_id  
					  FROM "tblSdPruefungRegelDetail" where "lngSdSeminarID"=lSeminarID and 
					  "lngPruefungID"=lPruefungID and "lngModulID"=r_MODULE."lngModulID" and 
					  "lngLeistungsID"!=r_LEISTUNG."lngLeistungID" and "lngRegelID"=l_regel_id;
					  
					-- Hat diese(r) Studierende die Alternativleistung in diesem 
					-- Modul bestanden?
					SELECT n."sngNoteECTSCalc", x."lngLeistungsID", x."lngStudentLeistungCount", x."dtmStudentLeistungAusstellungsd" into r_PLEISTUNG 
					FROM "tblBdStudentXLeistung" x, "tblSdNote" n
					WHERE 
					  x."lngSdSeminarID" = n."lngSdSeminarID" AND
					  x."intNoteID" = n."intNoteID" AND
					  x."strMatrikelnummer"=sMatrikelnummer and 
					  n."blnNoteBestanden" = true and 
					  x."lngSdSeminarID"=lSeminarID and 
					  x."lngLeistungsID" = ANY (l_leistung_alternative_id) and 
					  x."lngModulID"=r_MODULE."lngModulID"
					ORDER BY x."dtmStudentLeistungAntragdatum" ASC;
		
					IF NOT FOUND THEN
						--RAISE WARNING '......auch die Alternativleistung % noch nicht bestanden, breche ab.', l_leistung_alternative_id;
						RETURN FALSE;
					ELSE
						s_pruefung_detail_insert:=s_pruefung_detail_insert|| 'INSERT INTO "tblBdStudentPruefungDetail"(
				            "lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", 
				            "lngLeistungsID", "lngStudentLeistungCount", "lngModulID", "blnStudentLeistungPruefung", "sngStudentLeistungCreditPts")
						    VALUES (' || lSeminarID || ', ' || lPruefungID || ', ''' || sMatrikelnummer || ''', 1, 
						            ' || r_PLEISTUNG."lngLeistungsID" || ', ' || r_PLEISTUNG."lngStudentLeistungCount" || ', 
									' || r_MODULE."lngModulID" || ', true, ' || r_LEISTUNG."sngMinCreditPts" || ');';
						s_rem_modulberechnung_leistungsliste:=s_rem_modulberechnung_leistungsliste || '<tr><td>' || r_LEISTUNG."strLeistungBezeichnung" || '</td><td>'|| r_PLEISTUNG."sngNoteECTSCalc" ||'</td><td>'|| r_LEISTUNG."sngMinCreditPts" ||'</td></tr>';
					END IF; -- Alternative gefunden
				END IF; -- Ende Check Alternativleistung
				
				f_note=r_PLEISTUNG."sngNoteECTSCalc";
				
				if(r_PLEISTUNG."dtmStudentLeistungAusstellungsd">d_pruefung_datum) THEN
					d_pruefung_datum:=r_PLEISTUNG."dtmStudentLeistungAusstellungsd";
				END IF;
				
				--RAISE WARNING '....OK, Leistung (oder Alternative) bestanden, Note %, Gewichtung (LP) %', f_note, r_LEISTUNG."sngMinCreditPts";
				
				if(f_note>0) THEN
					f_modulnote:=f_modulnote + f_note * r_LEISTUNG."sngMinCreditPts";
					f_modulnote_lp:=f_modulnote_lp + r_LEISTUNG."sngMinCreditPts";
				END IF;
				-- RAISE WARNING '...... (Vektor %,%)', f_modulnote, f_modulnote_lp;
			ELSE
				--RAISE WARNING '....Leistung % hat Alternative und wird übersprungen', r_LEISTUNG."lngLeistungID";
			END IF;
		END LOOP; -- Leistungen

		-- berechnet Modulnote
		IF (f_modulnote_lp=0) THEN
			f_modulnote:=0;
		else
			f_modulnote:=trunc(f_modulnote/f_modulnote_lp, 1);
			-- f_modulnote:=f_modulnote/f_modulnote_lp;
		END IF;
		
		f_fachnote:=f_fachnote + f_modulnote * r_MODULE."sngMinCreditPtsPLeistung" * r_MODULE."sngPruefungLeistungGewichtung";
		f_fachnote_divisor:=f_fachnote_divisor + r_MODULE."sngMinCreditPtsPLeistung" * r_MODULE."sngPruefungLeistungGewichtung";
		-- RAISE WARNING '..Modul OK, Modulnote %, Gewichtung %, Faktor %, Fachnote tmp %', f_modulnote, r_MODULE."sngMinCreditPtsPLeistung", r_MODULE."sngPruefungLeistungGewichtung",f_fachnote;
		s_rem_modulberechnung:=s_rem_modulberechnung || '<tr style=&quot;background-color:#bbb&quot;><td>'|| r_MODULE."strModulBezeichnung" || '</td><td>'|| f_modulnote || '</td><td>'|| (r_MODULE."sngMinCreditPtsPLeistung" * r_MODULE."sngPruefungLeistungGewichtung") || s_rem_modulberechnung_leistungsliste || '</td></tr>';		
		f_modulnote:=0;
		f_modulnote_lp:=0;
  	END LOOP; -- Module
	
  	-- Endgültige Fachnote:
  	IF f_fachnote_divisor = 0 THEN
  		f_fachnote:=0;
  	ELSE
  		f_fachnote:=trunc(f_fachnote/f_fachnote_divisor,1);
  		--f_fachnote:=f_fachnote/f_fachnote_divisor;
  	END IF;
  	
  	-- insert
  	INSERT INTO "tblBdStudentXPruefung"(
            "lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", 
            "intNoteID", "strStudentPruefungNote", "strStudentPruefungSemester", 
            "blnStudentPruefungZUVInformiert", "blnStudentPruefungValidiert", 
            "blnStudentPruefungAnmeldung", "blnStudentPruefungGesiegelt", 
            "blnStudentPruefungBestanden", "dtmStudentPruefungAusstellungsd", 
            "strStudentPruefungAussteller", "strStudentPruefungRowIP", "strStudentPruefungCustom1","strStudentPruefungCustom2" 
            )
    VALUES (lSeminarID, lPruefungID, sMatrikelnummer, 1, 
            null, f_fachnote, '', false, false, 
            false, false, 
            true, d_pruefung_datum, 
            'Automatische Ausstellung', '', 'Durch Trigger erzeugt am ' || CURRENT_DATE::varchar, '<table><tr><td><b>Leistung/Modul</b></td><td><b>Note</b></td><td><b>LP</b></td></tr>'||s_rem_modulberechnung||'</table>');
  	
    EXECUTE s_pruefung_detail_insert;
	return b_return;	
END;
$$;


ALTER FUNCTION "public"."issuepruefung"("lseminarid" bigint, "smatrikelnummer" character varying, "ifachid" integer, "lpruefungid" bigint) OWNER TO "postgres";

--
-- TOC entry 231 (class 1255 OID 219135)
-- Dependencies: 6 733
-- Name: issuepruefungen(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "issuepruefungen"() RETURNS integer
    LANGUAGE "plpgsql"
    AS $$
DECLARE
	i_issued integer;
	l_BemerkungID bigint;
	l_DozentID bigint;
	r_PRUEFUNGEN RECORD;
	r_STUDENT RECORD;
BEGIN
	i_issued:=0;
	l_BemerkungID:=0;
	l_DozentID:=0;
	-- Durchlaufe getriggerte Prüfungen dieses Fachs
	FOR r_PRUEFUNGEN in SELECT 
	  "tblSdPruefungXFach"."lngSdSeminarID", 
	  "tblSdPruefungXFach"."lngPruefungID", 
	  "tblSdPruefungXFach"."intFachID",
	  "tblSdPruefung"."strPruefungBezeichnung"
	FROM 
	  "tblSdPruefungXFach", 
	  "tblSdPruefung"
	WHERE 
	  "tblSdPruefung"."lngSdSeminarID" = "tblSdPruefungXFach"."lngSdSeminarID" AND
	  "tblSdPruefung"."lngPruefungID" = "tblSdPruefungXFach"."lngPruefungID" AND
	  "tblSdPruefung"."blnPruefungTriggered" = true LOOP
	  
	  FOR r_STUDENT in select "strMatrikelnummer" from "tblBdStudent" where 
	  		"dtmStudentZUVUpdate">(CURRENT_DATE-90) and 
	  		("intStudentFach1"=r_PRUEFUNGEN."intFachID" OR 
	  		"intStudentFach2"=r_PRUEFUNGEN."intFachID" OR 
	  		"intStudentFach3"=r_PRUEFUNGEN."intFachID" OR 
	  		"intStudentFach4"=r_PRUEFUNGEN."intFachID" OR 
	  		"intStudentFach5"=r_PRUEFUNGEN."intFachID" OR 
	  		"intStudentFach6"=r_PRUEFUNGEN."intFachID") LOOP
	  		
		  perform * from "tblBdStudentXPruefung" where 
		  	"lngSdSeminarID"=r_PRUEFUNGEN."lngSdSeminarID" and 
		  	"lngSdPruefungsID"= r_PRUEFUNGEN."lngPruefungID" and 
		  	"strMatrikelnummer"=r_STUDENT."strMatrikelnummer";
		  	
		  IF NOT FOUND THEN
		  	IF(issuePruefung(r_PRUEFUNGEN."lngSdSeminarID", r_STUDENT."strMatrikelnummer", 
		  		r_PRUEFUNGEN."intFachID", r_PRUEFUNGEN."lngPruefungID")!=true) THEN
				RAISE WARNING '..(Fehlanzeige)';
			ELSE
				i_issued:=i_issued+1;
				IF(l_DozentID=0) THEN
					SELECT "lngDozentID" from "tblSdDozent" where 
						"lngSdSeminarID"=r_PRUEFUNGEN."lngSdSeminarID" and 
						"intDozentAccessLevel">400 limit 1 into l_DozentID;
				END IF;
				RAISE WARNING '..TREFFER: %', r_STUDENT."strMatrikelnummer";
				SELECT max("lngStudentBemerkungID")+1 from "tblBdStudentBemerkung" into l_BemerkungID; 
				INSERT INTO "tblBdStudentBemerkung"("lngStudentBemerkungID",
	            "lngSdSeminarID", "strMatrikelnummer", 
	            "lngDozentID", "strStudentBemerkungTag", "strStudentBemerkungText", 
	            "dtmStudentBemerkungDatum")
			    VALUES (l_BemerkungID, r_PRUEFUNGEN."lngSdSeminarID", r_STUDENT."strMatrikelnummer", l_DozentID, 
			            'Prüfung durch allg. Auto-Aufrug', 'SignUp hat automatisch die ' 
			            		|| r_PRUEFUNGEN."strPruefungBezeichnung" || 
			            		' ausgestellt (ausgelöst von der allg. Aufruffunktion)', CURRENT_DATE);

			END IF;
		END IF;
	END LOOP;
END LOOP;
RETURN i_issued;
END;
$$;


ALTER FUNCTION "public"."issuepruefungen"() OWNER TO "postgres";

--
-- TOC entry 232 (class 1255 OID 219136)
-- Dependencies: 733 6
-- Name: kursplatz_delete(bigint, bigint, bigint, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "kursplatz_delete"("lseminarid" bigint, "lkurstypid" bigint, "lkursid" bigint, "smatrikelnummer" character varying) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
BEGIN
	update "tblBdAnmeldung" set "blnAnmeldungZuschlag"=false, "dtmAnmeldungDatum"=now() where 
				"lngSdSeminarID"=lSeminarID	and "strMatrikelnummer"=sMatrikelnummer    
				and "lngKurstypID"=lKurstypID 
				and "lngKursID"=lKursID 
				and "blnAnmeldungZuschlag"=true;

	-- löscht ggf. Vormerkungen, die exakt diesen Kurstyp/Kurs betreffen
	delete from "tblBdAnmeldungSwap" where "strMatrikelnummer"=sMatrikelnummer and "lngKurstypID"=lKurstypID AND "lngKursID"=lKursID;
	
	perform pruefe_wuensche(lSeminarID, lKursID); 
END;
$$;


ALTER FUNCTION "public"."kursplatz_delete"("lseminarid" bigint, "lkurstypid" bigint, "lkursid" bigint, "smatrikelnummer" character varying) OWNER TO "postgres";

--
-- TOC entry 233 (class 1255 OID 219137)
-- Dependencies: 6 733
-- Name: mapmodules(bigint, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "mapmodules"("lseminarid" bigint, "smatrikelnummer" character varying, "ifachid" integer) RETURNS integer
    LANGUAGE "plpgsql"
    AS $$
DECLARE
	lPRUEFUNG_ID integer;
	--lMODUL_ID integer;
	r_MODUL_LP RECORD;
	r_LEISTUNGEN RECORD;
	r_STUDENT RECORD;
BEGIN
	-- Ordnet jeder Leistung des/r Studierenden
	-- das erstbeste Modul aus dem Studiengang iFachID
	-- zu; auch die LP werden justiert, sofern sie größer
	-- sind als null

	SELECT "tblSdPruefungXFach"."lngPruefungID" FROM 
	  public."tblSdFach", 
	  public."tblSdPruefungXFach"
	WHERE 
	  "tblSdPruefungXFach"."intFachID" = "tblSdFach"."intFachID" AND
	  "tblSdPruefungXFach"."intFachID" = iFachID AND 
	  "tblSdPruefungXFach"."blnPruefungFachAbschluss" = true 
	  into lPRUEFUNG_ID;

	IF FOUND THEN 

		-- durchlaufe die Leistungen
		FOR r_LEISTUNGEN IN SELECT "lngLeistungsID", "lngStudentLeistungCount" from "tblBdStudentXLeistung" 
		where "lngSdSeminarID"=lSeminarID and 
		"strMatrikelnummer"=sMatrikelnummer LOOP

		-- Suche nach einem passenden Modul
		SELECT 
		  "tblSdModulXLeistung"."lngModulID", "tblSdModulXLeistung"."sngMinCreditPts", "tblSdModul"."blnModulVarLP"
		FROM 
		  public."tblSdModulXLeistung", 
		  public."tblSdModul", 
		  public."tblSdPruefungXModul"
		WHERE 
		  "tblSdPruefungXModul"."lngSdSeminarID" = "tblSdModulXLeistung"."lngSdSeminarID" AND
		  "tblSdPruefungXModul"."lngModulID" = "tblSdModulXLeistung"."lngModulID" AND
		  "tblSdModul"."lngSdSeminarID" = "tblSdModulXLeistung"."lngSdSeminarID" AND
		  "tblSdModul"."lngModulID" = "tblSdModulXLeistung"."lngModulID" AND
		  "tblSdModulXLeistung"."lngSdSeminarID" = lSeminarID AND 
		  "tblSdPruefungXModul"."lngPruefungID" = lPRUEFUNG_ID AND 
		  "tblSdModulXLeistung"."lngLeistungID" = r_LEISTUNGEN."lngLeistungsID" ORDER BY "lngModulID" 
		  INTO r_MODUL_LP;

		if FOUND THEN
			update "tblBdStudentXLeistung" set "lngModulID"=r_MODUL_LP."lngModulID" where 
			"lngSdSeminarID"=lSeminarID and 
			"strMatrikelnummer"=sMatrikelnummer and 
			"lngLeistungsID"=r_LEISTUNGEN."lngLeistungsID" and 
			"lngStudentLeistungCount"=r_LEISTUNGEN."lngStudentLeistungCount";

			-- Setze die LP -- aber nur, wenn die Leistung
			-- bestanden ist (bzw. die LP vorher >0 waren)
			-- Damit nicht z.B. ÜK auf null gesetzt werden,
			-- werden die LP nur angefasst, wenn der neue
			-- Wert > 0 ist.
			-- ÜK müssen außerdem generell ausgeschlossen
			-- werden (da dort z.T. auch 1 LP eingetragen 
			-- sind)
			if r_MODUL_LP."sngMinCreditPts">0 AND r_MODUL_LP."blnModulVarLP"=false THEN
				update "tblBdStudentXLeistung" set "sngStudentLeistungCreditPts"=r_MODUL_LP."sngMinCreditPts" where 
				"lngSdSeminarID"=lSeminarID and 
				"strMatrikelnummer"=sMatrikelnummer and 
				"lngLeistungsID"=r_LEISTUNGEN."lngLeistungsID" and 
				"sngStudentLeistungCreditPts">0 and 
				"lngStudentLeistungCount"=r_LEISTUNGEN."lngStudentLeistungCount";
			END IF;
		END IF;

		END LOOP;
	
	END IF;
	RETURN 1;
END;
$$;


ALTER FUNCTION "public"."mapmodules"("lseminarid" bigint, "smatrikelnummer" character varying, "ifachid" integer) OWNER TO "postgres";

--
-- TOC entry 234 (class 1255 OID 219138)
-- Dependencies: 6
-- Name: plpgsql_call_handler(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "plpgsql_call_handler"() RETURNS "language_handler"
    LANGUAGE "c"
    AS '$libdir/plpgsql', 'plpgsql_call_handler';


ALTER FUNCTION "public"."plpgsql_call_handler"() OWNER TO "postgres";

--
-- TOC entry 235 (class 1255 OID 219139)
-- Dependencies: 6 733
-- Name: postprocessing(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "postprocessing"() RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
sSQLCommand varchar;
sMatrikelnummer varchar;
rFachwechsel RECORD;
integer_var integer;
BEGIN
-- Lösche alle Einträge zur Nachbearbeitung
-- Studierender, die schon seit mehr als
-- 300 Tagen nicht mehr rückgemeldet sind.
delete from "tblPostprocessing" USING "tblBdStudent" where ("tblPostprocessing"."strMatrikelnummer" = 
"tblBdStudent"."strMatrikelnummer" and (CURRENT_DATE-"tblBdStudent"."dtmStudentZUVUpdate")>300);


FOR rFachwechsel in select "strSQL", "strKommentar" from "tblPostprocessing" order by "dtmDatum" LOOP
EXECUTE rFachwechsel."strSQL";
GET DIAGNOSTICS integer_var = ROW_COUNT;
RAISE WARNING '% (% Updates)',rFachwechsel."strKommentar", integer_var;
END LOOP;

END;
$$;


ALTER FUNCTION "public"."postprocessing"() OWNER TO "postgres";

--
-- TOC entry 236 (class 1255 OID 219140)
-- Dependencies: 733 6
-- Name: pruefe_wuensche(bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "pruefe_wuensche"("lseminarid" bigint, "lkursid" bigint) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
	kurs_count integer;
	r_wunsch "tblBdAnmeldungSwap"%ROWTYPE;
BEGIN
	select count(*) from "tblBdAnmeldung" where "lngSdSeminarID"=lSeminarID and "lngKursID"=lKursID and "blnAnmeldungZuschlag"=true into kurs_count;
	
	RAISE WARNING 'Wunschtest für Kurs %, Tn % (breche ab, falls 25 oder mehr)',lKursID, kurs_count;
	
	IF(kurs_count<25) THEN
		FOR r_wunsch IN SELECT * FROM "tblBdAnmeldungSwap" where "lngSdSeminarID"=lSeminarID and "lngKursIDWunsch"=lKursID and "blnAnmeldungSwapZuschlag"=false LOOP
		
			-- Error Handling for errors from AnmeldungSwap
			-- eternal loop? Testen: Kurse mit je 25 TN, verschränkte Tauschwünsche (x nach y und y nach x).
			RAISE WARNING 'KurstypID Wunsch ist % ', r_wunsch."lngKurstypIDWunsch";
			perform Anmeldung_Swap(lSeminarID, r_wunsch."strMatrikelnummer", r_wunsch."lngKurstypID", r_wunsch."lngKursIDWunsch", r_wunsch."lngKursID", r_wunsch."lngKurstypIDWunsch");
        	
			-- Wunsch löschen
			update "tblBdAnmeldungSwap" set "blnAnmeldungSwapZuschlag"=true where "lngSdSeminarID"=lSeminarID and "lngKursID"=lKursID and "strMatrikelnummer"=r_wunsch."strMatrikelnummer";
        	
        	kurs_count := kurs_count+1;
        	if(kurs_count>24) THEN
        		EXIT;
        	END IF;
        	
    	END LOOP;
	END IF;
END;
$$;


ALTER FUNCTION "public"."pruefe_wuensche"("lseminarid" bigint, "lkursid" bigint) OWNER TO "postgres";

--
-- TOC entry 237 (class 1255 OID 219141)
-- Dependencies: 6 733
-- Name: trigger_check_raumbuchung(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "trigger_check_raumbuchung"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$

-- Prft, dass der Raum nicht schon belegt ist
BEGIN

-- Ist der Raum bereits berlappend belegt?
PERFORM "lngSdSeminarID" FROM "tblBdKursTermin"
WHERE "lngSdSeminarID"=NEW."lngSdSeminarID" and 
"strRaumBezeichnung"=NEW."strRaumBezeichnung" and 
"dtmKursTerminDatum"=NEW."dtmKursTerminDatum" and 
("dtmKursTerminStart","dtmKursTerminStop") overlaps (NEW."dtmKursTerminStart",NEW."dtmKursTerminStop") and 
"blnKursTerminZuschlag"=true;
  
-- falls ja, wird ein Fehler ausgelst.
IF FOUND THEN
RAISE EXCEPTION 'Raum % ist am % von % bis % bereits belegt -- sorry.', NEW."strRaumBezeichnung", NEW."dtmKursTerminDatum", NEW."dtmKursTerminStart", NEW."dtmKursTerminStop";
RETURN NULL;
END IF;

return NEW;
END;
$$;


ALTER FUNCTION "public"."trigger_check_raumbuchung"() OWNER TO "postgres";

--
-- TOC entry 238 (class 1255 OID 219142)
-- Dependencies: 733 6
-- Name: triggerpruefungonleistungadd(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "triggerpruefungonleistungadd"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$

-- Problems: trigger bei Update (note auf bestanden, Moduländerung etc.)
DECLARE
    fach_id integer;
    sUserName varchar;
    s_Leistung varchar;
    l_BemerkungID bigint;
    r_PRUEFUNG RECORD;
    r_FACH RECORD;
BEGIN
	-- RAISE WARNING 'Neue Leistung: wird Prüfung ausgelöst?';
	
	-- Leistung bestanden?
	PERFORM "lngSdSeminarID" from "tblSdNote" where "lngSdSeminarID"=NEW."lngSdSeminarID" 
		AND "intNoteID"=NEW."intNoteID" and "blnNoteBestanden"=true;
	
	-- falls nicht, brechen wir ab:
	IF NOT FOUND THEN
		-- RAISE WARNING '..Leistung ist nicht bestanden, suche nicht weiter nach Prüfungen.';
		RETURN NULL;
	END IF;
	
	-- Leistung ist bestanden. Eruiere das
	-- relevante Fach des Studierenden:
	select "intStudentFach1","intStudentFach2","intStudentFach3","intStudentFach4",
		"intStudentFach5","intStudentFach6" from "tblBdStudent" into r_FACH where
		"strMatrikelnummer"=NEW."strMatrikelnummer";
		
	select "intFachID" from "tblSdSeminarXFach" where "lngSeminarID"=NEW."lngSdSeminarID" AND 
		"intFachID" IN (r_FACH."intStudentFach1",r_FACH."intStudentFach2",r_FACH."intStudentFach3",
		r_FACH."intStudentFach4",r_FACH."intStudentFach5",r_FACH."intStudentFach6") into fach_id;
	
	-- RAISE WARNING 'Durchlaufe getriggerte Prüfungen im Fach %', fach_ID;
	
	-- durchlaufe alle Prüfungen, 
	-- die zum relevanten Fach gehören, 
	-- die als "triggered" gekennzeichnet sind,
	-- und das relevante Modul enthalten
	FOR r_PRUEFUNG IN SELECT 
	  pxf."intFachID", 
	  pxf."lngPruefungID",
	  pxm."lngModulID", 
	  pxm."sngPruefungLeistungGewichtung", 
	  pxm."sngMinCreditPts", 
	  p."strPruefungBezeichnung", 
	  p."strPruefungBeschreibung"
	FROM 
	  "tblSdPruefungXFach" pxf, 
	  "tblSdPruefungXModul" pxm, 
	  "tblSdPruefung" p
	WHERE 
	  pxm."lngModulID"=NEW."lngModulID" and 
	  pxf."lngSdSeminarID"=NEW."lngSdSeminarID" and 
	  pxf."intFachID"=fach_id and
	  pxf."lngSdSeminarID" = pxm."lngSdSeminarID" AND
	  pxf."lngPruefungID" = pxm."lngPruefungID" AND
	  p."lngSdSeminarID" = pxf."lngSdSeminarID" AND
	  p."lngPruefungID" = pxf."lngPruefungID" AND
	  p."blnPruefungTriggered" = true LOOP
	  
	  -- RAISE WARNING '..teste, ob zu Prüfung <<%>> schon ein Eintrag vorliegt', r_PRUEFUNG."strPruefungBezeichnung";
	  perform * from "tblBdStudentXPruefung" where 
	  	"lngSdSeminarID"=NEW."lngSdSeminarID" and 
	  	"lngSdPruefungsID"= r_PRUEFUNG."lngPruefungID" and 
	  	"strMatrikelnummer"=NEW."strMatrikelnummer";
	  	
	  IF NOT FOUND THEN
	  	-- RAISE WARNING '....Rufe issue Prüfung auf';
	  	IF(issuePruefung(NEW."lngSdSeminarID", NEW."strMatrikelnummer", fach_ID, r_PRUEFUNG."lngPruefungID")!=true) THEN
			-- RAISE WARNING '....Prüfung kann nicht ausgestellt werden.';
		ELSE
			-- RAISE WARNING '...Prüfung ausgestellt, mache Bemerkung';
			Select "strLeistungBezeichnung" FROM "tblSdLeistung" where 
				"lngSdSeminarID"=NEW."lngSdSeminarID" and "lngLeistungID"=NEW."lngLeistungsID" INTO s_Leistung;
			SELECT max("lngStudentBemerkungID")+1 from "tblBdStudentBemerkung" into l_BemerkungID; 
			INSERT INTO "tblBdStudentBemerkung"("lngStudentBemerkungID",
            "lngSdSeminarID", "strMatrikelnummer", 
            "lngDozentID", "strStudentBemerkungTag", "strStudentBemerkungText", 
            "dtmStudentBemerkungDatum")
		    VALUES (l_BemerkungID, NEW."lngSdSeminarID", NEW."strMatrikelnummer", NEW."lngDozentID", 
		            'Prüfung durch Trigger', 'SignUp hat automatisch die ' 
		            		|| r_PRUEFUNG."strPruefungBezeichnung" || 
		            		' ausgestellt (ausgelöst durch ' ||  s_Leistung || ' vom ' || NEW."dtmStudentLeistungAusstellungsd" || ')', CURRENT_DATE);

		END IF;
	  ELSE
	  	-- RAISE WARNING '....diese Prüfung ist bereits bestanden, suche weiter...';
	  END IF; -- (Not found)
	  
	END LOOP;

	return null;	
END;
$$;


ALTER FUNCTION "public"."triggerpruefungonleistungadd"() OWNER TO "postgres";

--
-- TOC entry 734 (class 1255 OID 219147)
-- Dependencies: 6
-- Name: textcat_all("text"); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE "textcat_all"("text") (
    SFUNC = "textcat",
    STYPE = "text",
    INITCOND = ''
);


ALTER AGGREGATE "public"."textcat_all"("text") OWNER TO "postgres";

SET default_with_oids = false;

--
-- TOC entry 161 (class 1259 OID 219157)
-- Dependencies: 2045 6
-- Name: tblBdData; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdData" (
    "lngSdSeminarID" integer NOT NULL,
    "strSemesterbezeichnung" character varying(12) DEFAULT ''::character varying NOT NULL,
    "dtmSignUpStart" "date",
    "dtmSignUpStop" "date",
    "blnHttpserverAktiv" boolean,
    "blnHttpShowResults" boolean,
    "blnAllowRegistration" integer
);


ALTER TABLE "public"."tblBdData" OWNER TO "postgres";

--
-- TOC entry 162 (class 1259 OID 219161)
-- Dependencies: 2759 6
-- Name: qryBdStatus; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW "qryBdStatus" AS
    SELECT "tblBdData"."lngSdSeminarID", "tblBdData"."strSemesterbezeichnung", CASE WHEN ("tblBdData"."dtmSignUpStart" > "date"(('now'::"text")::timestamp without time zone)) THEN true ELSE false END AS "blnBeforeSignUp", CASE WHEN (("tblBdData"."dtmSignUpStart" <= "date"(('now'::"text")::timestamp without time zone)) AND ("date"(('now'::"text")::timestamp without time zone) <= "tblBdData"."dtmSignUpStop")) THEN true ELSE false END AS "blnDuringSignUp", "tblBdData"."dtmSignUpStart", "tblBdData"."dtmSignUpStop", "tblBdData"."blnHttpserverAktiv", "tblBdData"."blnHttpShowResults" FROM "tblBdData";


ALTER TABLE "public"."qryBdStatus" OWNER TO "postgres";

--
-- TOC entry 163 (class 1259 OID 219173)
-- Dependencies: 6
-- Name: tblBdAnmeldung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdAnmeldung" (
    "lngSdSeminarID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "lngKursID" integer NOT NULL,
    "lngKurstypID" integer NOT NULL,
    "intAnmeldungPrioritaet" integer NOT NULL,
    "lngAnmeldungRandom" integer,
    "blnAnmeldungZuschlag" boolean,
    "dtmAnmeldungDatum" "date",
    "blnAnmeldungFixiert" boolean
);


ALTER TABLE "public"."tblBdAnmeldung" OWNER TO "postgres";

--
-- TOC entry 164 (class 1259 OID 219176)
-- Dependencies: 6
-- Name: tblBdAnmeldungSwap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdAnmeldungSwap" (
    "lngSdSeminarID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "lngKursID" integer NOT NULL,
    "lngKurstypID" integer NOT NULL,
    "lngKursIDWunsch" integer NOT NULL,
    "blnAnmeldungSwapZuschlag" boolean,
    "dtmAnmeldungSwapDatum" "date",
    "lngKurstypIDWunsch" integer NOT NULL
);


ALTER TABLE "public"."tblBdAnmeldungSwap" OWNER TO "postgres";

--
-- TOC entry 165 (class 1259 OID 219187)
-- Dependencies: 2046 2047 6
-- Name: tblBdDozentBemerkung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdDozentBemerkung" (
    "lngDozentBemerkungID" integer DEFAULT "nextval"(('"tblBdDozent_lngStudentBem_seq"'::"text")::"regclass") NOT NULL,
    "lngSdSeminarID" integer NOT NULL,
    "lngDozentID" integer NOT NULL,
    "strDozentBemerkungTag" character varying(50) NOT NULL,
    "strDozentBemerkungText" "text" DEFAULT ''::"text",
    "dtmDozentBemerkungDatum" "date" NOT NULL,
    "dtmDozentBemerkungWv" "date" NOT NULL
);


ALTER TABLE "public"."tblBdDozentBemerkung" OWNER TO "postgres";

--
-- TOC entry 166 (class 1259 OID 219226)
-- Dependencies: 6
-- Name: tblBdDozent_lngStudentBem_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "tblBdDozent_lngStudentBem_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "public"."tblBdDozent_lngStudentBem_seq" OWNER TO "postgres";

--
-- TOC entry 167 (class 1259 OID 219244)
-- Dependencies: 2048 2049 2050 2051 2052 2053 2054 2055 2056 2057 2058 2059 2060 2061 2062 2063 2064 2065 2066 2067 2068 2069 2070 2071 6
-- Name: tblBdKurs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdKurs" (
    "lngSdSeminarID" integer NOT NULL,
    "lngKursID" integer NOT NULL,
    "strKursUnivISID" character varying(50) DEFAULT ''::character varying,
    "lngDozentID" integer NOT NULL,
    "strKursTag" character varying(50) DEFAULT ''::character varying,
    "dtmKursBeginn" time without time zone,
    "dtmKursEnde" time without time zone,
    "strKursRaum" character varying(5) DEFAULT ''::character varying,
    "strKursTag2" character varying(50) DEFAULT ''::character varying,
    "dtmKursBeginn2" time without time zone,
    "dtmKursEnde2" time without time zone,
    "strKursRaum2" character varying(5) DEFAULT ''::character varying,
    "intKursTeilnehmerMaximal" integer DEFAULT 25,
    "lngKursRequests" integer DEFAULT 0,
    "strKursTitel" "text" NOT NULL,
    "strKursTitel_en" "text" DEFAULT 'No English title available'::"text",
    "strKursBeschreibung" "text" DEFAULT ''::"text",
    "strKursBeschreibung_en" "text" DEFAULT 'No English description available'::"text",
    "strKursLiteratur" "text" DEFAULT ''::"text",
    "strKursZusatz" "text" DEFAULT ''::"text",
    "strKursAnmeldung" character varying(254) DEFAULT ''::character varying,
    "strKursVoraussetzung" "text" DEFAULT ''::"text",
    "blnKursSchein" boolean,
    "strKursEinordnung" character varying(50) DEFAULT ''::character varying,
    "intKursStunden" integer DEFAULT 2 NOT NULL,
    "dtmKursLastChange" timestamp with time zone,
    "dtmKursScheinanmeldungBis" "date",
    "dtmKursScheinanmeldungVon" "date",
    "blnKursScheinanmeldungErlaubt" boolean,
    "intKursSequence" integer DEFAULT 0,
    "blnKursPlanungssemester" boolean NOT NULL,
    "strKursTerminFreitext" "text" DEFAULT ''::"text",
    "intKursTeilnehmer" integer DEFAULT 0,
    "strKursRaumExtern1" character varying(50) DEFAULT ''::character varying,
    "strKursRaumExtern2" character varying(50) DEFAULT ''::character varying,
    "strKursCustom1" "text" DEFAULT ''::"text",
    "strKursCustom2" "text" DEFAULT ''::"text",
    "strKursCustom3" "text" DEFAULT ''::"text",
    "sngKursCreditPts" double precision
);


ALTER TABLE "public"."tblBdKurs" OWNER TO "postgres";

--
-- TOC entry 168 (class 1259 OID 219274)
-- Dependencies: 2072 6
-- Name: tblBdKursTermin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdKursTermin" (
    "lngSdSeminarID" integer NOT NULL,
    "lngKursID" integer NOT NULL,
    "intKursTerminPrioritaet" integer NOT NULL,
    "intKursTerminNummer" integer NOT NULL,
    "strRaumBezeichnung" character varying(5) DEFAULT ''::character varying,
    "dtmKursTerminDatum" "date",
    "dtmKursTerminStart" time without time zone,
    "dtmKursTerminStop" time without time zone,
    "blnKursTerminZuschlag" boolean
);


ALTER TABLE "public"."tblBdKursTermin" OWNER TO "postgres";

--
-- TOC entry 169 (class 1259 OID 219278)
-- Dependencies: 2073 2074 2075 2076 2077 2078 2079 2080 2081 2082 2083 6
-- Name: tblBdKursXKurstyp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdKursXKurstyp" (
    "lngSeminarID" integer NOT NULL,
    "lngKurstypID" integer NOT NULL,
    "lngKursID" integer NOT NULL,
    "strBemerkung" character varying(50) DEFAULT ''::character varying,
    "strBemerkung_en" character varying(255) DEFAULT ''::character varying,
    "sngKursCreditPts" double precision,
    "intKursSemesterMin" integer DEFAULT 0,
    "intKursSemesterMax" integer DEFAULT 25,
    "strCustom1" "text" DEFAULT ''::"text",
    "strCustom2" "text" DEFAULT ''::"text",
    "strCustom3" "text" DEFAULT ''::"text",
    "strCustom1_en" "text" DEFAULT ''::"text",
    "strCustom2_en" "text" DEFAULT ''::"text",
    "strCustom3_en" "text" DEFAULT ''::"text",
    "intKursCommitmentMode" integer DEFAULT 0
);


ALTER TABLE "public"."tblBdKursXKurstyp" OWNER TO "postgres";

--
-- TOC entry 170 (class 1259 OID 219295)
-- Dependencies: 2084 2085 2086 2087 2088 2089 6
-- Name: tblBdKursXLink; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdKursXLink" (
    "lngSdSeminarID" integer NOT NULL,
    "lngKursID" integer NOT NULL,
    "lngLinkID" integer NOT NULL,
    "strKursLinkURL" "text" DEFAULT 'http://www.'::"text" NOT NULL,
    "strKursLinkBezeichnung" character varying(50) DEFAULT ''::character varying NOT NULL,
    "strKursLinkBeschreibung" "text" DEFAULT ''::"text",
    "blnKursLinkDownload" boolean,
    "blnKursLinkVisible" boolean,
    "strKursLinkCustom1" "text" DEFAULT ''::"text",
    "strKursLinkCustom2" "text" DEFAULT ''::"text",
    "strKursLinkCustom3" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblBdKursXLink" OWNER TO "postgres";

--
-- TOC entry 171 (class 1259 OID 219307)
-- Dependencies: 2090 2091 2092 2093 2094 2095 2096 2097 2098 2099 2100 2101 2102 2103 2104 2105 2106 2107 2108 2109 2110 2111 2112 6
-- Name: tblBdKvvArchiv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdKvvArchiv" (
    "lngSdFakultaetID" integer NOT NULL,
    "strSdFakultaetName" character varying(50) DEFAULT ''::character varying NOT NULL,
    "lngSdSeminarID" integer NOT NULL,
    "strSdSeminarName" character varying(50) DEFAULT ''::character varying NOT NULL,
    "lngID" integer NOT NULL,
    "lngKvvArchivKurstypID" integer NOT NULL,
    "lngKvvArchivKursID" integer NOT NULL,
    "strKvvArchivSemesterName" character varying(12) NOT NULL,
    "strKvvArchivDozentname" character varying(50) NOT NULL,
    "strKvvArchivKurstypBezeichnung" character varying(50) DEFAULT ''::character varying,
    "strKvvArchivKursEinordnung" character varying(50) DEFAULT ''::character varying,
    "strKvvArchivKursKategorie" character varying(50) DEFAULT ''::character varying,
    "strKvvArchivKurstitel" "text" NOT NULL,
    "strKvvArchivKurstitel_en" "text" DEFAULT ''::"text",
    "strKvvArchivKursTag" character varying(50) DEFAULT ''::character varying,
    "dtmKvvArchivKursBeginn" time without time zone,
    "dtmKvvArchivKursEnde" time without time zone,
    "strKvvArchivKursRaum" character varying(50) DEFAULT ''::character varying,
    "strKvvArchivKursTag2" character varying(50) DEFAULT ''::character varying,
    "dtmKvvArchivKursBeginn2" time without time zone,
    "dtmKvvArchivKursEnde2" time without time zone,
    "strKvvArchivKursKursRaum2" character varying(50) DEFAULT ''::character varying,
    "strKvvArchivKursBeschreibung" "text" DEFAULT ''::"text",
    "strKvvArchivKursBeschreibung_en" "text" DEFAULT ''::"text",
    "strKvvArchivKursVoraussetzung" "text" DEFAULT ''::"text",
    "blnKvvArchivKursSchein" boolean,
    "strKvvArchivKursLiteratur" "text" DEFAULT ''::"text",
    "strKvvArchivKursZusatz" "text" DEFAULT ''::"text",
    "strKvvArchivKursTerminFreitext" "text" DEFAULT ''::"text",
    "intKvvArchivKursTeilnehmer" integer DEFAULT 0,
    "sngKvvArchivKursCreditPts" double precision DEFAULT 0,
    "strKvvArchivCustom1" "text" DEFAULT ''::"text",
    "strKvvArchivCustom2" "text" DEFAULT ''::"text",
    "strKvvArchivCustom3" "text" DEFAULT ''::"text",
    "strKvvArchivDozentvorname" character varying(50),
    "strKvvArchivDozenttitel" character varying(50),
    "lngKvvArchivLeistungID" integer DEFAULT 0,
    "strKvvArchivLeistungBezeichnung" "text" DEFAULT ''::"text",
    "lngKvvArchivDozentID" bigint
);


ALTER TABLE "public"."tblBdKvvArchiv" OWNER TO "postgres";

--
-- TOC entry 172 (class 1259 OID 219336)
-- Dependencies: 2113 2114 2115 2116 2117 6
-- Name: tblBdKvvArchivXLinks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdKvvArchivXLinks" (
    "lngID" integer NOT NULL,
    "lngLinkID" integer NOT NULL,
    "strArchivLinkURL" "text" NOT NULL,
    "strArchivLinkBezeichnung" character varying(50) DEFAULT ''::character varying NOT NULL,
    "strArchivLinkBeschreibung" "text" DEFAULT ''::"text",
    "blnArchivLinkDownload" boolean,
    "strArchivLinkCustom1" "text" DEFAULT ''::"text",
    "strArchivLinkCustom2" "text" DEFAULT ''::"text",
    "strArchivLinkCustom3" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblBdKvvArchivXLinks" OWNER TO "postgres";

--
-- TOC entry 173 (class 1259 OID 219350)
-- Dependencies: 2118 2119 2120 2121 2122 6
-- Name: tblBdPruefungAblauf; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdPruefungAblauf" (
    "lngSdSeminarID" integer NOT NULL,
    "lngSdPruefungsID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "intStudentPruefungCount" integer NOT NULL,
    "lngAblaufID" integer NOT NULL,
    "blnPruefungAblaufErledigt" boolean NOT NULL,
    "strPruefungAblaufBemerkung" "text" DEFAULT ''::"text",
    "dtmPruefungAblaufDatum" "date",
    "strPruefungAblaufPerson" character varying(50) DEFAULT ''::character varying,
    "strCustom1" character varying(50) DEFAULT ''::character varying,
    "strCustom2" character varying(50) DEFAULT ''::character varying,
    "strCustom3" character varying(50) DEFAULT ''::character varying
);


ALTER TABLE "public"."tblBdPruefungAblauf" OWNER TO "postgres";

--
-- TOC entry 174 (class 1259 OID 219361)
-- Dependencies: 2123 2124 2125 2126 6
-- Name: tblBdRaumplanExtern; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdRaumplanExtern" (
    "lngSdSeminarID" integer NOT NULL,
    "lngLfdNr" integer NOT NULL,
    "strRaum" character varying(5) DEFAULT ''::character varying NOT NULL,
    "strTag" character varying(10) DEFAULT ''::character varying,
    "dtmBeginn" time without time zone,
    "dtmEnde" time without time zone,
    "strName" "text" DEFAULT ''::"text",
    "strKurstypBezeichnung" "text" DEFAULT ''::"text",
    "blnPlanung" boolean NOT NULL
);


ALTER TABLE "public"."tblBdRaumplanExtern" OWNER TO "postgres";

--
-- TOC entry 175 (class 1259 OID 219371)
-- Dependencies: 2127 2128 6
-- Name: tblBdSprechstunde; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdSprechstunde" (
    "lngSdSeminarID" bigint NOT NULL,
    "lngDozentID" bigint NOT NULL,
    "strNutzerUniID" character varying(10),
    "strMatrikelnummer" character varying(7),
    "strSprechstundeBemerkung" "text",
    "blnSprechstundeNurStudent" boolean DEFAULT false NOT NULL,
    "dtmSprechstundeDatum" "date" NOT NULL,
    "tmeSprechstundeStart" time without time zone NOT NULL,
    "tmeSprechstundeStop" time without time zone,
    "blnSprechstundeEmailReminder" boolean,
    "strSprechstundeOrt" "text",
    "strSprechstundeStornolink" character varying(250),
    "blnSprechstundeAbgesagt" boolean DEFAULT false
);


ALTER TABLE "public"."tblBdSprechstunde" OWNER TO "postgres";

--
-- TOC entry 176 (class 1259 OID 219379)
-- Dependencies: 2129 2130 2131 2132 2133 2134 2135 2136 2137 2138 2139 2140 2141 2142 2143 2144 2145 6
-- Name: tblBdStudent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudent" (
    "lngStudentPID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "strStudentVorname" character varying(50) NOT NULL,
    "strStudentNachname" character varying(150) NOT NULL,
    "intStudentSemester" integer DEFAULT 0,
    "strStudentPasswort" character varying(200) DEFAULT 'changeme'::character varying NOT NULL,
    "blnStudentLoggedIn" boolean,
    "dtmStudentGeburtstag" "date",
    "strStudentGeburtsort" character varying(254) DEFAULT ''::character varying,
    "strStudentStrasse" character varying(100) DEFAULT ''::character varying,
    "strStudentPLZ" character varying(5) DEFAULT ''::character varying,
    "strStudentOrt" character varying(100) DEFAULT ''::character varying,
    "strStudentEmail" character varying(50) DEFAULT ''::character varying,
    "blnStudentPublishEmail" boolean,
    "strStudentTelefon" character varying(30) DEFAULT ''::character varying,
    "strStudentHandy" character varying(30) DEFAULT ''::character varying,
    "blnStudentPublishHandy" boolean,
    "strStudentHomepage" character varying(250) DEFAULT ''::character varying,
    "blnStudentPublishHomepage" boolean,
    "strStudentInterests" "text" DEFAULT ''::"text",
    "blnStudentVisible" boolean,
    "dtmStudentLastLogin" timestamp with time zone,
    "dtmStudentLastLogout" timestamp with time zone,
    "strStudentHf1" character varying(10) DEFAULT ''::character varying,
    "strStudentHf2" character varying(10) DEFAULT ''::character varying,
    "blnStudentFemale" boolean NOT NULL,
    "lngStudentRandom" integer,
    "strStudentZUVFach" character varying(4),
    "intStudentFach1" integer NOT NULL,
    "intStudentFach2" integer,
    "intStudentFach3" integer,
    "intStudentFach4" integer,
    "intStudentFach5" integer,
    "intStudentFach6" integer,
    "intStudentFachsemester1" integer NOT NULL,
    "intStudentFachsemester2" integer,
    "intStudentFachsemester3" integer,
    "intStudentFachsemester4" integer,
    "intStudentFachsemester5" integer,
    "intStudentFachsemester6" integer,
    "strStudentStaat" character varying(254) DEFAULT ''::character varying,
    "lngStudentZUVZiel" integer,
    "strStudentBemerkung" "text" DEFAULT ''::"text",
    "dtmStudentZUVUpdate" "date",
    "strStudentGeburtsname" "text" DEFAULT ''::"text",
    "dtmStudentZUVImmatrikuliert" "date",
    "dtmStudentZUVAdd" "date",
    "blnStudentSelected" boolean,
    "strStudentUrlaub" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblBdStudent" OWNER TO "postgres";

--
-- TOC entry 177 (class 1259 OID 219402)
-- Dependencies: 6
-- Name: tblBdStudentAntrag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudentAntrag" (
    "lngStudentAntragID" integer NOT NULL,
    "lngSdSeminarID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "lngStudentAntragTypID" integer NOT NULL,
    "strStudentAntragBezeichnung" "text",
    "strStudentAntragBeschreibung" "text",
    "dtmStudentAntragDatum" "date" NOT NULL
);


ALTER TABLE "public"."tblBdStudentAntrag" OWNER TO "postgres";

--
-- TOC entry 178 (class 1259 OID 219408)
-- Dependencies: 6
-- Name: tblBdStudentAntragStatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudentAntragStatus" (
    "lngSdSeminarID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "lngDozentID" integer,
    "lngStudentAntragID" integer NOT NULL,
    "lngStudentAntragStatusID" integer NOT NULL,
    "lngStudentAntragStatusTypID" integer NOT NULL,
    "strStudentAntragStatusBezeichnung" "text",
    "strStudentAntragStatusBeschreibung" "text",
    "dtmStudentAntragStatusDatum" "date" NOT NULL,
    "blnStudentAntragStatusAbschluss" boolean
);


ALTER TABLE "public"."tblBdStudentAntragStatus" OWNER TO "postgres";

--
-- TOC entry 179 (class 1259 OID 219414)
-- Dependencies: 6 178
-- Name: tblBdStudentAntragStatus_lngStudentAntragStatusID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "tblBdStudentAntragStatus_lngStudentAntragStatusID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "public"."tblBdStudentAntragStatus_lngStudentAntragStatusID_seq" OWNER TO "postgres";

--
-- TOC entry 2822 (class 0 OID 0)
-- Dependencies: 179
-- Name: tblBdStudentAntragStatus_lngStudentAntragStatusID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "tblBdStudentAntragStatus_lngStudentAntragStatusID_seq" OWNED BY "tblBdStudentAntragStatus"."lngStudentAntragStatusID";


--
-- TOC entry 180 (class 1259 OID 219416)
-- Dependencies: 6
-- Name: tblBdStudentB_lngStudentBem_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "tblBdStudentB_lngStudentBem_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "public"."tblBdStudentB_lngStudentBem_seq" OWNER TO "postgres";

--
-- TOC entry 181 (class 1259 OID 219418)
-- Dependencies: 2147 2148 6
-- Name: tblBdStudentBemerkung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudentBemerkung" (
    "lngStudentBemerkungID" integer DEFAULT "nextval"(('"tblBdStudentB_lngStudentBem_seq"'::"text")::"regclass") NOT NULL,
    "lngSdSeminarID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "lngDozentID" integer NOT NULL,
    "strStudentBemerkungTag" character varying(50) NOT NULL,
    "strStudentBemerkungText" "text" DEFAULT ''::"text",
    "dtmStudentBemerkungDatum" "date" NOT NULL
);


ALTER TABLE "public"."tblBdStudentBemerkung" OWNER TO "postgres";

--
-- TOC entry 182 (class 1259 OID 219426)
-- Dependencies: 2149 2150 2151 6
-- Name: tblBdStudentDokument; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudentDokument" (
    "lngSdSeminarID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "dtmStudentDokumentDatum" "date" DEFAULT ('now'::"text")::"date",
    "strVerifikationscode" character varying(10) NOT NULL,
    "strDokument" "text",
    "strStudentDokumentName" "text" DEFAULT ''::"text",
    "blnStudentDokumentDauertranskript" boolean DEFAULT false
);


ALTER TABLE "public"."tblBdStudentDokument" OWNER TO "postgres";

--
-- TOC entry 183 (class 1259 OID 219442)
-- Dependencies: 2152 2153 2154 2155 6
-- Name: tblBdStudentPruefungDetail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudentPruefungDetail" (
    "lngSdSeminarID" integer NOT NULL,
    "lngSdPruefungsID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "intStudentPruefungCount" integer DEFAULT 0 NOT NULL,
    "lngLeistungsID" integer NOT NULL,
    "lngStudentLeistungCount" integer NOT NULL,
    "lngModulID" integer NOT NULL,
    "strCustom1" character varying(50) DEFAULT ''::character varying,
    "strCustom2" character varying(50) DEFAULT ''::character varying,
    "strCustom3" character varying(50) DEFAULT ''::character varying,
    "blnStudentLeistungPruefung" boolean,
    "sngStudentLeistungCreditPts" double precision
);


ALTER TABLE "public"."tblBdStudentPruefungDetail" OWNER TO "postgres";

--
-- TOC entry 184 (class 1259 OID 219456)
-- Dependencies: 2156 2157 2158 2159 2160 2161 2162 2163 2164 2165 2166 2167 2168 2169 2170 2171 2172 2173 2174 2175 2176 2177 2178 2179 6
-- Name: tblBdStudentXLeistung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudentXLeistung" (
    "lngSdSeminarID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "lngLeistungsID" integer NOT NULL,
    "lngStudentLeistungCount" integer NOT NULL,
    "lngDozentID" integer,
    "intNoteID" integer,
    "lngKlausuranmeldungKurstypID" integer,
    "lngKlausuranmeldungKursID" integer,
    "strSLKursUnivISID" character varying(50) DEFAULT ''::character varying,
    "strSLKursTag" character varying(50) DEFAULT ''::character varying,
    "dtmSLKursBeginn" time without time zone,
    "dtmSLKursEnde" time without time zone,
    "strSLKursRaum" character varying(5) DEFAULT ''::character varying,
    "strSLKursTag2" character varying(50) DEFAULT ''::character varying,
    "dtmSLKursBeginn2" time without time zone,
    "dtmSLKursEnde2" time without time zone,
    "strSLKursRaum2" character varying(5) DEFAULT ''::character varying,
    "strSLKursTitel" "text" DEFAULT ''::"text",
    "strSLKursTitel_en" "text" DEFAULT ''::"text",
    "strSLKursBeschreibung" "text" DEFAULT ''::"text",
    "strSLKursBeschreibung_en" "text" DEFAULT ''::"text",
    "strSLKursLiteratur" "text" DEFAULT ''::"text",
    "strSLKursZusatz" "text" DEFAULT ''::"text",
    "strSLKursAnmeldung" character varying(254) DEFAULT ''::character varying,
    "strSLKursVoraussetzung" "text" DEFAULT ''::"text",
    "blnSLKursSchein" boolean,
    "strSLKursEinordnung" character varying(50) DEFAULT ''::character varying,
    "intSLKursStunden" integer,
    "dtmSLKursLastChange" timestamp with time zone,
    "dtmSLKursScheinanmeldungBis" "date",
    "dtmSLKursScheinanmeldungVon" "date",
    "blnSLKursScheinanmeldungErlaubt" boolean,
    "strSLKursTerminFreitext" "text" DEFAULT ''::"text",
    "intSLKursTeilnehmer" integer,
    "strSLKursRaumExtern1" character varying(50) DEFAULT ''::character varying,
    "strSLKursRaumExtern2" character varying(50),
    "strSLKursDetails" "text" DEFAULT ''::"text",
    "strStudentLeistungDetails" "text" DEFAULT ''::"text",
    "blnStudentLeistungBestanden" boolean,
    "strStudentLeistungNote" character varying(25) DEFAULT ''::character varying,
    "sngStudentLeistungCreditPts" double precision,
    "dtmStudentLeistungAusstellungsd" "date",
    "strStudentLeistungAussteller" character varying(50),
    "strStudentLeistungBemerkung" "text" DEFAULT ''::"text",
    "blnStudentLeistungValidiert" boolean,
    "dtmStudentLeistungAntragdatum" "date",
    "blnStudentLeistungKlausuranmeldung" boolean,
    "blnStudentLeistungEditierbar" boolean,
    "blnStudentLeistungGesiegelt" boolean,
    "strStudentLeistungCustom1" "text" DEFAULT ''::"text",
    "strStudentLeistungCustom2" "text" DEFAULT ''::"text",
    "strStudentLeistungCustom3" "text" DEFAULT ''::"text",
    "blnStudentLeistungPruefung" boolean,
    "strStudentLeistungAusstellerVor" character varying(50),
    "strStudentLeistungAusstellerTit" character varying(50),
    "dtmStudentLeistungHISExport" "date",
    "dtmStudentLeistungHISVerified" "date",
    "lngModulID" integer,
    "lngStudentLeistungHISPrId" integer,
    "blnStudentLeistungAnerkannt" boolean DEFAULT false
);


ALTER TABLE "public"."tblBdStudentXLeistung" OWNER TO "postgres";

--
-- TOC entry 185 (class 1259 OID 219521)
-- Dependencies: 2180 2181 2182 2183 2184 2185 2186 2187 6
-- Name: tblBdStudentXPruefung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdStudentXPruefung" (
    "lngSdSeminarID" integer NOT NULL,
    "lngSdPruefungsID" integer NOT NULL,
    "strMatrikelnummer" character varying(8) NOT NULL,
    "intStudentPruefungCount" integer DEFAULT 0 NOT NULL,
    "intNoteID" integer,
    "strStudentPruefungNote" character varying(25) DEFAULT ''::character varying,
    "strStudentPruefungSemester" character varying(50) DEFAULT ''::character varying,
    "blnStudentPruefungZUVInformiert" boolean,
    "blnStudentPruefungValidiert" boolean,
    "blnStudentPruefungAnmeldung" boolean,
    "blnStudentPruefungGesiegelt" boolean,
    "blnStudentPruefungBestanden" boolean,
    "dtmStudentPruefungAusstellungsd" "date",
    "strStudentPruefungAussteller" character varying(255) DEFAULT ''::character varying,
    "strStudentPruefungRowIP" character varying(50) DEFAULT ''::character varying,
    "strStudentPruefungCustom1" "text" DEFAULT ''::"text",
    "strStudentPruefungCustom2" "text" DEFAULT ''::"text",
    "strStudentPruefungCustom3" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblBdStudentXPruefung" OWNER TO "postgres";

--
-- TOC entry 186 (class 1259 OID 219558)
-- Dependencies: 2188 2189 2190 2191 6
-- Name: tblBdTermin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblBdTermin" (
    "lngSeminarID" integer NOT NULL,
    "lngTerminID" integer NOT NULL,
    "dtmTerminDatum" "date" NOT NULL,
    "dtmTerminZeit" time without time zone NOT NULL,
    "strTerminOrt" "text" NOT NULL,
    "strTerminBeschreibung" "text" DEFAULT ''::"text",
    "strTerminAP" "text" DEFAULT ''::"text",
    "strTerminAPEmail" "text" DEFAULT ''::"text",
    "strTerminVerteiler" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblBdTermin" OWNER TO "postgres";

--
-- TOC entry 187 (class 1259 OID 219568)
-- Dependencies: 6
-- Name: tblInfo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblInfo" (
    "strVersion" character varying(50) NOT NULL,
    "dtmDatum" "date" NOT NULL,
    "strInfo" "text" NOT NULL,
    "strAutor" character varying(50) NOT NULL
);


ALTER TABLE "public"."tblInfo" OWNER TO "postgres";

--
-- TOC entry 188 (class 1259 OID 219619)
-- Dependencies: 6
-- Name: tblPostprocessing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblPostprocessing" (
    "strMatrikelnummer" character varying(7) NOT NULL,
    "strSQL" "text",
    "strUser" "text",
    "dtmDatum" "date",
    "strKommentar" "text"
);


ALTER TABLE "public"."tblPostprocessing" OWNER TO "postgres";

--
-- TOC entry 189 (class 1259 OID 219637)
-- Dependencies: 2192 2193 2194 2195 2196 2197 2198 2199 2200 2201 2202 2203 2204 2205 2206 2207 2208 2209 2210 2211 2212 2213 2214 2215 2216 2217 2218 2219 2220 2221 2222 2223 2224 6
-- Name: tblSdDozent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdDozent" (
    "lngSdSeminarID" integer NOT NULL,
    "lngDozentID" integer NOT NULL,
    "strDozentUnivISID" character varying(50) DEFAULT ''::character varying,
    "strDozentPasswort" "text" DEFAULT 'changeme'::character varying NOT NULL,
    "strDozentTitel" character varying(25) DEFAULT ''::character varying,
    "strDozentVorname" character varying(50) NOT NULL,
    "strDozentNachname" character varying(50) NOT NULL,
    "dtmDozentGebdatum" "date",
    "strDozentStellennr" character varying(25) DEFAULT ''::character varying,
    "strDozentTelefonPrivat" character varying(50) DEFAULT ''::character varying,
    "strDozentStrasse" character varying(254) DEFAULT ''::character varying,
    "strDozentPLZ" character varying(10) DEFAULT ''::character varying,
    "strDozentOrt" character varying(254) DEFAULT ''::character varying,
    "strDozentDienstendeMonat" character varying(5) DEFAULT ''::character varying,
    "strDozentDienstendeJahr" character varying(4) DEFAULT ''::character varying,
    "strDozentOD" character varying(50) DEFAULT ''::character varying,
    "strDozentVertragsart" character varying(10) DEFAULT ''::character varying,
    "strDozentBank" character varying(50) DEFAULT ''::character varying,
    "strDozentKto" character varying(50) DEFAULT ''::character varying,
    "strDozentBLZ" character varying(50) DEFAULT ''::character varying,
    "strDozentSprechstundeTag" character varying(25) DEFAULT ''::character varying,
    "dtmDozentSprechstundeDatum" "date",
    "dtmDozentSprechstundeZeitVon" time without time zone,
    "dtmDozentSprechstundeZeitBis" time without time zone,
    "strDozentSprechstunde" character varying(254) DEFAULT ''::character varying,
    "strDozentBau" character varying(50) DEFAULT ''::character varying,
    "strDozentZimmer" character varying(10) DEFAULT ''::character varying,
    "strDozentBereich" character varying(50) DEFAULT ''::character varying,
    "strDozentTelefon" character varying(25) DEFAULT ''::character varying,
    "strDozentEmail" character varying(50) DEFAULT ''::character varying,
    "strDozentHomepage" character varying(254) DEFAULT ''::character varying,
    "blnDozentLehrend" boolean,
    "strDozentBemerkung" character varying(254) DEFAULT ''::character varying,
    "strDozentAnrede" character varying(25) DEFAULT ''::character varying,
    "strDozentInteressen" "text" DEFAULT ''::"text",
    "dtmSprechstundeLastChange" timestamp with time zone,
    "strDozentPostfach" character varying(12) DEFAULT ''::character varying,
    "intDozentAccessLevel" integer DEFAULT 0 NOT NULL,
    "strDozentIP" character varying(30) DEFAULT ''::character varying,
    "lngDozentSessionID" integer,
    "dtmDozentLastAction" timestamp with time zone,
    "strDozentCertSubjectDN" "text" DEFAULT ''::"text",
    "strDozentCertIssuerDN" "text" DEFAULT ''::"text",
    "strDozentCertSerialID" character varying(50) DEFAULT ''::character varying,
    "blnDozentCertValidated" boolean,
    "blnDozentCertRevoked" boolean,
    "blnDozentExtern" boolean,
    "strDozentHomepageOptions" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblSdDozent" OWNER TO "postgres";

--
-- TOC entry 190 (class 1259 OID 219676)
-- Dependencies: 2225 2226 6
-- Name: tblSdFach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdFach" (
    "intFachID" integer NOT NULL,
    "strFachBezeichnung" character varying(80) NOT NULL,
    "strFachBeschreibung" "text" DEFAULT ''::"text",
    "strHN" character varying(255) DEFAULT ''::character varying,
    "strFachHISStg" character varying(10),
    "sngFachCreditPtsRequired" double precision,
    "strFachTranskriptName" "text",
    "strFachTranskriptName_en" "text"
);


ALTER TABLE "public"."tblSdFach" OWNER TO "postgres";

--
-- TOC entry 191 (class 1259 OID 219684)
-- Dependencies: 2227 2228 2229 6
-- Name: tblSdFakultaet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdFakultaet" (
    "lngSdUniID" integer NOT NULL,
    "lngSdFakultaetID" integer NOT NULL,
    "strFakultaetUnivISID" character varying(50) DEFAULT ''::character varying,
    "strFakultaetNr" integer DEFAULT 0,
    "strFakultaetName" character varying(50) NOT NULL,
    "strFakultaetLink" character varying(50) DEFAULT 'http://www.'::character varying
);


ALTER TABLE "public"."tblSdFakultaet" OWNER TO "postgres";

--
-- TOC entry 192 (class 1259 OID 219694)
-- Dependencies: 2230 2231 2232 2233 2234 2235 2236 2237 2238 2239 2240 2241 2242 2243 2244 2245 2246 2247 2248 6
-- Name: tblSdKurstyp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdKurstyp" (
    "lngSdSeminarID" integer NOT NULL,
    "lngKurstypID" integer NOT NULL,
    "strKurstypUnivISID" character varying(50) DEFAULT ''::character varying,
    "strKurstypBezeichnung" character varying(254) NOT NULL,
    "strKurstypBeschreibung" "text" DEFAULT ''::"text",
    "intKurstypSemesterMinimum" integer DEFAULT 0,
    "strKurstypEinordnung" character varying(22) DEFAULT ''::character varying,
    "blnKurstypFormularanmeldung" boolean,
    "blnKurstypKvvOnlyGrouped" boolean,
    "intKurstypSequence" integer DEFAULT 0,
    "lngKurstypLeistungsID" integer,
    "sngKurstypCreditPts" double precision DEFAULT 0,
    "intKurstypSemesterMin" integer DEFAULT 0,
    "intKurstypSemesterMax" integer DEFAULT 25,
    "blnKurstypTeilmodul" boolean,
    "blnKurstypVv" boolean,
    "strKurstypCustom1" "text" DEFAULT ''::"text",
    "strKurstypCustom2" "text" DEFAULT ''::"text",
    "strKurstypCustom3" "text" DEFAULT ''::"text",
    "strKurstypBezeichnung_en" character varying(254) DEFAULT ''::character varying,
    "strKurstypBeschreibung_en" "text" DEFAULT ''::"text",
    "strKurstypCustom1_en" "text" DEFAULT ''::"text",
    "strKurstypCustom2_en" "text" DEFAULT ''::"text",
    "strKurstypCustom3_en" "text" DEFAULT ''::"text",
    "intKurstypCommitmentMode" integer DEFAULT 0,
    "intKurstypKurswahlMin" integer,
    "intKurstypTauschMin" integer DEFAULT 5,
    "intKurstypTauschMax" integer DEFAULT 25
);


ALTER TABLE "public"."tblSdKurstyp" OWNER TO "postgres";

--
-- TOC entry 193 (class 1259 OID 219719)
-- Dependencies: 2249 2250 6
-- Name: tblSdKvvInhalt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdKvvInhalt" (
    "lngSdSeminarID" integer NOT NULL,
    "intSdKvvInhaltNr" integer NOT NULL,
    "strKvvInhaltHeading" character varying(50) NOT NULL,
    "strKvvInhaltHeadingDescription" "text" DEFAULT ''::"text",
    "intKvvInhaltHeadingSequence" integer,
    "strKvvInhaltTyp" character varying(5) DEFAULT ''::character varying
);


ALTER TABLE "public"."tblSdKvvInhalt" OWNER TO "postgres";

--
-- TOC entry 194 (class 1259 OID 219727)
-- Dependencies: 2251 2252 2253 6
-- Name: tblSdKvvInhaltXKurstyp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdKvvInhaltXKurstyp" (
    "lngSdSeminarID" integer NOT NULL,
    "intKvvInhaltNr" integer NOT NULL,
    "lngKurstypID" integer NOT NULL,
    "strCustom1" "text" DEFAULT ''::"text",
    "strCustom2" "text" DEFAULT ''::"text",
    "strCustom3" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblSdKvvInhaltXKurstyp" OWNER TO "postgres";

--
-- TOC entry 195 (class 1259 OID 219736)
-- Dependencies: 2254 2255 2256 2257 2258 2259 2260 2261 2262 6
-- Name: tblSdLeistung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdLeistung" (
    "lngSdSeminarID" integer NOT NULL,
    "lngLeistungID" integer NOT NULL,
    "strLeistungBezeichnung" character varying(200) NOT NULL,
    "strLeistungBezeichnung_en" character varying(200) DEFAULT ''::character varying,
    "strLeistungBeschreibung" "text" DEFAULT ''::"text",
    "strLeistungBeschreibung_en" "text" DEFAULT ''::"text",
    "strLeistungZuordnung" character varying(50) DEFAULT ''::character varying,
    "sngLeistungCreditPts" double precision DEFAULT 0,
    "strLeistungCustom1" "text" DEFAULT ''::"text",
    "strLeistungCustom2" "text" DEFAULT ''::"text",
    "strLeistungCustom3" "text" DEFAULT ''::"text",
    "intLeistungCommitmentMode" integer DEFAULT 0
);


ALTER TABLE "public"."tblSdLeistung" OWNER TO "postgres";

--
-- TOC entry 196 (class 1259 OID 219751)
-- Dependencies: 2263 2264 2265 2266 2267 2268 2269 2270 2271 2272 2273 2274 2275 6
-- Name: tblSdModul; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdModul" (
    "lngSdSeminarID" integer NOT NULL,
    "lngModulID" integer NOT NULL,
    "strModulBezeichnung" character varying(255) NOT NULL,
    "strModulBeschreibung" "text" DEFAULT ''::"text",
    "lngModulNummer" integer,
    "strModulEinordnung" character varying(50) DEFAULT ''::character varying,
    "intModulSemester" integer,
    "intModulSemesterMin" integer DEFAULT 0,
    "intModulSemesterMax" integer DEFAULT 25,
    "strModulCustom1" "text" DEFAULT ''::"text",
    "strModulCustom2" "text" DEFAULT ''::"text",
    "strModulCustom3" "text" DEFAULT ''::"text",
    "strModulBezeichnung_en" character varying(150) DEFAULT ''::character varying,
    "strModulBeschreibung_en" "text" DEFAULT ''::"text",
    "strModulCustom1_en" "text" DEFAULT ''::"text",
    "strModulCustom2_en" "text" DEFAULT ''::"text",
    "strModulCustom3_en" "text" DEFAULT ''::"text",
    "blnModulWaehlbar" boolean,
    "blnModulVarLP" boolean DEFAULT false
);


ALTER TABLE "public"."tblSdModul" OWNER TO "postgres";

--
-- TOC entry 197 (class 1259 OID 219770)
-- Dependencies: 2276 2277 2278 2279 2280 2281 2282 6
-- Name: tblSdModulXLeistung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdModulXLeistung" (
    "lngSdSeminarID" integer NOT NULL,
    "lngModulID" integer NOT NULL,
    "lngLeistungID" integer NOT NULL,
    "sngMinCreditPts" double precision DEFAULT 0,
    "strCustom1" "text" DEFAULT ''::"text",
    "strCustom2" "text" DEFAULT ''::"text",
    "strCustom3" "text" DEFAULT ''::"text",
    "strCustom1_en" "text" DEFAULT ''::"text",
    "strCustom2_en" "text" DEFAULT ''::"text",
    "strCustom3_en" "text" DEFAULT ''::"text",
    "blnModulLeistungTranskript" boolean
);


ALTER TABLE "public"."tblSdModulXLeistung" OWNER TO "postgres";

--
-- TOC entry 198 (class 1259 OID 219783)
-- Dependencies: 2283 2284 2285 2286 2287 2288 6
-- Name: tblSdNote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdNote" (
    "lngSdSeminarID" integer NOT NULL,
    "intNoteID" integer NOT NULL,
    "strNoteNameDE" character varying(50) NOT NULL,
    "sngNoteWertDE" double precision NOT NULL,
    "strNoteECTSGrade" character varying(50) DEFAULT ''::character varying,
    "strNoteECTSDefinition" character varying(50) DEFAULT ''::character varying,
    "sngNoteECTSCalc" double precision DEFAULT 0 NOT NULL,
    "blnNoteBestanden" boolean NOT NULL,
    "strNoteCustom1" "text" DEFAULT ''::"text",
    "strNoteCustom2" "text" DEFAULT ''::"text",
    "strNoteCustom3" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblSdNote" OWNER TO "postgres";

--
-- TOC entry 199 (class 1259 OID 219795)
-- Dependencies: 6
-- Name: tblSdNutzer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdNutzer" (
    "strNutzerUniID" character varying(10) NOT NULL,
    "strNutzerVorname" "text",
    "strNutzerNachname" "text",
    "strNutzerEmail" "text",
    "strNutzerTelefon" "text",
    "strNutzerTitel" character varying(50),
    "strNutzerInstitut" "text",
    "intNutzerLevel" integer
);


ALTER TABLE "public"."tblSdNutzer" OWNER TO "postgres";

--
-- TOC entry 200 (class 1259 OID 219801)
-- Dependencies: 2289 2290 2291 2292 2293 2294 2295 2296 2297 2298 2299 2300 2301 6
-- Name: tblSdPruefung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdPruefung" (
    "lngSdSeminarID" integer NOT NULL,
    "lngPruefungID" integer NOT NULL,
    "strPruefungBezeichnung" character varying(50) NOT NULL,
    "strPruefungBeschreibung" "text" DEFAULT ''::"text",
    "strPruefungFach" character varying(50) DEFAULT ''::character varying,
    "strPruefungAbschluss" character varying(25) DEFAULT ''::character varying,
    "strPruefungsordnung" character varying(254) DEFAULT ''::character varying,
    "blnPruefungHauptfach" boolean,
    "strPruefungZUVAmt" character varying(7) DEFAULT '1125002'::character varying NOT NULL,
    "strPruefungZUVFach" character varying(4) NOT NULL,
    "strPruefungZUVTyp" character varying(3) NOT NULL,
    "sngPruefungMinCreditPts" double precision DEFAULT 0,
    "blnPruefungECTSGewicht" boolean,
    "strPruefungBezeichnung_en" character varying(50) DEFAULT ''::character varying,
    "strPruefungBeschreibung_en" "text" DEFAULT ''::"text",
    "strPruefungFach_en" character varying(50) DEFAULT ''::character varying,
    "strPruefungAbschluss_en" character varying(25) DEFAULT ''::character varying,
    "strPruefungCustom1" "text" DEFAULT ''::"text",
    "strPruefungCustom2" "text" DEFAULT ''::"text",
    "strPruefungCustom3" "text" DEFAULT ''::"text",
    "blnPruefungTriggered" boolean
);


ALTER TABLE "public"."tblSdPruefung" OWNER TO "postgres";

--
-- TOC entry 201 (class 1259 OID 219820)
-- Dependencies: 2302 2303 2304 2305 6
-- Name: tblSdPruefungAblauf; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdPruefungAblauf" (
    "lngSdSeminarID" integer NOT NULL,
    "lngPruefungID" integer NOT NULL,
    "lngAblaufID" integer NOT NULL,
    "strPruefungAblaufBezeichnung" character varying(50) NOT NULL,
    "strPruefungAblaufBeschreibung" "text" DEFAULT ''::"text",
    "blnPruefungAblaufPrereq" boolean,
    "blnPruefungAblaufStudentinfo" boolean,
    "strCustom1" character varying(50) DEFAULT ''::character varying,
    "strCustom2" character varying(50) DEFAULT ''::character varying,
    "strCustom3" character varying(50) DEFAULT ''::character varying
);


ALTER TABLE "public"."tblSdPruefungAblauf" OWNER TO "postgres";

--
-- TOC entry 202 (class 1259 OID 219830)
-- Dependencies: 2306 2307 2308 2309 2310 6
-- Name: tblSdPruefungRegel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdPruefungRegel" (
    "lngSdSeminarID" integer NOT NULL,
    "lngPruefungID" integer NOT NULL,
    "lngRegelID" integer NOT NULL,
    "strPruefungRegelBezeichnung" character varying(255) DEFAULT ''::character varying NOT NULL,
    "strPruefungRegelBeschreibung" "text" DEFAULT ''::"text",
    "strCustom1" "text" DEFAULT ''::"text",
    "strCustom2" "text" DEFAULT ''::"text",
    "strCustom3" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblSdPruefungRegel" OWNER TO "postgres";

--
-- TOC entry 203 (class 1259 OID 219841)
-- Dependencies: 2311 2312 2313 6
-- Name: tblSdPruefungRegelDetail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdPruefungRegelDetail" (
    "lngSdSeminarID" integer NOT NULL,
    "lngPruefungID" integer NOT NULL,
    "lngRegelID" integer NOT NULL,
    "lngLeistungsID" integer NOT NULL,
    "lngModulID" integer NOT NULL,
    "strCustom1" character varying(50) DEFAULT ''::character varying,
    "strCustom2" character varying(50) DEFAULT ''::character varying,
    "strCustom3" character varying(50) DEFAULT ''::character varying
);


ALTER TABLE "public"."tblSdPruefungRegelDetail" OWNER TO "postgres";

--
-- TOC entry 204 (class 1259 OID 219847)
-- Dependencies: 2314 6
-- Name: tblSdPruefungXFach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdPruefungXFach" (
    "lngSdSeminarID" integer NOT NULL,
    "lngPruefungID" integer NOT NULL,
    "intFachID" integer NOT NULL,
    "strBemerkung" "text" DEFAULT ''::"text",
    "blnPruefungFachAbschluss" boolean
);


ALTER TABLE "public"."tblSdPruefungXFach" OWNER TO "postgres";

--
-- TOC entry 205 (class 1259 OID 219854)
-- Dependencies: 2315 2316 2317 2318 2319 2320 2321 6
-- Name: tblSdPruefungXModul; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdPruefungXModul" (
    "lngSdSeminarID" integer NOT NULL,
    "lngPruefungID" integer NOT NULL,
    "lngModulID" integer NOT NULL,
    "sngPruefungLeistungGewichtung" double precision,
    "sngMinCreditPts" double precision,
    "strCustom1" "text" DEFAULT ''::"text",
    "strCustom2" "text" DEFAULT ''::"text",
    "strCustom3" "text" DEFAULT ''::"text",
    "strCustom1_en" "text" DEFAULT ''::"text",
    "strCustom2_en" "text" DEFAULT ''::"text",
    "strCustom3_en" "text" DEFAULT ''::"text",
    "sngMinCreditPtsPLeistung" double precision,
    "sngMinCreditPtsSLeistung" double precision,
    "blnZulassungsvoraussetzung" boolean,
    "lngPruefungModulSequence" bigint DEFAULT 0
);


ALTER TABLE "public"."tblSdPruefungXModul" OWNER TO "postgres";

--
-- TOC entry 206 (class 1259 OID 219867)
-- Dependencies: 2322 6
-- Name: tblSdPruefungXPruefung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdPruefungXPruefung" (
    "lngSdSeminarID" integer NOT NULL,
    "lngPruefungID" integer NOT NULL,
    "lngPruefungPrereqID" integer NOT NULL,
    "strPruefungBemerkung" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblSdPruefungXPruefung" OWNER TO "postgres";

--
-- TOC entry 207 (class 1259 OID 219874)
-- Dependencies: 2323 2324 6
-- Name: tblSdRaum; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdRaum" (
    "lngSdSeminarID" integer NOT NULL,
    "strRaumBezeichnung" character varying(5) NOT NULL,
    "strRaumBeschreibung" "text" DEFAULT ''::"text",
    "strRaumUnivISID" character varying(50) DEFAULT ''::character varying
);


ALTER TABLE "public"."tblSdRaum" OWNER TO "postgres";

--
-- TOC entry 208 (class 1259 OID 219882)
-- Dependencies: 2325 2326 2327 2328 2329 2330 6
-- Name: tblSdSeminar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdSeminar" (
    "lngUniID" integer NOT NULL,
    "lngFakultaetID" integer NOT NULL,
    "lngSeminarID" integer NOT NULL,
    "strSeminarUnivISID" character varying(50) DEFAULT ''::character varying,
    "strSeminarName" character varying(50) NOT NULL,
    "strSeminarLink" character varying(50) DEFAULT 'http://www.'::character varying,
    "strSeminarCustom1" "text" DEFAULT ''::"text",
    "strSeminarCustom2" "text" DEFAULT ''::"text",
    "strSeminarCustom3" "text" DEFAULT ''::"text",
    "strSeminarShort" character varying(5) DEFAULT ''::character varying,
    "blnSeminarNoteCboLocal" boolean
);


ALTER TABLE "public"."tblSdSeminar" OWNER TO "postgres";

--
-- TOC entry 209 (class 1259 OID 219894)
-- Dependencies: 2331 6
-- Name: tblSdSeminarXFach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdSeminarXFach" (
    "lngSeminarID" integer NOT NULL,
    "intFachID" integer NOT NULL,
    "strSdSeminarXFachBemerkung" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."tblSdSeminarXFach" OWNER TO "postgres";

--
-- TOC entry 210 (class 1259 OID 219913)
-- Dependencies: 2332 6
-- Name: tblSdUni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tblSdUni" (
    "lngSdUniID" integer NOT NULL,
    "strUniName" character varying(50) NOT NULL,
    "strUniOrt" character varying(50) NOT NULL,
    "strUniLink" character varying(50) DEFAULT 'http://www.'::character varying
);


ALTER TABLE "public"."tblSdUni" OWNER TO "postgres";

--
-- TOC entry 211 (class 1259 OID 219917)
-- Dependencies: 6
-- Name: tmpDays; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "tmpDays" (
    "strTag" character varying(10),
    "intSort" integer
);


ALTER TABLE "public"."tmpDays" OWNER TO "postgres";

--
-- TOC entry 2146 (class 2604 OID 219924)
-- Dependencies: 179 178
-- Name: lngStudentAntragStatusID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentAntragStatus" ALTER COLUMN "lngStudentAntragStatusID" SET DEFAULT "nextval"('"tblBdStudentAntragStatus_lngStudentAntragStatusID_seq"'::"regclass");


--
-- TOC entry 2761 (class 0 OID 219173)
-- Dependencies: 163 2810
-- Data for Name: tblBdAnmeldung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdAnmeldung" ("lngSdSeminarID", "strMatrikelnummer", "lngKursID", "lngKurstypID", "intAnmeldungPrioritaet", "lngAnmeldungRandom", "blnAnmeldungZuschlag", "dtmAnmeldungDatum", "blnAnmeldungFixiert") FROM stdin;
\.


--
-- TOC entry 2762 (class 0 OID 219176)
-- Dependencies: 164 2810
-- Data for Name: tblBdAnmeldungSwap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdAnmeldungSwap" ("lngSdSeminarID", "strMatrikelnummer", "lngKursID", "lngKurstypID", "lngKursIDWunsch", "blnAnmeldungSwapZuschlag", "dtmAnmeldungSwapDatum", "lngKurstypIDWunsch") FROM stdin;
\.


--
-- TOC entry 2760 (class 0 OID 219157)
-- Dependencies: 161 2810
-- Data for Name: tblBdData; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdData" ("lngSdSeminarID", "strSemesterbezeichnung", "dtmSignUpStart", "dtmSignUpStop", "blnHttpserverAktiv", "blnHttpShowResults", "blnAllowRegistration") FROM stdin;
1	ws2014/2015	2014-09-15	2014-10-09	f	t	0
\.


--
-- TOC entry 2763 (class 0 OID 219187)
-- Dependencies: 165 2810
-- Data for Name: tblBdDozentBemerkung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdDozentBemerkung" ("lngDozentBemerkungID", "lngSdSeminarID", "lngDozentID", "strDozentBemerkungTag", "strDozentBemerkungText", "dtmDozentBemerkungDatum", "dtmDozentBemerkungWv") FROM stdin;
\.


--
-- TOC entry 2825 (class 0 OID 0)
-- Dependencies: 166
-- Name: tblBdDozent_lngStudentBem_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"tblBdDozent_lngStudentBem_seq"', 1, false);


--
-- TOC entry 2765 (class 0 OID 219244)
-- Dependencies: 167 2810
-- Data for Name: tblBdKurs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdKurs" ("lngSdSeminarID", "lngKursID", "strKursUnivISID", "lngDozentID", "strKursTag", "dtmKursBeginn", "dtmKursEnde", "strKursRaum", "strKursTag2", "dtmKursBeginn2", "dtmKursEnde2", "strKursRaum2", "intKursTeilnehmerMaximal", "lngKursRequests", "strKursTitel", "strKursTitel_en", "strKursBeschreibung", "strKursBeschreibung_en", "strKursLiteratur", "strKursZusatz", "strKursAnmeldung", "strKursVoraussetzung", "blnKursSchein", "strKursEinordnung", "intKursStunden", "dtmKursLastChange", "dtmKursScheinanmeldungBis", "dtmKursScheinanmeldungVon", "blnKursScheinanmeldungErlaubt", "intKursSequence", "blnKursPlanungssemester", "strKursTerminFreitext", "intKursTeilnehmer", "strKursRaumExtern1", "strKursRaumExtern2", "strKursCustom1", "strKursCustom2", "strKursCustom3", "sngKursCreditPts") FROM stdin;
1	15146	null	23	Donnerstag	14:15:00	15:45:00	113		\N	\N	\N	0	0	Darlegung und Argumentation	Exposition and Argumentation	--	No English description available	--			--	f		0	2014-07-02 00:00:00+02	2015-01-23	2014-12-01	t	0	f		26						0
1	15118	null	113	Mittwoch	11:15:00	12:45:00	113		\N	\N	\N	0	0	Spätneuenglisch	Late Modern English	--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	2015-01-23	2014-12-01	t	10	f		23						0
1	15213	null	29	Mittwoch	11:15:00	12:45:00	\N		\N	\N	\N	0	0	Einführungs Sprachwissenschaft	Introduction to Linguistics	--	No English description available	--			--	f		0	2014-09-02 00:00:00+02	2015-01-23	2014-12-01	t	0	f		127	Heuscheuer I					0
1	15120	null	113	Montag	11:15:00	12:45:00	113		\N	\N	\N	0	0	Varietäten des Englischen: Fokus auf Südafrika	Varieties of English: Focus on South Africa	--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	2015-01-23	2014-12-01	t	40	f		23						0
1	15320	null	113	Montag	14:15:00	15:45:00	\N		\N	\N	\N	0	0	 Einführung in die englische Phonologie und Phonetik	Introduction to English Phonology and Phonetics	--	No English description available	--			--	f		0	2014-11-20 00:00:00+01	2015-01-23	2014-12-01	t	0	t		0	Hörsaal					0
1	15140	null	23	Montag	16:15:00	17:45:00	122		\N	\N	\N	0	0	Übersetzungen ins Englische (Klausur I)		--	No English description available	--			--	f		0	2014-05-12 00:00:00+02	\N	\N	t	0	f		34						0
1	15141	null	23	Montag	14:15:00	15:45:00	122		\N	\N	\N	0	0	Übersetzungen ins Englische (Klausur I)		--	No English description available	--			--	f		0	2014-05-12 00:00:00+02	\N	\N	t	0	f		34						0
1	15045	null	8	Donnerstag	09:15:00	10:45:00	122		\N	\N	\N	0	0	 Darstellende und Narrative Texte	Description and Narration	--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	2015-01-23	2014-12-01	t	600	f		16						0
1	15164	null	46	Donnerstag	14:15:00	15:45:00	108		\N	\N	\N	0	0	Trust and Suspicion: American Literature and the Emotional Foundations of Democracy	Trust and Suspicion: American Literature and the Emotional Foundations of Democracy	--	No English description available	--			--	f		0	2014-06-23 00:00:00+02	2015-01-23	2014-12-01	t	50	f		16						0
1	15376	null	46	Donnerstag	14:15:00	15:45:00	108		\N	\N	\N	0	0	American Novelists Review the Twentieth Century	American Novelists Review the Twentieth Century	--	No English description available	--			--	f		0	2015-01-03 00:00:00+01	2015-01-23	2014-12-01	t	40	t		0						0
1	15050	null	39	Dienstag	09:15:00	10:45:00	116		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte	Writing/Essential Skills for Writing	--	No English description available	--			--	f		0	2014-06-18 00:00:00+02	2015-01-23	2014-12-01	t	100	f		28						0
1	15377	null	46	Dienstag	16:15:00	17:45:00	112		\N	\N	\N	0	0	Examenskolloquium	Preparing for the Final Exam	--	No English description available	--			--	f		0	2014-12-25 00:00:00+01	\N	\N	f	500	t		0						0
1	15044	null	8	Dienstag	11:15:00	12:45:00	122		\N	\N	\N	0	0	 Wiederholungskurs Zeit und Aspekt	Tense and Aspect for Repeat Students	--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	2015-01-23	2014-12-30	t	0	f		24						0
1	15053	null	39	Freitag	09:15:00	10:45:00	122		\N	\N	\N	0	0	 Zeit und Aspekt	Tense & Aspect	--	No English description available	--			--	f		0	2014-09-10 00:00:00+02	2015-01-23	2014-12-01	t	400	f		40						0
1	15238	null	8	Dienstag	13:15:00	14:00:00	122		\N	\N	\N	0	0	 Begleitkurs zum PS: Einführung in das wissenschaftliche Arbeiten und Schreiben	Fundamentals of Research and Writing	--	No English description available	--			--	f		0	2014-06-24 00:00:00+02	2015-01-23	2014-12-01	t	0	f		15						0
1	15163	null	46	Mittwoch	11:15:00	12:45:00	108		\N	\N	\N	0	0	The American Novel: Beginnings to 1900 	The American Novel: Beginnings to 1900	--	No English description available	--			--	f		0	2014-07-01 00:00:00+02	2015-01-23	2014-12-01	t	500	f		61						0
1	15056	null	39	Freitag	11:15:00	12:45:00	116		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte	Writing/Essential Skills for Writing	--	No English description available	--			--	f		0	2014-06-18 00:00:00+02	2015-01-23	2014-12-01	t	500	f		28						0
1	15046	null	8	Donnerstag	11:15:00	12:45:00	122		\N	\N	\N	0	0	 Darstellende und Narrative Texte	Description and Narration	--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	2015-01-23	2014-12-01	t	700	f		21						0
1	15142	null	23	Dienstag	11:15:00	12:45:00	116		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte		--	No English description available	--			--	f		0	2014-04-30 00:00:00+02	2015-01-23	2014-12-01	t	200	f		26						0
1	15116	null	29	Donnerstag	11:15:00	12:45:00	110		\N	\N	\N	0	0	Examenskolloquium	Exam Colloquium	--	No English description available	--			--	f		0	2014-06-17 00:00:00+02	\N	\N	t	0	f		43						0
1	15143	null	23	Dienstag	14:15:00	15:45:00	116		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte		--	No English description available	--			--	f		0	2014-04-30 00:00:00+02	2015-01-23	2014-12-01	t	300	f		29						0
1	15145	null	23	Donnerstag	11:15:00	12:45:00	113		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte		--	No English description available	--			--	f		0	2014-04-30 00:00:00+02	2015-01-23	2014-12-01	t	400	f		28						0
1	15144	null	23	Dienstag	16:15:00	17:45:00	116		\N	\N	\N	0	0	Zeit und Aspekt		--	No English description available	--			--	f		0	2014-04-30 00:00:00+02	2015-01-23	2014-12-01	t	300	f		35						0
1	15277	null	8	Montag	09:15:00	11:45:00	110		\N	\N	\N	0	0	Das amerikanische Musical	The American Musical	--	No English description available	--			--	f		0	2014-12-16 00:00:00+01	2015-01-23	2014-12-01	t	20	t		0						0
1	15247	null	25	Freitag	11:00:00	12:30:00	115		\N	\N	\N	0	0	Übung SPDE	SPDE Exercises	--	No English description available	--			--	f		0	2014-06-30 00:00:00+02	\N	\N	t	0	f		0						0
1	15115	null	29	Dienstag	16:15:00	17:45:00	108		\N	\N	\N	0	0	 Linguistic (Im-)Politeness on- and off-line	 Linguistic (Im-)Politeness on- and off-line	--	No English description available	--			--	f		0	2014-07-01 00:00:00+02	2015-01-23	2014-12-01	t	30	f		30						0
1	15428	null	25	Montag	09:15:00	10:45:00	114		\N	\N	\N	0	0	Einführung ins Frühneuenglische	Introduction to Early Modern English	--	No English description available	--			--	f		0	2014-12-23 00:00:00+01	\N	\N	f	0	t		0						0
1	15431	null	25	Freitag	11:00:00	12:30:00	115		\N	\N	\N	0	0	Übungen SPDE	Tutorial SPDE	--	No English description available	--			--	f		0	2014-12-17 00:00:00+01	\N	\N	f	0	t		0						0
1	15191	null	84	Mittwoch	11:15:00	12:45:00	112		\N	\N	\N	0	0	Examenskolloquium	Colloquium for Exam Candidates	--	No English description available	--			--	f		0	2014-07-01 00:00:00+02	\N	\N	t	0	f		40						0
1	15429	null	25	Donnerstag	09:15:00	10:45:00	115		\N	\N	\N	0	0	Konstruktionsgrammatik	Construction Grammar	--	No English description available	--			--	f		0	2015-01-08 00:00:00+01	\N	\N	f	20	t		0						0
1	15047	null	8	Montag	09:15:00	12:45:00	110		\N	\N	\N	0	0	Star Trek	Star Trek: Rewriting the Past in the Future	--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	2015-01-23	2014-12-01	t	800	f		18						0
1	15114	null	84	Dienstag	11:15:00	12:45:00	110		\N	\N	\N	0	0	British Literature from the Renaissance to the Present: An Overview	British Literature from the Renaissance to the Present: An Overview	--	No English description available	--			--	f		0	2014-07-01 00:00:00+02	2015-01-23	2014-12-01	t	200	f		75						0
1	15119	null	113	Mittwoch	09:15:00	10:45:00	113		\N	\N	\N	0	0	Examenskolloquium		--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	\N	\N	t	0	f		19						0
1	15274	null	8	Donnerstag	11:15:00	12:45:00	122		\N	\N	\N	0	0	Darstellende und Narrative Texte	Description and Narration	--	No English description available	--			--	f		0	2014-09-07 00:00:00+02	2015-01-23	2014-12-01	t	400	t		0						0
1	15273	null	8	Donnerstag	09:15:00	10:45:00	122		\N	\N	\N	0	0	Darstellende und Narrative Texte	Description and Narration	--	No English description available	--			--	f		0	2014-09-07 00:00:00+02	2015-01-23	2014-12-01	t	200	t		0						0
1	15285	null	39	Dienstag	09:15:00	10:45:00	116		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte	Essential Skills for Writing	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	2015-01-23	2014-12-01	t	300	t		0						0
1	15275	null	8	Dienstag	09:15:00	10:45:00	122		\N	\N	\N	0	0	Wiederholungskurs Zeit und Aspekt	Tense and Aspect for Repeat Students	--	No English description available	--			--	f		0	2014-12-16 00:00:00+01	2015-01-23	2014-12-30	t	100	t		0						0
1	15286	null	39	Freitag	11:15:00	12:45:00	122		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte	Essential Skills for Writing	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	2015-01-23	2014-12-01	t	600	t		0						0
1	15276	null	8	Dienstag	11:15:00	12:45:00	122		\N	\N	\N	0	0	Wiederholungskurs Zeit und Aspekt	Tense and Aspect for Repeat Students	--	No English description available	--			--	f		0	2014-12-16 00:00:00+01	2015-01-23	2014-12-30	t	200	t		0						0
1	15278	null	8	Dienstag	13:15:00	14:00:00	122		\N	\N	\N	0	0	Begleitkurs zum PS: Einführung in das wissenschaftliche Arbeiten und Schreiben	Fundamentals of Research and Writing	--	No English description available	--			--	f		0	2014-12-16 00:00:00+01	2015-01-23	2014-12-01	t	300	t		0						0
1	15321	null	113	Montag	11:15:00	12:45:00	113		\N	\N	\N	0	0	Kontrastive Linguistik	Contrastive Linguistics	--	No English description available	--			--	f		0	2014-11-20 00:00:00+01	2015-01-23	2014-12-01	t	20	t		0						0
1	15318	null	113	Mittwoch	09:15:00	10:45:00	113		\N	\N	\N	0	0	Kolloquium für Examenskandidaten	Colloquium for Exam Candidates	--	No English description available	--			--	f		0	2014-11-20 00:00:00+01	\N	\N	f	400	t		0						0
1	15338	null	23	Montag	14:15:00	15:45:00	122		\N	\N	\N	0	0	Übersetzungen ins Englische (Klausur I)	Translation into English for Exam Candidates	--	No English description available	--			--	f		0	2014-10-11 00:00:00+02	\N	\N	f	100	t		0						0
1	15279	null	8	Donnerstag	13:15:00	14:00:00	122		\N	\N	\N	0	0	Begleitkurs zum PS: Einführung in das wissenschaftliche Arbeiten und Schreiben	Fundamentals of Research and Writing	--	No English description available	--			--	f		0	2014-12-16 00:00:00+01	2015-01-23	2014-12-01	t	600	t		0						0
1	15340	null	23	Dienstag	11:15:00	12:45:00	116		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte	Essential Skills for Writing	--	No English description available	--			--	f		0	2014-10-31 00:00:00+01	2015-01-23	2014-12-01	t	400	t		0						0
1	15343	null	23	Dienstag	16:15:00	17:45:00	122		\N	\N	\N	0	0	Zeit und Aspekt	Tense and Aspect	--	No English description available	--			--	f		0	2014-10-31 00:00:00+01	2015-01-23	2014-12-01	t	100	t		0						0
1	15339	null	23	Montag	16:15:00	17:45:00	122		\N	\N	\N	0	0	Übersetzungen ins Englische (Klausur I)	Translation into English for Exam Candidates	--	No English description available	--			--	f		0	2014-10-11 00:00:00+02	\N	\N	f	200	t		0						0
1	15344	null	23	Donnerstag	14:15:00	15:45:00	116		\N	\N	\N	0	0	Preparation Course for Assistant Teachers		--	No English description available	--			--	f		0	2014-12-08 00:00:00+01	\N	\N	f	0	t		0						0
1	15341	null	23	Dienstag	14:15:00	15:45:00	122		\N	\N	\N	0	0	Grundkenntnisse im Verfassen englischer Texte	Essential Skills for Writing	--	No English description available	--			--	f		0	2014-10-11 00:00:00+02	2015-01-23	2014-12-01	t	500	t		0						0
1	15342	null	23	Donnerstag	11:15:00	12:45:00	114		\N	\N	\N	0	0	Exposition and Argumentation		--	No English description available	--			--	f		0	2014-12-08 00:00:00+01	2015-01-23	2014-12-01	t	300	t		0						0
1	15028	null	25	Freitag	11:15:00	12:45:00	115		\N	\N	\N	0	0	Übung SPDE	SPDE Exercises	--	No English description available	--			--	f		0	2014-01-05 00:00:00+01	\N	\N	t	0	f		40						0
1	15283	null	39	Dienstag	11:15:00	12:45:00	108		\N	\N	\N	0	0	Übersetzungen Deutsch-Englisch	Translation German-English	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	\N	\N	f	400	t		0						0
1	15284	null	39	Donnerstag	11:15:00	12:45:00	108		\N	\N	\N	0	0	Geteilte Geschichte(n) - Deutsch-Irische Beziehungen über die Jarhunderte	Shared Histories - Irish-German Relations Through the Ages	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	2015-01-23	2014-12-01	t	20	t		0						0
1	15395	null	84	Mittwoch	11:15:00	12:45:00	116		\N	\N	\N	0	0	Gothic Fiction im 18. und 19. Jahrhundert	Gothic Fiction in the Eighteenth and Nineteenth Century	--	No English description available	--			--	f		0	2014-11-20 00:00:00+01	2015-01-23	2014-12-01	t	20	t		0						0
1	15287	null	39	Donnerstag	09:15:00	10:45:00	116		\N	\N	\N	0	0	 Wortschatz im Einsatz	Vocabulary and Idiom	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	2015-01-23	2014-12-01	t	10	t		0						0
1	15248	null	25	Dienstag	18:15:00	19:45:00	108		\N	\N	\N	0	0	Die Struktur des Gegenwartsenglischen	The Structure of Present-Day English	--	No English description available	--			--	f		0	2014-07-01 00:00:00+02	\N	\N	t	0	f		78						0
1	15430	null	25	Dienstag	18:00:00	19:30:00	108		\N	\N	\N	0	0	Die Struktur des Gegenwartsenglischen	The Structure of Present-Day English	--	No English description available	--			--	f		0	2014-12-23 00:00:00+01	\N	\N	f	300	t		0						0
1	15375	null	46	Mittwoch	11:15:00	12:45:00	108		\N	\N	\N	0	0	American Fictions of Violence	American Fictions of Violence	--	No English description available	--			--	f		0	2014-12-25 00:00:00+01	2015-01-23	2014-12-01	t	40	t		0						0
1	15379	null	29	Mittwoch	11:15:00	12:45:00	\N		\N	\N	\N	0	0	Einführung in die Sprachwissenschaft	Introduction to Linguistics	--	No English description available	--			--	f		0	2014-12-17 00:00:00+01	2015-01-23	2014-12-01	t	0	t		0	Heuscheuer I					0
1	15385	null	29	Donnerstag	14:15:00	15:45:00	110		\N	\N	\N	0	0	Linguistische Genderstudien	Linguistic Gender Studies	--	No English description available	--			--	f		0	2014-12-18 00:00:00+01	2015-01-23	2014-12-01	t	50	t		0						0
1	15389	null	26	Mittwoch	11:15:00	12:45:00	112		\N	\N	\N	0	0	American Cyborgs	American Cyborgs	--	No English description available	--			--	f		0	2015-01-05 00:00:00+01	2015-01-23	2014-12-01	t	50	t		0						0
1	15380	null	29	Mittwoch	18:15:00	19:45:00	108		\N	\N	\N	0	0	Forschungskolloquium	Research Colloquium	--	No English description available	--			--	f		0	2014-12-17 00:00:00+01	\N	\N	f	500	t		0						0
1	15381	null	29	Donnerstag	11:15:00	12:45:00	110		\N	\N	\N	0	0	Examenskolloquium	Exam Colloquium	--	No English description available	--			--	f		0	2014-12-17 00:00:00+01	\N	\N	f	600	t		0						0
1	15052	null	39	Dienstag	16:15:00	17:45:00	122		\N	\N	\N	0	0	Darlegung und Argumentation	Exposition and Argumentation	--	No English description available	--			--	f		0	2014-06-18 00:00:00+02	2015-01-23	2014-12-01	t	450	f		23						0
1	15319	null	113	Mittwoch	11:15:00	12:45:00	113		\N	\N	\N	0	0	Zweitspracherwerb	Second Language Acquisition	--	No English description available	--			--	f		0	2014-11-20 00:00:00+01	2015-01-23	2014-12-01	t	30	t		0						0
1	15396	null	84	Montag	11:15:00	12:45:00	\N		\N	\N	\N	0	0	Einführung in die Englische Literaturwissenschaft	Introduction to the Study of English Literature	--	No English description available	--			--	f		0	2014-12-18 00:00:00+01	2015-01-23	2014-12-01	t	0	t		0	HS 15 Neue Uni					0
1	15049	null	8	Montag	14:15:00	15:45:00	\N		\N	\N	\N	0	0	Vorlesung: Akademische Aufsatztypen	Academic Essay Writing	--	No English description available	--			--	f		0	2014-06-24 00:00:00+02	2015-01-23	2014-12-01	t	0	f		103	Neue Uni HS 06					0
1	15043	null	8	Dienstag	09:15:00	10:45:00	122		\N	\N	\N	0	0	Zeit und Aspekt	Tense and Aspect	--	No English description available	--			--	f		0	2014-06-10 00:00:00+02	2015-01-23	2014-12-01	t	100	f		7						0
1	15055	null	39	Donnerstag	11:15:00	12:45:00	108		\N	\N	\N	0	0	 ---- 	From Potatoes to Chips: The Transformation of Ireland 1800-2000	--	No English description available	--			--	f		0	2014-06-19 00:00:00+02	2015-01-23	2014-12-01	t	300	f		22						0
1	15054	null	39	Donnerstag	09:15:00	10:45:00	116		\N	\N	\N	0	0	Wortschatz im Einsatz	Vocabulary and Idiom	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	2015-01-23	2014-12-01	t	200	f		27						0
1	15051	null	39	Dienstag	11:15:00	12:45:00	108		\N	\N	\N	0	0	Vorbereitungskurs für Examenskandidaten	Translation into English	--	No English description available	--			--	f		0	2014-06-18 00:00:00+02	\N	\N	t	0	f		31						0
1	15235	null	46	Dienstag	16:15:00	17:45:00	115		\N	\N	\N	0	0	Preparing for the Final Exam	Preparing for the Final Exam	--	No English description available	--			--	f		0	2014-06-23 00:00:00+02	\N	\N	t	0	f		33						0
1	15365	null	39	Dienstag	16:15:00	17:45:00	108		\N	\N	\N	0	0	Übersetzungen Deutsch-English	Translation German-English 	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	\N	\N	f	600	t		0						0
1	15117	null	29	Mittwoch	18:15:00	19:45:00	108		\N	\N	\N	0	0	Forschungskolloquium	Research Colloquium	--	No English description available	--			--	f		0	2014-06-17 00:00:00+02	\N	\N	t	0	f		16						0
1	15367	null	39	Freitag	09:15:00	10:45:00	122		\N	\N	\N	0	0	Zeit und Aspekt	Tesne & Aspect	--	No English description available	--			--	f		0	2014-11-16 00:00:00+01	2015-01-23	2014-12-01	t	400	t		0						0
1	15239	null	8	Donnerstag	13:15:00	14:00:00	122		\N	\N	\N	0	0	Begleitkurs zum PS: Einführung in das wissenschaftliche Arbeiten und Schreiben	Fundamentals of Research and Writing	--	No English description available	--			--	f		0	2014-06-24 00:00:00+02	2015-01-23	2014-12-01	t	0	f		19						0
1	15245	null	25	Montag	09:15:00	10:45:00	114		\N	\N	\N	0	0	Konstrastive Linguistik	Contrastive Linguistics	--	No English description available	--			--	f		0	2014-06-30 00:00:00+02	2015-01-23	2014-12-01	t	0	f		26						0
1	15201	null	113	Montag	14:15:00	15:45:00	\N		\N	\N	\N	0	0	Einführung in die englische Phonologie und Phonetik	Introduction to English Phonology and Phonetics	--	No English description available	--			--	f		0	2014-06-27 00:00:00+02	2015-01-23	2014-12-01	t	0	f		230	Heuscheuer II					0
1	15246	null	25	Mittwoch	09:15:00	10:45:00	114		\N	\N	\N	0	0	Einführung ins Frühneuenglische	Introduction to Early Modern English	--	No English description available	--			--	f		0	2014-06-27 00:00:00+02	2015-01-23	2014-12-01	t	0	f		18						0
1	15113	null	84	Mittwoch	09:15:00	10:45:00	116		\N	\N	\N	0	0	The Persuasive Power of Fiction	The Persuasive Power of Fiction	--	No English description available	--			--	f		0	2014-07-01 00:00:00+02	2015-01-23	2014-12-01	t	30	f		19						0
1	15188	null	26	Mittwoch	11:15:00	12:45:00	122		\N	\N	\N	0	0	American Detectives	American Detectives	--	No English description available	--			--	f		0	2014-07-25 00:00:00+02	2015-01-23	2014-12-01	t	1000	f		26						0
\.


--
-- TOC entry 2766 (class 0 OID 219274)
-- Dependencies: 168 2810
-- Data for Name: tblBdKursTermin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdKursTermin" ("lngSdSeminarID", "lngKursID", "intKursTerminPrioritaet", "intKursTerminNummer", "strRaumBezeichnung", "dtmKursTerminDatum", "dtmKursTerminStart", "dtmKursTerminStop", "blnKursTerminZuschlag") FROM stdin;
\.


--
-- TOC entry 2767 (class 0 OID 219278)
-- Dependencies: 169 2810
-- Data for Name: tblBdKursXKurstyp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdKursXKurstyp" ("lngSeminarID", "lngKurstypID", "lngKursID", "strBemerkung", "strBemerkung_en", "sngKursCreditPts", "intKursSemesterMin", "intKursSemesterMax", "strCustom1", "strCustom2", "strCustom3", "strCustom1_en", "strCustom2_en", "strCustom3_en", "intKursCommitmentMode") FROM stdin;
1	10140	15273	auto-add		4	0	25							0
1	20000	15274	auto-add		4	0	25							0
1	10110	15274	auto-add		4	0	25							0
1	10140	15274	auto-add		4	0	25							0
1	20000	15273	auto-add		4	0	25							0
1	10110	15273	auto-add		4	0	25							0
1	10090	15277	auto-add		0	0	25							0
1	24	15235	auto-add		0	0	25							0
1	28	15283	auto-add		0	0	25							0
1	10130	15287	auto-add		0	0	25							0
1	20010	15278	auto-add		0	0	25							0
1	10080	15284	auto-add		0	0	25							0
1	28	15365	auto-add		0	0	25							0
1	20010	15279	auto-add		0	0	25							0
1	6	15285	auto-add		0	0	25							0
1	10120	15049	auto-add		0	0	25							0
1	6	15050	auto-add		0	0	25							0
1	10130	15054	auto-add		0	0	25							0
1	10080	15055	auto-add		0	0	25							0
1	6	15056	auto-add		0	0	25							0
1	34	15275	auto-add		0	0	25							0
1	6	15286	auto-add		0	0	25							0
1	34	15276	auto-add		0	0	25							0
1	5	15367	auto-add		0	0	25							0
1	24	15116	auto-add		0	0	25							0
1	10140	15342	auto-add		4	0	25							0
1	20005	15342	auto-add		4	0	25							0
1	19	15113	auto-add		0	0	25							0
1	10110	15342	auto-add		4	0	25							0
1	24	15117	auto-add		0	0	25							0
1	31	15188	auto-add		6	0	25							0
1	15	15188	auto-add		6	0	25							0
1	24	15191	auto-add		0	0	25							0
1	13	15201	auto-add		0	0	25							0
1	10110	15046	auto-add		4	0	25							0
1	10140	15046	auto-add		4	0	25							0
1	10110	15045	auto-add		4	0	25							0
1	10140	15045	auto-add		4	0	25							0
1	34	15044	auto-add		3	0	25							0
1	1	15213	auto-add		0	0	25							0
1	20010	15238	auto-add		0	0	25							0
1	25	15114	auto-add		0	0	25							0
1	20	15118	auto-add		0	0	25							0
1	28	15140	auto-add		0	0	25							0
1	10090	15047	auto-add		6	0	25							0
1	5	15043	auto-add		3	0	25							0
1	25	15163	auto-add		0	0	25							0
1	20000	15046	auto-add		4	0	25							0
1	20000	15045	auto-add		4	0	25							0
1	0	15028	auto-add		0	0	25							0
1	28	15051	auto-add		0	0	25							0
1	20	15115	auto-add		0	0	25							0
1	24	15119	auto-add		0	0	25							0
1	25	15375	auto-add		0	0	25							0
1	19	15376	auto-add		0	0	25							0
1	20	15385	auto-add		0	0	25							0
1	15	15389	auto-add		0	0	25							0
1	20	15120	auto-add		8	0	25							0
1	19	15395	auto-add		0	0	25							0
1	20010	15239	auto-add		0	0	25							0
1	2	15396	auto-add		0	0	25							0
1	6	15142	auto-add		0	0	25							0
1	19	15164	auto-add		0	0	25							0
1	28	15141	auto-add		0	0	25							0
1	20	15245	auto-add		0	0	25							0
1	-1	15247	auto-add		0	0	25							0
1	24	15248	auto-add		0	0	25							0
1	10110	15146	auto-add		4	0	25							0
1	20005	15146	auto-add		4	0	25							0
1	10140	15146	auto-add		4	0	25							0
1	10140	15052	auto-add		4	0	25							0
1	10110	15052	auto-add		4	0	25							0
1	20005	15052	auto-add		4	0	25							0
1	28	15377	auto-add		0	0	25							0
1	24	15380	auto-add		0	0	25							0
1	5	15053	auto-add		0	0	25							0
1	24	15318	auto-add		0	0	25							0
1	6	15143	auto-add		0	0	25							0
1	20	15319	auto-add		0	0	25							0
1	6	15145	auto-add		0	0	25							0
1	13	15320	auto-add		0	0	25							0
1	28	15338	auto-add		0	0	25							0
1	6	15340	auto-add		0	0	25							0
1	5	15343	auto-add		0	0	25							0
1	16	15321	auto-add		0	0	25							0
1	24	15381	auto-add		0	0	25							0
1	5	15144	auto-add		0	0	25							0
1	20300	15188	auto-add		5	0	25							0
1	10010	15246	auto-add		0	0	25							0
1	28	15339	auto-add		0	0	25							0
1	6	15341	auto-add		0	0	25							0
1	39	15344	auto-add		0	0	25							0
1	10100	15344	auto-add		2	0	25							0
1	10010	15428	auto-add		0	0	25							0
1	20	15429	auto-add		0	0	25							0
1	24	15430	auto-add		0	0	25							0
1	-1	15431	auto-add		0	0	25							0
1	1	15379	auto-add		5	0	25							0
1	10090	15389	auto-add		6	0	25							0
1	31	15389	auto-add		6	0	25							0
\.


--
-- TOC entry 2768 (class 0 OID 219295)
-- Dependencies: 170 2810
-- Data for Name: tblBdKursXLink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdKursXLink" ("lngSdSeminarID", "lngKursID", "lngLinkID", "strKursLinkURL", "strKursLinkBezeichnung", "strKursLinkBeschreibung", "blnKursLinkDownload", "blnKursLinkVisible", "strKursLinkCustom1", "strKursLinkCustom2", "strKursLinkCustom3") FROM stdin;
\.


--
-- TOC entry 2769 (class 0 OID 219307)
-- Dependencies: 171 2810
-- Data for Name: tblBdKvvArchiv; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdKvvArchiv" ("lngSdFakultaetID", "strSdFakultaetName", "lngSdSeminarID", "strSdSeminarName", "lngID", "lngKvvArchivKurstypID", "lngKvvArchivKursID", "strKvvArchivSemesterName", "strKvvArchivDozentname", "strKvvArchivKurstypBezeichnung", "strKvvArchivKursEinordnung", "strKvvArchivKursKategorie", "strKvvArchivKurstitel", "strKvvArchivKurstitel_en", "strKvvArchivKursTag", "dtmKvvArchivKursBeginn", "dtmKvvArchivKursEnde", "strKvvArchivKursRaum", "strKvvArchivKursTag2", "dtmKvvArchivKursBeginn2", "dtmKvvArchivKursEnde2", "strKvvArchivKursKursRaum2", "strKvvArchivKursBeschreibung", "strKvvArchivKursBeschreibung_en", "strKvvArchivKursVoraussetzung", "blnKvvArchivKursSchein", "strKvvArchivKursLiteratur", "strKvvArchivKursZusatz", "strKvvArchivKursTerminFreitext", "intKvvArchivKursTeilnehmer", "sngKvvArchivKursCreditPts", "strKvvArchivCustom1", "strKvvArchivCustom2", "strKvvArchivCustom3", "strKvvArchivDozentvorname", "strKvvArchivDozenttitel", "lngKvvArchivLeistungID", "strKvvArchivLeistungBezeichnung", "lngKvvArchivDozentID") FROM stdin;
\.


--
-- TOC entry 2770 (class 0 OID 219336)
-- Dependencies: 172 2810
-- Data for Name: tblBdKvvArchivXLinks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdKvvArchivXLinks" ("lngID", "lngLinkID", "strArchivLinkURL", "strArchivLinkBezeichnung", "strArchivLinkBeschreibung", "blnArchivLinkDownload", "strArchivLinkCustom1", "strArchivLinkCustom2", "strArchivLinkCustom3") FROM stdin;
\.


--
-- TOC entry 2771 (class 0 OID 219350)
-- Dependencies: 173 2810
-- Data for Name: tblBdPruefungAblauf; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdPruefungAblauf" ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", "lngAblaufID", "blnPruefungAblaufErledigt", "strPruefungAblaufBemerkung", "dtmPruefungAblaufDatum", "strPruefungAblaufPerson", "strCustom1", "strCustom2", "strCustom3") FROM stdin;
\.


--
-- TOC entry 2772 (class 0 OID 219361)
-- Dependencies: 174 2810
-- Data for Name: tblBdRaumplanExtern; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdRaumplanExtern" ("lngSdSeminarID", "lngLfdNr", "strRaum", "strTag", "dtmBeginn", "dtmEnde", "strName", "strKurstypBezeichnung", "blnPlanung") FROM stdin;
\.


--
-- TOC entry 2773 (class 0 OID 219371)
-- Dependencies: 175 2810
-- Data for Name: tblBdSprechstunde; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdSprechstunde" ("lngSdSeminarID", "lngDozentID", "strNutzerUniID", "strMatrikelnummer", "strSprechstundeBemerkung", "blnSprechstundeNurStudent", "dtmSprechstundeDatum", "tmeSprechstundeStart", "tmeSprechstundeStop", "blnSprechstundeEmailReminder", "strSprechstundeOrt", "strSprechstundeStornolink", "blnSprechstundeAbgesagt") FROM stdin;
\.


--
-- TOC entry 2774 (class 0 OID 219379)
-- Dependencies: 176 2810
-- Data for Name: tblBdStudent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudent" ("lngStudentPID", "strMatrikelnummer", "strStudentVorname", "strStudentNachname", "intStudentSemester", "strStudentPasswort", "blnStudentLoggedIn", "dtmStudentGeburtstag", "strStudentGeburtsort", "strStudentStrasse", "strStudentPLZ", "strStudentOrt", "strStudentEmail", "blnStudentPublishEmail", "strStudentTelefon", "strStudentHandy", "blnStudentPublishHandy", "strStudentHomepage", "blnStudentPublishHomepage", "strStudentInterests", "blnStudentVisible", "dtmStudentLastLogin", "dtmStudentLastLogout", "strStudentHf1", "strStudentHf2", "blnStudentFemale", "lngStudentRandom", "strStudentZUVFach", "intStudentFach1", "intStudentFach2", "intStudentFach3", "intStudentFach4", "intStudentFach5", "intStudentFach6", "intStudentFachsemester1", "intStudentFachsemester2", "intStudentFachsemester3", "intStudentFachsemester4", "intStudentFachsemester5", "intStudentFachsemester6", "strStudentStaat", "lngStudentZUVZiel", "strStudentBemerkung", "dtmStudentZUVUpdate", "strStudentGeburtsname", "dtmStudentZUVImmatrikuliert", "dtmStudentZUVAdd", "blnStudentSelected", "strStudentUrlaub") FROM stdin;
2	1000000	Jane	Doe	0	1000:34c041cc2c10fd3ff821c2511cba5efe5f9832a8c9fcda91:ce7d32444d26791073f0d2d63a0af548075b1bc7a1f4060e	\N	1997-05-13	Orlando	Floridastr. 8	12345	Doe-City	jane@testsystem.de	\N	012234567		\N		f		f	2014-12-27 15:34:22.859556+01	\N			t	\N	\N	200216	6702	0	0	0	0	4	1	0	0	0	0	Deutschland	182		2014-12-10	Taxpayer	2012-09-03	2012-09-12	\N	! Auslandsaufenthalt [#1]
3	2000000	Fulana	de Tal	0	1000:dba172caf9112b1652382f96734f2fc04d8920bc821b5e6d:12df1ca88293fa136ce7b8c34aee9cd88db1b316771cde0d	\N	1994-10-21	Madrid	Spanienweg 3	12345	Musterort	fulana@testsystem.de	t	01234567		f	http://	f		f	2014-10-16 15:27:18.790759+02	\N			t	\N	\N	200822	1501	0	0	0	0	8	8	8	0	0	0	Deutschland	125		2014-12-10	de Tal	2010-09-13	2010-10-08	\N	! Auslandsaufenthalt [#1]
4	3000000	Heiko	Jakubzik	0	1000:a1d238b565648c8a6476783d80c877b7bc29da1b649ab332:8c1dc41f2dabeacb1651a2797714f1360024d5279c52f1fa	\N	1969-11-06		Rheinvillenstr. 5	68163	Mannheim	heiko.jakubzik@shj-online.de	t			f		\N		\N	2014-02-18 19:57:43.412853+01	\N			f	\N	\N	200923	0	0	0	0	0	1	0	0	0	0	0		\N		\N		\N	\N	\N	
\.


--
-- TOC entry 2775 (class 0 OID 219402)
-- Dependencies: 177 2810
-- Data for Name: tblBdStudentAntrag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudentAntrag" ("lngStudentAntragID", "lngSdSeminarID", "strMatrikelnummer", "lngStudentAntragTypID", "strStudentAntragBezeichnung", "strStudentAntragBeschreibung", "dtmStudentAntragDatum") FROM stdin;
0	1	2000000	1	Antrag auf Ausstellen eines (deutschen) Transkripts.		2016-06-27
1	1	2000000	2	Antrag auf Ausstellen eines (englischen) Transkripts.		2016-06-27
\.


--
-- TOC entry 2776 (class 0 OID 219408)
-- Dependencies: 178 2810
-- Data for Name: tblBdStudentAntragStatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudentAntragStatus" ("lngSdSeminarID", "strMatrikelnummer", "lngDozentID", "lngStudentAntragID", "lngStudentAntragStatusID", "lngStudentAntragStatusTypID", "strStudentAntragStatusBezeichnung", "strStudentAntragStatusBeschreibung", "dtmStudentAntragStatusDatum", "blnStudentAntragStatusAbschluss") FROM stdin;
1	2000000	\N	0	833	1	Antrag gestellt	Antrag gestellt	2016-06-27	f
1	2000000	\N	1	834	1	Antrag gestellt	Antrag gestellt	2016-06-27	f
\.


--
-- TOC entry 2826 (class 0 OID 0)
-- Dependencies: 179
-- Name: tblBdStudentAntragStatus_lngStudentAntragStatusID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"tblBdStudentAntragStatus_lngStudentAntragStatusID_seq"', 834, true);


--
-- TOC entry 2827 (class 0 OID 0)
-- Dependencies: 180
-- Name: tblBdStudentB_lngStudentBem_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"tblBdStudentB_lngStudentBem_seq"', 960, true);


--
-- TOC entry 2779 (class 0 OID 219418)
-- Dependencies: 181 2810
-- Data for Name: tblBdStudentBemerkung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudentBemerkung" ("lngStudentBemerkungID", "lngSdSeminarID", "strMatrikelnummer", "lngDozentID", "strStudentBemerkungTag", "strStudentBemerkungText", "dtmStudentBemerkungDatum") FROM stdin;
\.


--
-- TOC entry 2780 (class 0 OID 219426)
-- Dependencies: 182 2810
-- Data for Name: tblBdStudentDokument; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudentDokument" ("lngSdSeminarID", "strMatrikelnummer", "dtmStudentDokumentDatum", "strVerifikationscode", "strDokument", "strStudentDokumentName", "blnStudentDokumentDauertranskript") FROM stdin;
\.


--
-- TOC entry 2781 (class 0 OID 219442)
-- Dependencies: 183 2810
-- Data for Name: tblBdStudentPruefungDetail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudentPruefungDetail" ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", "lngLeistungsID", "lngStudentLeistungCount", "lngModulID", "strCustom1", "strCustom2", "strCustom3", "blnStudentLeistungPruefung", "sngStudentLeistungCreditPts") FROM stdin;
\.


--
-- TOC entry 2782 (class 0 OID 219456)
-- Dependencies: 184 2810
-- Data for Name: tblBdStudentXLeistung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudentXLeistung" ("lngSdSeminarID", "strMatrikelnummer", "lngLeistungsID", "lngStudentLeistungCount", "lngDozentID", "intNoteID", "lngKlausuranmeldungKurstypID", "lngKlausuranmeldungKursID", "strSLKursUnivISID", "strSLKursTag", "dtmSLKursBeginn", "dtmSLKursEnde", "strSLKursRaum", "strSLKursTag2", "dtmSLKursBeginn2", "dtmSLKursEnde2", "strSLKursRaum2", "strSLKursTitel", "strSLKursTitel_en", "strSLKursBeschreibung", "strSLKursBeschreibung_en", "strSLKursLiteratur", "strSLKursZusatz", "strSLKursAnmeldung", "strSLKursVoraussetzung", "blnSLKursSchein", "strSLKursEinordnung", "intSLKursStunden", "dtmSLKursLastChange", "dtmSLKursScheinanmeldungBis", "dtmSLKursScheinanmeldungVon", "blnSLKursScheinanmeldungErlaubt", "strSLKursTerminFreitext", "intSLKursTeilnehmer", "strSLKursRaumExtern1", "strSLKursRaumExtern2", "strSLKursDetails", "strStudentLeistungDetails", "blnStudentLeistungBestanden", "strStudentLeistungNote", "sngStudentLeistungCreditPts", "dtmStudentLeistungAusstellungsd", "strStudentLeistungAussteller", "strStudentLeistungBemerkung", "blnStudentLeistungValidiert", "dtmStudentLeistungAntragdatum", "blnStudentLeistungKlausuranmeldung", "blnStudentLeistungEditierbar", "blnStudentLeistungGesiegelt", "strStudentLeistungCustom1", "strStudentLeistungCustom2", "strStudentLeistungCustom3", "blnStudentLeistungPruefung", "strStudentLeistungAusstellerVor", "strStudentLeistungAusstellerTit", "dtmStudentLeistungHISExport", "dtmStudentLeistungHISVerified", "lngModulID", "lngStudentLeistungHISPrId", "blnStudentLeistungAnerkannt") FROM stdin;
1	1000000	10120	1	8	6	10120	14810	null	Dienstag	11:15:00	12:45:00	\N		\N	\N	\N	Vorlesung: Akademische Aufsatztypen	Academic Essay Writing Lecture	--	--	--			--	f		0	2013-07-03 00:00:00+02	2014-01-24	2013-12-02	t		120	HS 07, Neue Uni		Vorlesung: Akademische Aufsatztypen		f		4	2014-03-13	Doe		t	2013-12-11	f	f	t			--	t	Joan		\N	\N	100045	0	f
1	1000000	4	1	113	6	13	14563	null	Montag	16:15:00	17:45:00	\N		\N	\N	\N	Einführung in die englische Phonologie und Phonetik	Introduction to English Phonology and Phonetics	--	--	--			--	f		0	2012-11-23 00:00:00+01	2013-07-14	2013-06-14	t		140	Heuscheuer		Einführung in die englische Phonologie und Phonetik		f		4	2013-08-02	Lazar	;	t	2013-06-26	f	f	t				t	Josefa	Priv.-Doz. Dr.	\N	\N	100025	0	f
1	1000000	7110	1	23	13	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	Vorlesung: Einführung in die Geschichte der Neuzeit, Historisches Seminar, SS2013	Lecture: Introduction to Modern History, Dept. of History, summer 2013	--	--	--	\N	\N	--	f	\N	0	1969-11-06 00:00:00+01	\N	\N	f	\N	0	\N	\N	\N		t	\N	3	2014-08-12	Test		t	\N	f	f	f	\N	\N	--	t	Theresa	Ms	\N	\N	500	0	f
1	1000000	7110	2	23	13	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	Quellenübung Neuere/Neueste Geschichte, Historisches Seminar, WS2013-14	Working With Sources, Dept. of History, winter 2013-14	--	--	--	\N	\N	--	f	\N	0	1969-11-06 00:00:00+01	\N	\N	f	\N	0	\N	\N	\N		t	\N	3	2014-08-12	Test		t	\N	f	f	f	\N	\N	--	t	Theresa	Ms	\N	\N	500	0	f
1	1000000	10150	2	46	1	10050	6838	Not in archive	Donnerstag	14:15:00	15:45:00	\N		\N	\N	\N	Metapher und Metonymie	Metaphor and metonymy	--	--	--		Not in archive	--	f		0	1969-11-06 00:00:00+01	\N	\N	f		83	\N	\N	\N		t	\N	4	2013-08-21	Mustermann		t	2013-08-21	f	f	f	\N	\N	KL	t	Murat	Prof. Dr.	\N	\N	100105	0	f
1	2000000	10090	1	8	1	10090	14425	null	Donnerstag	09:15:00	12:45:00	110		\N	\N	\N	The American Musical	The American Musical	--	--	--			--	f		0	2013-02-06 00:00:00+01	2013-07-14	2013-06-14	t		30			The American Musical		f		6	2013-07-25	Doe		t	2013-06-17	f	f	t			--	t	Joan		\N	\N	100245	0	f
1	2000000	4	1	113	3	13	13676	null	Montag	16:15:00	17:45:00	\N		\N	\N	\N			--	--	--			--	f		0	2010-12-02 00:00:00+01	2011-07-01	2011-05-01	t		180	Heuscheuer II		Einführung in die englische Phonologie und Phonetik		f		4	2011-08-04	Lazar	;	t	2011-05-11	f	f	t				t	Josefa	Dr.	\N	\N	100025	0	f
1	2000000	12	1	23	2	6	13497	null	Mittwoch	09:15:00	10:45:00	122		\N	\N	\N	Grundkenntnisse im Verfassen englischer Texte	Writing /Essential Skills for Writing	--	--	--			--	f		0	2011-03-02 00:00:00+01	2011-07-01	2011-05-01	t		34			Grundkenntnisse im Verfassen englischer Texte		f		3	2011-08-05	Test	;	t	2011-05-18	f	f	t				t	Theresa	Ms	\N	\N	100045	0	f
1	1000000	20010	1	8	13	20010	14629	null	Dienstag	13:15:00	14:00:00	122		\N	\N	\N	 Begleitkurs zum PSI Sprach- und Literaturwissenschaft: Grundlagen des wissenschaftlichen Arbeitens 	Begleitkurs zum PSI Sprach- und Literaturwissenschaft: Grundlagen des wissenschaftlichen Arbeitens 	--	--	--			--	f		0	2012-12-27 00:00:00+01	2013-07-14	2013-06-14	t		31			 Begleitkurs zum PSI Sprach- und Literaturwissenschaft: Grundlagen des wissenschaftlichen Arbeitens 		f		2	2013-08-31	Doe	;	t	2013-06-26	f	f	t				t	Joan		\N	\N	100075	0	f
1	2000000	16	2	84	1	19	14885	null	Mittwoch	09:15:00	10:45:00	116		\N	\N	\N	Beginnings: The Importance of Origins (of Novels) and Style	Beginnings: The Importance of Origins (of Novels) and Style	--	--	--			--	f		0	2014-01-10 00:00:00+01	2014-07-11	2014-06-06	t		18			Beginnings: The Importance of Origins (of Novels) and Style	The Beginning of the End in Stevenson's "Strange Case of Dr. Jekyll and Mr Hyde" and Wilde's "The Picture of Dorian Gray"	t		8	2014-10-14	Meikäläinen	\N	t	2014-07-01	f	f	f			HA	f	Maija	Prof. Dr.	\N	\N	100275	0	f
1	1000000	12	1	23	1	6	14539	null	Donnerstag	11:15:00	12:45:00	108		\N	\N	\N	Grundkenntnisse im Verfassen englischer Texte	Essential Skills for Writing	--	--	--			--	f		0	2012-11-20 00:00:00+01	2013-07-14	2013-06-14	t		25			Grundkenntnisse im Verfassen englischer Texte		f		3	2013-08-14	Test	;	t	2013-06-26	f	f	t				t	Theresa	Ms	\N	\N	100045	0	f
1	1000000	10	1	84	3	14	14523	null	Dienstag	14:15:00	15:45:00	116		\N	\N	\N	Sea Stories	Sea Stories	--	--	--			--	f		0	2013-01-18 00:00:00+01	2013-07-14	2013-06-14	t		29			Sea Stories		f		5	2013-10-01	Meikäläinen	 Automatik ändert für neue Studiengänge die LP auf 5 (von ursprünglich 5.5)	t	2013-06-26	f	f	t				t	Maija	Prof. Dr.	\N	\N	100075	0	f
1	2000000	5	1	23	1	5	13359	null	Dienstag	11:15:00	12:45:00	110		\N	\N	\N	Tempus und Aspekt	Tense and Aspect	--	--	--			--	f		0	2010-05-11 00:00:00+02	2011-01-16	2010-11-29	t		49			Zeit und Aspekt	Tense 	f		3	2011-02-17	Test	;	t	2010-12-14	f	f	t			HA	t	Theresa	Ms	\N	\N	100035	0	f
1	2000000	21	1	25	2	20	15005	null	Donnerstag	16:15:00	17:45:00	115		\N	\N	\N	Englische Syntax	English Syntax	--	--	--			--	f		0	2014-01-05 00:00:00+01	2014-07-11	2014-06-06	t		23			Englische Syntax		t		8	2014-07-31	Bloggs	 Automatik ändert LP im HS Anglistik auf 8 (von ursprünglich 0)	t	2014-07-01	f	f	f			--	t	Fred	Dr.	\N	\N	100275	0	f
1	2000000	20005	1	39	2	20005	15122	null	Donnerstag	14:15:00	15:45:00	115		\N	\N	\N	Exposition and Argumentation	Exposition and Argumentation	--	--	--			--	f		0	2014-04-07 00:00:00+02	2014-07-11	2014-06-06	t		19			Exposition and Argumentation		f		4	2014-09-24	Pompies		t	2014-07-01	f	f	t			KL	t	Piet		\N	\N	100225	0	f
1	2000000	13	1	39	2	7	13593	null	Dienstag	09:15:00	10:45:00	115		\N	\N	\N	Grundkenntnisse im Übersetzen ins Englische	Translation into English	--	--	--			--	f		0	2011-03-02 00:00:00+01	2011-07-01	2011-05-01	t		37			Grundkenntnisse im Übersetzen ins Englische		f		3	2011-08-10	Pompies	;	t	2011-05-11	f	f	t				t	Piet		\N	\N	100035	0	f
1	2000000	10120	1	113	4	10120	14031	null	Dienstag	09:15:00	10:45:00	114		\N	\N	\N	Akademische Aufsatztypen	Academic Essay Writing	--	--	--			--	f		0	2011-12-18 00:00:00+01	2012-07-17	2012-06-01	t		20			Akademische Aufsatztypen		f		4	2012-09-14	Lazar		t	2012-06-23	f	f	t				t	Josefa	Priv.-Doz. Dr.	\N	\N	100045	0	f
1	2000000	1	1	46	3	2	13412	null	Montag	11:15:00	12:45:00	\N		\N	\N	\N			--	--	--			--	f		0	2010-06-18 00:00:00+02	2011-01-16	2010-11-29	t		270	Heuscheuer I		Einführung Literaturwissenschaft		f		4	2011-02-17	Mustermann	;	t	2010-12-14	f	f	t			--	t	Murat	Prof. Dr.	\N	\N	100015	0	f
1	1000000	10050	1	113	1	10050	14607	null	Mittwoch	13:15:00	14:00:00	\N	Donnerstag	13:15:00	14:00:00	\N	Englisches Lehnwortgut und Konsequenzen	English loans and consequences	--	--	--			--	f		0	2012-12-21 00:00:00+01	2013-07-14	2013-06-14	t		50	n.n.	n.n.	Englisches Lehnwortgut und Konsequenzen	Oral Examination on Changes within living memory	t		4	2013-07-31	Lazar		t	2013-06-26	f	f	f				t	Josefa	Priv.-Doz. Dr.	\N	\N	100105	0	f
1	2000000	10130	1	39	1	10130	14659	null	Donnerstag	09:15:00	10:45:00	112		\N	\N	\N	Wortschatz im Einsatz	Vocabulary and Idiom	--	--	--			--	f		0	2014-01-04 00:00:00+01	2014-01-24	2013-12-02	t		28			Wortschatz im Einsatz		f		3	2014-02-06	Pompies		t	2014-01-11	f	f	t			KL	t	Piet		\N	\N	100305	0	f
1	2000000	3	1	26	1	22	13436	null	Donnerstag	14:15:00	15:00:00	\N		\N	\N	\N			--	--	--			--	f		0	2010-06-15 00:00:00+02	2011-01-16	2010-11-29	t		25	ZSL 320		 ---- 		f		1	2011-03-14	Normalverbraucher		t	2010-12-14	f	f	t				t	Otto	Dr.	\N	\N	100025	0	f
1	2000000	10	1	26	1	14	13858	null	Mittwoch	14:15:00	15:45:00	113		\N	\N	\N	Einführung in die Lyrik: Whitman, Dickinson, Frost	Introduction to U.S. American Poetry: Whitman, Dickinson, Frost	--	--	--			--	f		0	2011-06-06 00:00:00+02	2012-01-22	2011-11-25	t		0			Einführung in die Lyrik: Whitman, Dickinson, Frost	Emily Dickinson and the Fathomless Self: Reinventing the Rules of Epistemology by Means of Contradiction and Ambiguity	f		5	2012-03-14	Normalverbraucher	LP von 5,5 auf 5 geändert wg. Transkript; 	t	2011-11-30	f	f	t			HA	t	Otto	Dr.	\N	\N	100235	0	f
1	1000000	22	0	26	1	31	7326		Mittwoch	11:15:00	12:45:00	333		\N	\N	\N	Cyborgs in America	Cyborgs in America	--	--	--			--	f		0	1969-11-06 00:00:00+01	\N	\N	t		28		\N			f		6	2014-02-28	Normalverbraucher	Mündliche Prüfung am 20.8.2014	t	2014-08-20	f	t	t				t	Otto	Dr.	\N	\N	\N	0	f
1	1000000	10070	1	26	3	10070	14839	null	Dienstag	16:15:00	17:45:00	115		\N	\N	\N	Die Rolle der Medien in der Amerikanischen Kultur 	The Role of Media in American Culture  	--	--	--			--	f		0	2013-07-05 00:00:00+02	2014-01-24	2013-12-02	t		28			Die Rolle der Medien in der Amerikanischen Kultur 		t		5	2014-03-25	Normalverbraucher		t	2013-12-11	f	f	f			KL	f	Otto	Dr.	\N	\N	100075	0	f
1	1000000	10050	2	29	13	10050	14769	null	Donnerstag	14:15:00	17:30:00	110		\N	\N	\N	Sprache, Denken und Kultur	Language, Mind and Culture	--	--	--			--	f		0	2013-06-20 00:00:00+02	2014-01-24	2013-12-02	t		61			Sprache, Denken und Kultur		t		4	2014-02-06	Smith		t	2013-12-11	f	f	t			KL	t	Bobbie	Prof. Dr.	\N	\N	100065	0	f
1	1000000	15	1	26	1	15	14831	null	Mittwoch	11:15:00	12:45:00	333		\N	\N	\N	Cyborgs in America	Cyborgs in America	--	--	--			--	f		0	2013-07-04 00:00:00+02	2014-01-24	2013-12-02	t		28			Cyborgs in America	Defending Humanism.	f		6	2014-03-25	Normalverbraucher		t	2013-12-11	f	f	t			HA	t	Otto	Dr.	\N	\N	100085	0	f
1	2000000	20220	1	57	1	20220	14101	null	Dienstag	11:15:00	12:45:00	110		\N	\N	\N	Das Lehrwerk		--	--	--			--	f		0	2011-11-27 00:00:00+01	2012-07-17	2012-06-01	t		35			Das Lehrwerk	Hörverstehen und Songs im Englischunterricht  Theorie trifft Praxis  	f		5	2013-05-09	Svensson		t	2012-06-16	f	f	t				t	Kalle	StD	\N	\N	100285	0	f
1	2000000	0	1	29	2	1	13630	null	Mittwoch	11:15:00	12:45:00	\N		\N	\N	\N			--	--	--			--	f		0	2010-12-06 00:00:00+01	2011-07-01	2011-05-01	t		200	NUni HS 14		Einführung in die Sprachwissenschaft NU H 14		f		4	2011-09-28	Smith	;	t	2011-05-18	f	f	t				t	Bobbie	Prof. Dr.	\N	\N	100015	0	f
1	1000000	3	1	113	6	4	14361	null	Dienstag	09:15:00	10:00:00	\N		\N	\N	\N	Britisches Englisch		--	--	--			--	f		0	2012-06-13 00:00:00+02	2013-01-13	2012-12-14	t		24	ZSL 320		Pronunciation Practice BE		f		1	2013-02-27	Lazar		t	2012-12-15	f	f	t				t	Josefa	Priv.-Doz. Dr.	\N	\N	100025	0	f
1	1000000	5	1	23	6	5	14214	null	Dienstag	16:15:00	17:45:00	122		\N	\N	\N	Tempus und Aspekt	Tense and Aspect	--	--	--			--	f		0	2012-02-21 00:00:00+01	2013-01-13	2012-12-14	t		25			Zeit und Aspekt		f		3	2013-02-21	Test	;	t	2012-12-15	f	f	t				t	Theresa	Ms	\N	\N	100035	0	f
1	1000000	11	1	25	2	16	14525	null	Mittwoch	11:15:00	12:45:00	113		\N	\N	\N	Morphologie und Wortbildung	Morphology and word formation  	--	--	--			--	f		0	2012-12-28 00:00:00+01	2013-07-14	2013-06-14	t		19			Morphologie und Wortbildung		t		5	2013-07-24	Bloggs		t	2013-06-26	f	f	t			KL	t	Fred	Dr.	\N	\N	100075	0	f
1	1000000	0	1	29	4	1	14394	null	Mittwoch	11:15:00	12:45:00	\N		\N	\N	\N	Introduction to Linguistics		--	--	--			--	f		0	2012-12-05 00:00:00+01	2013-01-13	2012-12-14	t		120	Heu I		Introduction to Linguistics		f		4	2013-02-06	Smith	;	t	2012-12-15	f	f	t				t	Bobbie	Prof. Dr.	\N	\N	100015	0	f
1	2000000	11	1	29	1	16	13857	null	Dienstag	14:15:00	15:45:00	110		\N	\N	\N	Pragmatics		--	--	--			--	f		0	2011-06-06 00:00:00+02	2012-01-22	2011-11-25	t		28			Pragmatics	Emotive choices as pragmatic tools in communication	t		5	2012-05-08	Smith	LP von 5,5 auf 5 geändert wg. Transkript; 	t	2011-11-30	f	f	t			HA	t	Bobbie	Prof. Dr.	\N	\N	100235	0	f
1	2000000	9	1	39	14	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N			--	--	--	\N	\N	--	f	\N	0	1969-11-06 00:00:00+01	\N	\N	f	\N	0	\N	\N	\N		t	\N	0	2012-05-24	Pompies		t	\N	f	f	f	\N	\N		t	Piet		\N	\N	100010	0	f
1	2000000	15	1	26	1	15	14569	null	Mittwoch	11:15:00	12:45:00	116		\N	\N	\N	Lyrik und Politik der Romantik	Romantic Poetry and Politics	--	--	--			--	f		0	2013-01-01 00:00:00+01	2013-07-14	2013-06-14	t		42			Lyrik und Politik der Romantik		t		6	2013-08-25	Normalverbraucher		t	2013-06-17	f	f	f			KL	t	Otto	Dr.	\N	\N	100245	0	f
1	2000000	10020	1	29	1	10020	14414	null	Dienstag	14:15:00	15:45:00	108		\N	\N	\N	Einführung in die Geschichte des Englischen	Introduction to the History of English	--	--	--			--	f		0	2012-12-20 00:00:00+01	2013-07-14	2013-06-14	t		38			Einführung in die Geschichte des Englischen		f		6	2013-07-23	Smith		t	2013-06-17	f	f	t			KL	t	Bobbie	Prof. Dr.	\N	\N	100245	0	f
1	3000000	1	1	26	4	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N			--	--	--	\N	\N	--	f	\N	0	1969-11-06 00:00:00+01	\N	\N	f	\N	0	\N	\N	\N		t	\N	4	2008-02-14	Normalverbraucher		t	\N	f	f	f	\N	\N		t	Otto	Dr.	\N	\N	100325	0	f
1	2000000	10080	2	26	1	10080	5247	Not in archive	Mittwoch	11:15:00	12:45:00	114		\N	\N	\N	Jane Austen und das Märchen	Jane Austen and the Fairy Tale	--	--	--		Not in archive	--	f		0	1969-11-06 00:00:00+01	\N	\N	f		35	\N	\N	\N		t	\N	5	2012-03-26	Normalverbraucher		t	2012-05-18	f	f	f	\N	\N	KL	t	Otto	Dr.	\N	\N	100235	0	f
1	1000000	1	1	46	3	2	14371	null	Montag	11:15:00	12:45:00	\N		\N	\N	\N			--	--	--			--	f		0	2012-06-27 00:00:00+02	2013-01-13	2012-12-14	t		200	Heu II		Einführung Literaturwissenschaft		f		4	2013-02-08	Mustermann	;	t	2012-12-15	f	f	t				t	Murat	Prof. Dr.	\N	\N	100015	0	f
1	2000000	20010	1	26	13	20010	13865	null	Donnerstag	13:15:00	14:00:00	116		\N	\N	\N	Begleitkurs zum PS: Einführung in das wissenschaftliche Arbeiten und Schreiben	Begleitkurs zum PS: Einführung in das wissenschaftliche Arbeiten und Schreiben	--	--	--			--	f		0	2011-06-06 00:00:00+02	2012-01-22	2011-11-25	t		21			Begleitkurs zum PS: Einführung in das wissenschaftliche Arbeiten und Schreiben		f		2	2012-04-05	Normalverbraucher	;	t	2011-11-30	f	f	t				t	Otto	Dr.	\N	\N	100235	0	f
1	1000000	10160	0	46	13	25	15011		Dienstag	16:15:00	17:45:00	108		\N	\N	\N	Victorianismus: Britische Literatur & Kultur 1837-1901	Victorianism: British Literature & Culture 1837-1901	--	--	--			--	f		0	1969-11-06 00:00:00+01	2014-07-11	2014-06-06	t		100					t		4	2014-07-22	Mustermann		t	2014-07-07	f	t	f			KL	f	Murat	Prof. Dr.	\N	\N	100065	0	f
\.


--
-- TOC entry 2783 (class 0 OID 219521)
-- Dependencies: 185 2810
-- Data for Name: tblBdStudentXPruefung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdStudentXPruefung" ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", "intNoteID", "strStudentPruefungNote", "strStudentPruefungSemester", "blnStudentPruefungZUVInformiert", "blnStudentPruefungValidiert", "blnStudentPruefungAnmeldung", "blnStudentPruefungGesiegelt", "blnStudentPruefungBestanden", "dtmStudentPruefungAusstellungsd", "strStudentPruefungAussteller", "strStudentPruefungRowIP", "strStudentPruefungCustom1", "strStudentPruefungCustom2", "strStudentPruefungCustom3") FROM stdin;
1	200000	1000000	1	\N	0		f	f	f	f	t	2013-02-08	Automatische Ausstellung		Durch Trigger erzeugt am 2013-11-16	<table><tr><td><b>Leistung/Modul</b></td><td><b>Note</b></td><td><b>LP</b></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Einführungsmodul Sprach- und Literaturwissenschaft</td><td>1.8</td><td>0<tr><td>Einführung Sprachwissenschaft</td><td>2</td><td>4</td></tr><tr><td>Einführung Literaturwissenschaft</td><td>1.7</td><td>4</td></tr></td></tr></table>	
1	200000	2000000	1	\N	0		f	f	f	f	t	2011-09-28	Automatische Ausstellung		Durch Trigger erzeugt am 2012-06-09	<table><tr><td><b>Leistung/Modul</b></td><td><b>Note</b></td><td><b>LP</b></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Einführungsmodul Sprach- und Literaturwissenschaft</td><td>1.5</td><td>0<tr><td>Einführung Sprachwissenschaft</td><td>1.3</td><td>4</td></tr><tr><td>Einführung Literaturwissenschaft</td><td>1.7</td><td>4</td></tr></td></tr></table>	
1	200001	2000000	1	\N	1.2		f	f	f	f	t	2013-05-09	Automatische Ausstellung		Durch Trigger erzeugt am 2013-05-12	<table><tr><td><b>Leistung/Modul</b></td><td><b>Note</b></td><td><b>LP</b></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Fremdsprachenkenntnisse</td><td>0</td><td>0<tr><td>Fremdsprachenkenntnisse</td><td>0</td><td>0</td></tr></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Einführungsmodul Sprach- und Literaturwissenschaft</td><td>1.5</td><td>0<tr><td>Einführung Sprachwissenschaft</td><td>1.3</td><td>4</td></tr><tr><td>Einführung Literaturwissenschaft</td><td>1.7</td><td>4</td></tr></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Phonetikmodul</td><td>1.5</td><td>5<tr><td>Pronunciation Practice/Aussprachetest</td><td>1</td><td>1</td></tr><tr><td>Phonetik</td><td>1.7</td><td>4</td></tr></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Grammatik Modul</td><td>1.1</td><td>6<tr><td>Grammar/Tense and Aspect</td><td>1</td><td>3</td></tr><tr><td>Translation into English/Structure and Idiom</td><td>1.3</td><td>3</td></tr></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Schreibmodul</td><td>1.7</td><td>7<tr><td>Writing/Essential Skills for Writing</td><td>1.3</td><td>3</td></tr><tr><td>Advanced Writing/Academic Essay Writing</td><td>2</td><td>4</td></tr></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Aufbaumodul Sprach-, Literatur- und Kulturwissenschaft/Landeskunde</td><td>1.0</td><td>17<tr><td>Proseminar I Literaturwissenschaft</td><td>1</td><td>5</td></tr><tr><td>Proseminar I Sprachwissenschaft</td><td>1</td><td>5</td></tr><tr><td>Proseminar I Kulturwissenschaft (anwendungsorientiert)</td><td>1</td><td>5</td></tr><tr><td>Fundamentals of Research and Writing</td><td>0</td><td>2</td></tr></td></tr><tr style=&quot;background-color:#bbb&quot;><td>Fachdidaktik I</td><td>1.0</td><td>5<tr><td>Fachdidaktik I</td><td>1</td><td>5</td></tr></td></tr></table>	
\.


--
-- TOC entry 2784 (class 0 OID 219558)
-- Dependencies: 186 2810
-- Data for Name: tblBdTermin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblBdTermin" ("lngSeminarID", "lngTerminID", "dtmTerminDatum", "dtmTerminZeit", "strTerminOrt", "strTerminBeschreibung", "strTerminAP", "strTerminAPEmail", "strTerminVerteiler") FROM stdin;
\.


--
-- TOC entry 2785 (class 0 OID 219568)
-- Dependencies: 187 2810
-- Data for Name: tblInfo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblInfo" ("strVersion", "dtmDatum", "strInfo", "strAutor") FROM stdin;
os-1.00.00	2016-06-07	Untermenge 1	hj
\.


--
-- TOC entry 2786 (class 0 OID 219619)
-- Dependencies: 188 2810
-- Data for Name: tblPostprocessing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblPostprocessing" ("strMatrikelnummer", "strSQL", "strUser", "dtmDatum", "strKommentar") FROM stdin;
\.


--
-- TOC entry 2787 (class 0 OID 219637)
-- Dependencies: 189 2810
-- Data for Name: tblSdDozent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdDozent" ("lngSdSeminarID", "lngDozentID", "strDozentUnivISID", "strDozentPasswort", "strDozentTitel", "strDozentVorname", "strDozentNachname", "dtmDozentGebdatum", "strDozentStellennr", "strDozentTelefonPrivat", "strDozentStrasse", "strDozentPLZ", "strDozentOrt", "strDozentDienstendeMonat", "strDozentDienstendeJahr", "strDozentOD", "strDozentVertragsart", "strDozentBank", "strDozentKto", "strDozentBLZ", "strDozentSprechstundeTag", "dtmDozentSprechstundeDatum", "dtmDozentSprechstundeZeitVon", "dtmDozentSprechstundeZeitBis", "strDozentSprechstunde", "strDozentBau", "strDozentZimmer", "strDozentBereich", "strDozentTelefon", "strDozentEmail", "strDozentHomepage", "blnDozentLehrend", "strDozentBemerkung", "strDozentAnrede", "strDozentInteressen", "dtmSprechstundeLastChange", "strDozentPostfach", "intDozentAccessLevel", "strDozentIP", "lngDozentSessionID", "dtmDozentLastAction", "strDozentCertSubjectDN", "strDozentCertIssuerDN", "strDozentCertSerialID", "blnDozentCertValidated", "blnDozentCertRevoked", "blnDozentExtern", "strDozentHomepageOptions") FROM stdin;
1	8		1000:997fea879ed7d9781300a431ab5bb64967b5e292fc8c654d:fc5b513587c399ff5c7dd759ab4f8d6a4c99d8a94fc5d668		Joan	Doe	1962-04-10	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Frau		\N	1	600	\N	1572362667	\N				f	f	f	
1	29		1000:393548c90f4afd5d9fcd12a6a5fdd2191adc3de4acfe807a:eed1dfe36518a30fce0f01c4b82251d4a437ba6ca45010de	Prof. Dr.	Bobbie	Smith	\N	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Frau		\N	1	600	\N	1965159391	\N				f	f	f	
1	46		1000:68d86724cc5dbdbecf5ad3e933cb2b21d96d688afebcc805:87a1047165253046e0e2a362d02533c4c1f6a190b77e8b4c	Prof. Dr.	Murat	Mustermann	1954-03-26	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Herr		\N	1	1	\N	746467436	\N				f	f	f	
1	84		1000:d35f4259b11fe70c16a4fb5f03e8ad4cdd8a7ad949cbbf5b:e2b60b54a11ae3db3effcd068813a1b563fdbe46e67add54	Prof. Dr.	Maija	Meikäläinen	\N	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Frau		\N	1	1	\N	2041386273	\N				f	f	f	
1	39		1000:b5af1bfb4dbfdf58af4141a756a799eb13ed24d07c3825a5:ee6f457d61dbb722cf230336f3d76f2c93c0c6f95a005b74		Piet	Pompies	1964-11-03	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Herr		\N	1	500	\N	1937867375	\N				f	f	f	
1	57		1000:09f1b1bc860d79ae960c21d392117808a2c81c1a1ad9c838:e75573dd0872dfa74581ee10c0537067baf4be2716e6285f	StD	Kalle	Svensson	1951-11-07	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Herr		\N	1	1	\N	380563508	\N				f	f	f	
1	113		1000:6284712bb67cc6fdfef6df58900d026d2133252d03052f24:7fcc9389da86cc7677ad16ce9f19178075efffba0c436c36	Priv.-Doz. Dr.	Josefa	Lazar	1872-01-31	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Frau		\N	1	600	\N	471806903	\N				f	f	f	
1	23		1000:5ec833a7afca877e363427728942fb7ffa0872a7d93ca48c:002d4ee343bf4b35c550afa2255ee31f802e5f8e97fbc58e	Ms	Theresa	Test	1963-03-14	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Frau		\N	1	600	\N	30036409	\N				f	f	f	
1	25		1000:903801f95945e427d92d8d9067498c89a04570c7b8a3721d:dfd900fd2e4fe94c435aa6a77aff575cf50cf824d14bbf9b	Dr.	Fred	Bloggs	1957-03-20	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Herr		\N	1	600	\N	872815249	\N				f	f	f	
1	26		1000:417ba21d3e670c6394a2d8897b6e8b70360ee15e7e4dedf8:9ad54f0c9ca605ee0e1dc8f933015191eaa27d0a7c6f617b	Dr.	Otto	Normalverbraucher	\N	100	0621-12345	Zu Hause 1	68163	Mannheim									\N	\N	\N	Mo 14-15 Uhr	AS	121		12345	info@shj-online.de	https://www.shj-online.de	t		Herr		\N	1	600	\N	1996800386	\N				f	f	f	
\.


--
-- TOC entry 2788 (class 0 OID 219676)
-- Dependencies: 190 2810
-- Data for Name: tblSdFach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdFach" ("intFachID", "strFachBezeichnung", "strFachBeschreibung", "strHN", "strFachHISStg", "sngFachCreditPtsRequired", "strFachTranskriptName", "strFachTranskriptName_en") FROM stdin;
2721	AGES HF	Alte Geschichte HF	HF	\N	\N	\N	\N
2722	AGES NF	Alte Geschichte NF	NF	\N	\N	\N	\N
8791	AINF HF	Anwendungsorientierte Informatik HF	HF	\N	\N	\N	\N
1521	ALSW HF	Allgemeine Sprachwissenschaft HF	HF	\N	\N	\N	\N
1522	ALSW NF	Allgemeine Sprachwissenschaft NF	NF	\N	\N	\N	\N
8351	ANGL HF	Englische Philologie HF	HF	\N	\N	\N	\N
8352	ANGL NF	Englische Philologie NF	NF	\N	\N	\N	\N
8301	ARCC HF	Christliche Archäologie HF	HF	\N	\N	\N	\N
8302	ARCC NF	Christliche Archäologie NF	NF	\N	\N	\N	\N
8311	ARCK HF	Klassische Archäologie HF	HF	\N	\N	\N	\N
8312	ARCK NF	Klassische Archäologie NF	NF	\N	\N	\N	\N
8321	ARCV HF	Vorderasiatische Archäologie HF	HF	\N	\N	\N	\N
8322	ARCV NF	Vorderasiatische Archäologie NF	NF	\N	\N	\N	\N
8211	ASSY HF	Assyriologie HF	HF	\N	\N	\N	\N
8212	ASSY NF	Assyriologie NF	NF	\N	\N	\N	\N
1601	CLIN HF	Computerlinguistik HF	HF	\N	\N	\N	\N
1602	CLIN NF	Computerlinguistik NF	NF	\N	\N	\N	\N
8261	DFPH  HF	Deutsch als Fremd. phil. (Literaturw., Sprachwiss.) HF	HF	\N	\N	\N	\N
8262	DFPH NF	Deutsch als Fremd. phil. (Literaturw., Sprachwiss.) NF	NF	\N	\N	\N	\N
8281	DFPL HF	Deutsch als Fremdsprachenphilologie, Literaturwissenschaft HF	HF	\N	\N	\N	\N
8282	DFPL NF	Deutsch als Fremdsprachenphilologie, Literaturwissenschaft NF	NF	\N	\N	\N	\N
8271	DFPS HF	Deutsch als Fremdsprachenphilologie, Sprachwissenschaft HF	HF	\N	\N	\N	\N
8272	DFPS NF	Deutsch als Fremdsprachenphilologie, Sprachwissenschaft NF	NF	\N	\N	\N	\N
1611	DIAK HF	Diakoniewissenschaft HF	HF	\N	\N	\N	\N
8141	ENGL HF	Dolmetscher Englisch HF	HF	\N	\N	\N	\N
8142	ENGL NF	Dolmetscher Englisch NF	NF	\N	\N	\N	\N
8361	EPHL HF	Englische Phil. (Literaturw) HF	HF	\N	\N	\N	\N
8362	EPHL NF	Englische Phil. (Literaturw) NF	NF	\N	\N	\N	\N
8371	EPHS HF	Englische Phil. (Sprachwiss) HF	HF	\N	\N	\N	\N
8372	EPHS NF	Englische Phil. (Sprachwiss) NF	NF	\N	\N	\N	\N
8291	EPS HF	European Political Studies HF	HF	\N	\N	\N	\N
1731	ETHN HF	Ethnologie / Völkerkunde HF	HF	\N	\N	\N	\N
1732	ETHN NF	Ethnologie / Völkerkunde NF	NF	\N	\N	\N	\N
8101	FRAN HF	Dolmetscher Französisch HF	HF	\N	\N	\N	\N
8102	FRAN NF	Dolmetscher Französisch NF	NF	\N	\N	\N	\N
8641	GERO HF	Gerontologie HD HF	HF	\N	\N	\N	\N
8011	HeEc HF	Health Economics HF	HF	\N	\N	\N	\N
8421	HWGE HF	Historische Hilfswissenschaften HF	HF	\N	\N	\N	\N
8422	HWGE NF	Historische Hilfswissenschaften NF	NF	\N	\N	\N	\N
8071	IGER HF	Indogermanistik HF	HF	\N	\N	\N	\N
8072	IGER NF	Indogermanistik NF	NF	\N	\N	\N	\N
8091	IMM HF	Informationsmanagement in der Medizin HF	HF	\N	\N	\N	\N
8451	INDK HF	Klassische Indologie HF	HF	\N	\N	\N	\N
8452	INDK NF	Klassische Indologie NF	NF	\N	\N	\N	\N
8461	INDN HF	Moderne Indologie HF	HF	\N	\N	\N	\N
8462	INDN NF	Moderne Indologie NF	NF	\N	\N	\N	\N
8831	ISLM  1 HF	Islamwissenschaft 1 HF	HF	\N	\N	\N	\N
8832	ISLM  1 NF	Islamwissenschaft 1 NF	NF	\N	\N	\N	\N
8842	ISLM  2 NF	Islamwissenschaft 2 NF	NF	\N	\N	\N	\N
8111	ITAL HF	Dolmetscher Italienisch HF	HF	\N	\N	\N	\N
8112	ITAL NF	Dolmetscher Italienisch NF	NF	\N	\N	\N	\N
8732	JURA OER NF	NÖffentliches Recht NF	NF	\N	\N	\N	\N
8712	KIJU NF	Kinder- und Jugendpsychiatrie NF	NF	\N	\N	\N	\N
8501	KNSO HF	Ostasiatische Kunstgeschichte HF	HF	\N	\N	\N	\N
8502	KNSO NF	Ostasiatische Kunstgeschichte NF	NF	\N	\N	\N	\N
8702	KRIM NF	Kriminologie NF	NF	\N	\N	\N	\N
8031	MaCB HF	Molecular and Cellular Biology HF	HF	\N	\N	\N	\N
8751	MAWR HF	Mathematik Wissenschaftl Rechnen HF	HF	\N	\N	\N	\N
1851	MDNT HF	Zahnmedizin HF	HF	\N	\N	\N	\N
8081	MEDE HF	Medizin und Gesundh. vors. in Entwicklungsland HF	HF	\N	\N	\N	\N
8041	MEDH HF	Medizin Klinikum Heidelberg HF	HF	\N	\N	\N	\N
8042	MEDH NF	Medizin Klinikum Heidelberg NF	NF	\N	\N	\N	\N
8051	MEDM HF	Medizin Klinikum Mannheim HF	HF	\N	\N	\N	\N
2471	MINF HF	Medizinische Informatik HF	HF	\N	\N	\N	\N
8181	MLAT HF	Lateinische Philologie des Mittelalters und der Neuzeit HF	HF	\N	\N	\N	\N
8182	MLAT NF	Lateinische Philologie des Mittelalters und der Neuzeit NF	NF	\N	\N	\N	\N
2731	MNGE HF	Mittlere und Neuere Geschichte HF	HF	\N	\N	\N	\N
2732	MNGE NF	Mittlere und Neuere Geschichte NF	NF	\N	\N	\N	\N
8021	MOBI HF	Molekulare Biotechnologie HF	HF	\N	\N	\N	\N
8161	NDL HF	Dolmetscher Niederländisch HF	HF	\N	\N	\N	\N
8162	NDL NF	Dolmetscher Niederländisch NF	NF	\N	\N	\N	\N
8401	OEGE HF	Osteuropäische Geschichte HF	HF	\N	\N	\N	\N
8402	OEGE NF	Osteuropäische Geschichte NF	NF	\N	\N	\N	\N
8511	POLS HF	Politische Wissenschaft Südasiens HF	HF	\N	\N	\N	\N
8512	POLS NF	Politische Wissenschaft Südasiens NF	NF	\N	\N	\N	\N
8131	PORT HF	Dolmetscher Portugiesisch HF	HF	\N	\N	\N	\N
8132	PORT NF	Dolmetscher Portugiesisch NF	NF	\N	\N	\N	\N
8981	REHA HF	Sport im Bereich der Prävention/ Rehabilitation HF	HF	\N	\N	\N	\N
8982	REHA NF	Sport im Bereich der Prävention/ Rehabilitation NF	NF	\N	\N	\N	\N
8561	ROML HF	Romanische Philologie, Literaturwissenschaft HF	HF	\N	\N	\N	\N
8562	ROML NF	Romanische Philologie, Literaturwissenschaft NF	NF	\N	\N	\N	\N
8551	ROMS HF	Romanische Philologie, Sprachwissenschaft HF	HF	\N	\N	\N	\N
8552	ROMS NF	Romanische Philologie, Sprachwissenschaft NF	NF	\N	\N	\N	\N
8151	RUSS HF	Dolmetscher Russisch HF	HF	\N	\N	\N	\N
8152	RUSS NF	Dolmetscher Russisch NF	NF	\N	\N	\N	\N
8411	SAGE HF	Südasien Geschichte HF	HF	\N	\N	\N	\N
8412	SAGE NF	Südasien Geschichte NF	NF	\N	\N	\N	\N
8061	SC. HUM.	Scientiarum Humanarum	Humanarum	\N	\N	\N	\N
8201	SEMI HF	Semitistik HF	HF	\N	\N	\N	\N
8202	SEMI NF	Semitistik NF	NF	\N	\N	\N	\N
8601	SINK HF	Klassische Sinologie HF	HF	\N	\N	\N	\N
8602	SINK NF	Klassische Sinologie NF	NF	\N	\N	\N	\N
8611	SINM HF	Moderne Sinologie HF	HF	\N	\N	\N	\N
8612	SINM NF	Moderne Sinologie NF	NF	\N	\N	\N	\N
8661	SLAL HF	Slawische Philologie, Literaturwissenschaft HF	HF	\N	\N	\N	\N
8662	SLAL NF	Slawische Philologie, Literaturwissenschaft NF	NF	\N	\N	\N	\N
8651	SLAS HF	Slawische Philologie, Sprachwissenschaft HF	HF	\N	\N	\N	\N
8652	SLAS NF	Slawische Philologie, Sprachwissenschaft NF	NF	\N	\N	\N	\N
8121	SPAN HF	Dolmetscher Spanisch HF	HF	\N	\N	\N	\N
1501	SPAN HF	Spanisch HF	HF	\N	\N	\N	\N
8122	SPAN NF	Dolmetscher Spanisch NF	NF	\N	\N	\N	\N
1502	SPAN NF	Spanisch NF	NF	\N	\N	\N	\N
1511	SPLO HF	Sprachheilpädagogik/ Logopädie HF	HF	\N	\N	\N	\N
1512	SPLO NF	Sprachheilpädagogik/ Logopädie NF	NF	\N	\N	\N	\N
8722	SPOT NF	Leistungsphys./ Sporttraumat. NF	NF	\N	\N	\N	\N
1961	STKO HF	Studienkolleg HF	HF	\N	\N	\N	\N
8171	UEBW HF	Übersetzungswissenschaft HF	HF	\N	\N	\N	\N
8172	UEBW NF	Übersetzungswissenschaft NF	NF	\N	\N	\N	\N
5481	URGE HF	Ur- und Frühgeschichte HF	HF	\N	\N	\N	\N
5482	URGE NF	Ur- und Frühgeschichte NF	NF	\N	\N	\N	\N
8251	VKUD HF	Vorsemesterkurs Deutsch HF	HF	\N	\N	\N	\N
1751	VWL HF	Volkswirtschaftslehre HF	HF	\N	\N	\N	\N
1752	VWL NF	Volkswirtschaftslehre NF	NF	\N	\N	\N	\N
0	--	--	--	\N	\N	\N	\N
40000	Testzugang Germanistik			\N	\N	\N	\N
200000	NF-BA/MA-Escape, cl	Germanistische Linguistik	NF	\N	\N	\N	\N
200002	NF-BA/MA-Escape, cl	Romanische Philologie/Sprachwissenschaft	NF	\N	\N	\N	\N
200003	NF-BA/MA-Escape, cl	Englische Philologie/Sprachwissenschaft	NF	\N	\N	\N	\N
200004	NF-BA/MA-Escape, cl	Slavische Philologie/Sprachwissenschaft	NF	\N	\N	\N	\N
200005	NF-BA/MA-Escape, cl	Mittellatein	NF	\N	\N	\N	\N
200006	NF-BA/MA-Escape, cl	Ostasienwissenschaft (Japanisch)	NF	\N	\N	\N	\N
200007	NF-BA/MA-Escape, cl	Ostasienwissenschaft (Chinesisch)	NF	\N	\N	\N	\N
200008	NF-BA/MA-Escape, cl	Anwendungsorientierte Informatik	NF	\N	\N	\N	\N
200009	NF-BA/MA-Escape, cl	Mathematik	NF	\N	\N	\N	\N
200010	NF-BA/MA-Escape, cl	Psychologie	NF	\N	\N	\N	\N
40001	Geog-Testzugang	Geographie	HF	\N	\N	\N	\N
8191	NN	Unbekannt		\N	\N	\N	\N
200011	NF-BA/MA-Escape, cl	Übersetzen und Dolmetschen / Russisch	NF	\N	\N	\N	\N
200012	NF-BA/MA-Escape, cl	Medizinische Informatik	NF	\N	\N	\N	\N
8631	??	Pflegewiss./Geront. Pflege HF	HF	\N	\N	\N	\N
200013	NF-BA/MA-Escape, cl	Allgemeine Sprachwissenschaft	NF	\N	\N	\N	\N
200014	NF-BA/MA-Escape, cl	Physik	NF	\N	\N	\N	\N
9081	BA neu & unbekannt			\N	\N	\N	\N
8381	BA neu & unbekannt			\N	\N	\N	\N
27304	BA neu & unbekannt			\N	\N	\N	\N
12704	BA neu & unbekannt			\N	\N	\N	\N
92504	BA neu & unbekannt			\N	\N	\N	\N
9207	BA neu & unbekannt			\N	\N	\N	\N
8802	BA neu & unbekannt			\N	\N	\N	\N
11404	BA neu & unbekannt			\N	\N	\N	\N
6807	BA neu & unbekannt			\N	\N	\N	\N
92004	BA neu & unbekannt			\N	\N	\N	\N
88505	BA neu & unbekannt			\N	\N	\N	\N
2905	BA neu & unbekannt			\N	\N	\N	\N
9204	BA neu & unbekannt			\N	\N	\N	\N
12702	BA neu & unbekannt			\N	\N	\N	\N
2904	BA neu & unbekannt			\N	\N	\N	\N
12705	BA neu & unbekannt			\N	\N	\N	\N
90805	BA neu & unbekannt			\N	\N	\N	\N
85307	BA neu & unbekannt			\N	\N	\N	\N
17304	BA neu & unbekannt			\N	\N	\N	\N
92005	BA neu & unbekannt			\N	\N	\N	\N
27305	BA neu & unbekannt			\N	\N	\N	\N
90304	BA neu & unbekannt			\N	\N	\N	\N
27204	BA neu & unbekannt			\N	\N	\N	\N
88504	BA neu & unbekannt			\N	\N	\N	\N
12904	BA neu & unbekannt			\N	\N	\N	\N
91104	BA neu & unbekannt			\N	\N	\N	\N
12907	BA neu & unbekannt			\N	\N	\N	\N
16004	BA neu & unbekannt			\N	\N	\N	\N
12905	BA neu & unbekannt			\N	\N	\N	\N
90702	BA neu & unbekannt			\N	\N	\N	\N
90804	BA neu & unbekannt			\N	\N	\N	\N
82004	BA neu & unbekannt			\N	\N	\N	\N
83104	BA neu & unbekannt			\N	\N	\N	\N
90704	BA neu & unbekannt			\N	\N	\N	\N
91204	BA neu & unbekannt			\N	\N	\N	\N
90202	BA neu & unbekannt			\N	\N	\N	\N
13202	BA neu & unbekannt			\N	\N	\N	\N
13602	BA neu & unbekannt			\N	\N	\N	\N
14602	BA neu & unbekannt			\N	\N	\N	\N
11402	BA neu & unbekannt			\N	\N	\N	\N
87302	BA neu & unbekannt			\N	\N	\N	\N
16002	BA neu & unbekannt			\N	\N	\N	\N
17302	BA neu & unbekannt			\N	\N	\N	\N
90802	BA neu & unbekannt			\N	\N	\N	\N
92002	BA neu & unbekannt			\N	\N	\N	\N
86505	BA neu & unbekannt			\N	\N	\N	\N
12902	BA neu & unbekannt			\N	\N	\N	\N
6802	BA neu & unbekannt			\N	\N	\N	\N
88507	BA neu & unbekannt			\N	\N	\N	\N
90507	BA neu & unbekannt			\N	\N	\N	\N
17307	BA neu & unbekannt			\N	\N	\N	\N
8801	BA neu & unbekannt			\N	\N	\N	\N
8781	BA neu & unbekannt			\N	\N	\N	\N
16007	BA neu & unbekannt			\N	\N	\N	\N
83502	ANGL	BA 50% Anglistik: Fehleinschreibg.	NF	\N	\N	\N	\N
90104	GERM K	BA 50% Germanistik Kulturvergl., 2. HF	HF	\N	\N	\N	\N
90105	GERM K	BA 50% Germanistik Kulturvergl., 1. HF	HF	\N	\N	\N	\N
88002	BA neu & unbekannt			\N	\N	\N	\N
86605	BA neu & unbekannt			\N	\N	\N	\N
11405	BA neu & unbekannt			\N	\N	\N	\N
90705	BA neu & unbekannt			\N	\N	\N	\N
13605	BA neu & unbekannt			\N	\N	\N	\N
86504	BA neu & unbekannt			\N	\N	\N	\N
54804	BA neu & unbekannt			\N	\N	\N	\N
90407	BA neu & unbekannt			\N	\N	\N	\N
92107	BA neu & unbekannt			\N	\N	\N	\N
90904	BA neu & unbekannt			\N	\N	\N	\N
88502	BA neu & unbekannt			\N	\N	\N	\N
85202	BA neu & unbekannt			\N	\N	\N	\N
82702	BA neu & unbekannt			\N	\N	\N	\N
90902	BA neu & unbekannt			\N	\N	\N	\N
83105	BA neu & unbekannt			\N	\N	\N	\N
91202	BA neu & unbekannt			\N	\N	\N	\N
54802	BA neu & unbekannt			\N	\N	\N	\N
90205	BA neu & unbekannt			\N	\N	\N	\N
85302	BA neu & unbekannt			\N	\N	\N	\N
9202	BA neu & unbekannt			\N	\N	\N	\N
91002	BA neu & unbekannt			\N	\N	\N	\N
14607	BA neu & unbekannt			\N	\N	\N	\N
82002	BA neu & unbekannt			\N	\N	\N	\N
82607	BA neu & unbekannt			\N	\N	\N	\N
90204	BA neu & unbekannt			\N	\N	\N	\N
9071	BA neu & unbekannt			\N	\N	\N	\N
86604	BA neu & unbekannt			\N	\N	\N	\N
9061	BA neu & unbekannt			\N	\N	\N	\N
100000	Editionswissenschaften			\N	\N	\N	\N
27202	BA neu & unbekannt			\N	\N	\N	\N
86502	BA neu & unbekannt			\N	\N	\N	\N
83002	BA neu & unbekannt			\N	\N	\N	\N
85304	BA neu & unbekannt			\N	\N	\N	\N
91102	BA neu & unbekannt			\N	\N	\N	\N
14902	BA neu & unbekannt			\N	\N	\N	\N
13604	BA neu & unbekannt			\N	\N	\N	\N
27205	BA neu & unbekannt			\N	\N	\N	\N
91902	BA neu & unbekannt			\N	\N	\N	\N
84202	BA neu & unbekannt			\N	\N	\N	\N
13607	BA neu & unbekannt			\N	\N	\N	\N
82602	BA neu & unbekannt			\N	\N	\N	\N
82802	BA neu & unbekannt			\N	\N	\N	\N
8531	BA neu & unbekannt			\N	\N	\N	\N
9041	BA neu & unbekannt			\N	\N	\N	\N
9051	BA neu & unbekannt			\N	\N	\N	\N
9291	MA Editionswissenschaften			\N	\N	\N	\N
92505	BA neu & unbekannt			\N	\N	\N	\N
83102	BA neu & unbekannt			\N	\N	\N	\N
82102	BA neu & unbekannt			\N	\N	\N	\N
5202	BA neu & unbekannt			\N	\N	\N	\N
84102	BA neu & unbekannt			\N	\N	\N	\N
85004	BA neu & unbekannt			\N	\N	\N	\N
85305	BA neu & unbekannt			\N	\N	\N	\N
92204	BA neu & unbekannt			\N	\N	\N	\N
9252	BA neu & unbekannt			\N	\N	\N	\N
9042	BA neu & unbekannt			\N	\N	\N	\N
9082	BA neu & unbekannt			\N	\N	\N	\N
90302	BA neu & unbekannt			\N	\N	\N	\N
83202	BA neu & unbekannt			\N	\N	\N	\N
16702	GERM ALT	BA 25% Germanistik nach PO vor 2009	NF	KEIN	\N	\N	\N
16704	GERM ALT	BA 50% 2. HF Germanistik nach PO vor 2009	HF	KEIN	\N	\N	\N
16705	GERM ALT	BA 50% 1. HF Germanistik nach PO vor 2009	HF	KEIN	\N	\N	\N
91907	BA neu & unbekannt			\N	\N	\N	\N
9011	BA neu & unbekannt			\N	\N	\N	\N
85207	BA neu & unbekannt			\N	\N	\N	\N
83204	BA neu & unbekannt			\N	\N	\N	\N
9052	BA neu & unbekannt			\N	\N	\N	\N
91205	BA neu & unbekannt			\N	\N	\N	\N
91302	BA neu & unbekannt			\N	\N	\N	\N
9381	BA neu & unbekannt			\N	\N	\N	\N
8771	BA neu & unbekannt			\N	\N	\N	\N
91304	BA neu & unbekannt			\N	\N	\N	\N
91305	BA neu & unbekannt			\N	\N	\N	\N
9102	BA neu & unbekannt			\N	\N	\N	\N
9161	BA neu & unbekannt			\N	\N	\N	\N
8532	BA neu & unbekannt			\N	\N	\N	\N
84105	BA neu & unbekannt			\N	\N	\N	\N
9391	BA neu & unbekannt			\N	\N	\N	\N
11407	BA neu & unbekannt			\N	\N	\N	\N
90305	BA neu & unbekannt			\N	\N	\N	\N
83005	BA neu & unbekannt			\N	\N	\N	\N
9222	BA neu & unbekannt			\N	\N	\N	\N
83507	BA neu & unbekannt			\N	\N	\N	\N
14604	BA neu & unbekannt			\N	\N	\N	\N
90107	BA neu & unbekannt			\N	\N	\N	\N
90102	BA neu & unbekannt			\N	\N	\N	\N
92402	ANGL S	BA 25% Sprachwissenschaft Englische Philologie	NF	835	35	BA Studiengang Englische Philologie: Sprachwissenschaft, 25% Nebenfach	BA program English Philology: Linguistics, 25% minor subject
12707	BA neu & unbekannt			\N	\N	\N	\N
14605	BA neu & unbekannt			\N	\N	\N	\N
90502	BA neu & unbekannt			\N	\N	\N	\N
93707	BA neu & unbekannt			\N	\N	\N	\N
8792	BA neu & unbekannt			\N	\N	\N	\N
6805	BA neu & unbekannt			\N	\N	\N	\N
84407	BA neu & unbekannt			\N	\N	\N	\N
90405	BA neu & unbekannt			\N	\N	\N	\N
8821	BA neu & unbekannt			\N	\N	\N	\N
6804	BA neu & unbekannt			\N	\N	\N	\N
9012	BA neu & unbekannt			\N	\N	\N	\N
90604	BA neu & unbekannt			\N	\N	\N	\N
90505	BA neu & unbekannt			\N	\N	\N	\N
9121	BA neu & unbekannt			\N	\N	\N	\N
82107	BA neu & unbekannt			\N	\N	\N	\N
90504	BA neu & unbekannt			\N	\N	\N	\N
90402	BA neu & unbekannt			\N	\N	\N	\N
90404	BA neu & unbekannt			\N	\N	\N	\N
5005	BA neu & unbekannt			\N	\N	\N	\N
9132	BA neu & unbekannt			\N	\N	\N	\N
9362	BA neu & unbekannt			\N	\N	\N	\N
9461	BA neu & unbekannt			\N	\N	\N	\N
9231	BA neu & unbekannt			\N	\N	\N	\N
9401	BA neu & unbekannt			\N	\N	\N	\N
8901	BA neu & unbekannt			\N	\N	\N	\N
83004	BA neu & unbekannt			\N	\N	\N	\N
94802	BA neu & unbekannt			\N	\N	\N	\N
14502	BA neu & unbekannt			\N	\N	\N	\N
8671	BA neu & unbekannt			\N	\N	\N	\N
9271	BA neu & unbekannt			\N	\N	\N	\N
8798	BA neu & unbekannt			\N	\N	\N	\N
9418	BA neu & unbekannt			\N	\N	\N	\N
1498	BA neu & unbekannt			\N	\N	\N	\N
9438	BA neu & unbekannt			\N	\N	\N	\N
9428	BA neu & unbekannt			\N	\N	\N	\N
8208	BA neu & unbekannt			\N	\N	\N	\N
9408	BA neu & unbekannt			\N	\N	\N	\N
9248	BA neu & unbekannt			\N	\N	\N	\N
9448	BA neu & unbekannt			\N	\N	\N	\N
9238	BA neu & unbekannt			\N	\N	\N	\N
9228	BA neu & unbekannt			\N	\N	\N	\N
9398	BA neu & unbekannt			\N	\N	\N	\N
82105	BA neu & unbekannt			\N	\N	\N	\N
8811	BA neu & unbekannt			\N	\N	\N	\N
5002	BA neu & unbekannt			\N	\N	\N	\N
9361	BA neu & unbekannt			\N	\N	\N	\N
9201	BA neu & unbekannt			\N	\N	\N	\N
90605	BA neu & unbekannt			\N	\N	\N	\N
200923	HCA	HCA am Anglistischen Seminar	NF		\N	\N	\N
16005	BA neu & unbekannt			\N	\N	\N	\N
8481	BA neu & unbekannt			\N	\N	\N	\N
84104	BA neu & unbekannt			\N	\N	\N	\N
200822	Anglistik Lehramt modular	Anglistik Lehramt nach GymPO	HF	835	104	Anglistik Lehramt für die Gymnasiale Oberstufe	English Teaching Degree for Secondary Schools
210810	AS:MA	Hauptfach MA Anglistik Sprachwissenschaft	HF	\N	70	MA Studiengang English Studies: Sprachwissenschaft, Hauptfach	MA program English Studies: Linguistics, major subject
200317	BA 50% Anglistik: 1.HF ab 2010/11	Bachelor 50% Englische Philologie (1. HF, Prüfungsordnung ab 1.10.2010)	HF	835	84	BA Studiengang Englische Philologie, 50%, 1. Hauptfach	BA program English Philology, 50%, first major subject
83505	ANGL 1	BA 50% Englische Philologie (1. HF)	HF	835	84	BA Studiengang Englische Philologie, 50%, 1. Hauptfach	BA program English Philology, 50%, first major subject
83907	ANGL	BA 75% Englische Philologie	HF	835	133	BA Studiengang Englische Sprach- Literatur- und Kulturwissenschaft, 75% Hauptfach	BA program English Linguistics, Literary and Cultural Studies, 75% major subject
200216	BA 75% Anglistik ab 2010/11	Bachelor 75% Englische Philologie (Prüfungsordnung ab 1.10.2010)	HF	835	133	BA Studiengang Englische Sprach- Literatur- und Kulturwissenschaft, 75% Hauptfach	BA program English Linguistics, Literary and Cultural Studies, 75% major subject
210811	AS:MA	Hauptfach MA Anglistik Literaturwissenschaft	HF	\N	70	MA Studiengang English Studies: Literaturwissenschaft, Hauptfach	MA program English Studies: Literary Studies, major subject
210812	AS:MA	Begleitfach MA Anglistik Sprachwissenschaft	NF	\N	20	MA Studiengang English Studies: Literaturwissenschaft, Begleitfach	MA program English Studies: Literary Studies, minor subject
210813	AS:MA	Begleitfach MA Anglistik Literaturwissenschaft	NF	\N	20	MA Studiengang English Studies: Literaturwissenschaft, Begleitfach	MA program English Studies: Literary Studies, minor subject
92502	BA neu & unbekannt			\N	\N	\N	\N
9168	BA neu & unbekannt			\N	\N	\N	\N
200001	NF-BA/MA-Escape, cl	Deutsch als Fremdsprachenphilologie	NF	\N	\N	\N	\N
210814	AS:MA	Begleitfach MA Anglistik Methodologie und Forschungspraxis	NF	\N	\N	\N	\N
84402	BA neu & unbekannt			\N	\N	\N	\N
82005	BA neu & unbekannt			\N	\N	\N	\N
200721	BA 25% Sprachwiss. Anglistik ab 2010/11	Bachelor 25% Sprachwissenschaft Englische Philologie (Prüfungsordnung ab 1.10.2010)	NF	835	35	BA Studiengang Englische Philologie: Sprachwissenschaft, 25% Nebenfach	BA program English Philology: Linguistics, 25% minor subject
200620	BA 25% Literaturwiss. Anglistik ab 2010/11	Bachelor 25% Literaturwissenschaft Englische Philologie (Prüfungsordnung ab 1.10.2010)	NF	835	35	BA Studiengang Englische Philologie: Literaturwissenschaft, 25% Nebenfach	BA program English Philology: Literary Studies, 25% minor subject
92302	ANGL L	BA 25% Literaturwissenschaft Englische Philologie	NF	835	35	BA Studiengang Englische Philologie: Literaturwissenschaft, 25% Nebenfach	BA program English Philology: Literary Studies, 25% minor subject
92202	ANGL K	BA 25% Kulturwissenschaft Englische Philologie	NF	835	35	BA Studiengang Englische Philologie: Kulturwissenschaft, 25% Nebenfach	BA program English Philology: Cultural Studies, 25% minor subject
200519	BA 25% Kulturwiss. Anglistik ab 2010/11	Bachelor 25% Kulturwissenschaft Englische Philologie (Prüfungsordnung ab 1.10.2010)	NF	835	35	BA Studiengang Englische Philologie: Kulturwissenschaft, 25% Nebenfach	BA program English Philology: Cultural Studies, 25% minor subject
83504	ANGL 2	BA 50% Englische Philologie (2. HF)	HF	835	84	BA Studiengang Englische Philologie, 50%, 2. Hauptfach	BA program English Philology, 50%, second major subject
200418	BA 50% Anglistik: 2.HF ab 2010/11	Bachelor 50% Englische Philologie (2. HF, Prüfungsordnung ab 1.10.2010)	HF	835	84	BA Studiengang Englische Philologie, 50%, 2. Hauptfach	BA program English Philology, 50%, second major subject
200115	Lehramt Germanistik modular	Lehramt Germanistik ab Wintersemester 2010/11 (modularisiert)	HF		104	Germanistik Lehramt für die Gymnasiale Oberstufe	German Teaching Degree for Secondary Schools
6705	GERM 1	BA 50% Germanistik, 1. HF	HF	\N	84	BA Studiengang Deutsche Philologie, 50% 1. Hauptfach	BA program German Philology, 50% first major subject
8908	BA neu & unbekannt			\N	\N	\N	\N
9481	BA neu & unbekannt			\N	\N	\N	\N
5204	BA neu & unbekannt			\N	\N	\N	\N
84405	BA neu & unbekannt			\N	\N	\N	\N
1608	BA neu & unbekannt			\N	\N	\N	\N
85204	BA neu & unbekannt			\N	\N	\N	\N
90602	BA neu & unbekannt			\N	\N	\N	\N
9261	BA neu & unbekannt			\N	\N	\N	\N
90905	BA neu & unbekannt			\N	\N	\N	\N
84404	BA neu & unbekannt			\N	\N	\N	\N
9501	BA neu & unbekannt			\N	\N	\N	\N
8918	BA neu & unbekannt			\N	\N	\N	\N
9331	BA neu & unbekannt			\N	\N	\N	\N
83107	BA neu & unbekannt			\N	\N	\N	\N
9308	BA neu & unbekannt			\N	\N	\N	\N
5004	BA neu & unbekannt			\N	\N	\N	\N
9298	BA neu & unbekannt			\N	\N	\N	\N
1738	BA neu & unbekannt			\N	\N	\N	\N
54805	BA neu & unbekannt			\N	\N	\N	\N
210915	MA Hauptfach Linguistik Solo 2012	MA Hauptfach, Schwerpunkt Linguistik, anderes Beifach, PO ab Sommer 2012	HF		100	MA Hauptfach English Studies Sprachwissenschaft	MA English Studies: linguistics (major subject)
211016	MA Hauptfach Literaturwissenschaft Solo 2012	 MA Hauptfach, Schwerpunkt Literaturwissenschaft, anderes Beifach, PO ab Sommer 2012	HF		100	MA Hauptfach English Studies Literaturwissenschaft	MA English Studies: literary studies (major subject)
211117	MA Beifach Linguistik 2012	MA Beifach, Schwerpunkt Linguistik, anderes Beifach, PO ab Sommer 2012	NF		20	MA Begleitfach English Studies Sprachwissenschaft	MA English Studies: linguistics (minor subject)
211218	MA Beifach Literaturwissenschaft 2012	MA Beifach, Schwerpunkt Literaturwissenschaft, PO ab Sommer 2012	NF		20	MA Begleitfach English Studies Literaturwissenschaft	MA English Studies: literary studies (minor subject)
211319	MA HF Linguistik Kombi 2012	MA Hauptfach, Schwerpunkt Linguistik, Beifach Literaturwissenschaft, PO ab Sommer 2012	HF		120	MA English Studies: Hauptfach Sprach- und Begleitfach Literaturwissenschaft	MA English Studies: linguistics (major subject) and literary studies (minor subject)
211420	MA HF Literaturwissenschaft Kombi 2012	MA Hauptfach, Schwerpunkt Literaturwissenschaft, Beifach Linguistik, PO ab Sommer 2012	HF		120	MA English Studies: Hauptfach Literatur- und Begleitfach Sprachwissenschaft	MA English Studies: literary studies (major subject) and linguistics (minor subject)
2902	BA neu & unbekannt			\N	\N	\N	\N
8391	BA neu & unbekannt			\N	\N	\N	\N
85205	BA neu & unbekannt			\N	\N	\N	\N
93702	BA neu & unbekannt			\N	\N	\N	\N
2907	BA neu & unbekannt			\N	\N	\N	\N
9371	BA neu & unbekannt			\N	\N	\N	\N
8528	BA neu & unbekannt			\N	\N	\N	\N
8521	BA neu & unbekannt			\N	\N	\N	\N
230000	Klassische Philologie	Klassische Philologie	\N	\N	4711	\N	\N
6702	GERM	BA 25% Germanistik	NF	\N	35	BA Studiengang Deutsche Philologie, 25% Nebenfach	BA program German Philology, 25% minor subject
6704	GERM 2	BA 50% Germanistik, 2. HF	HF	\N	84	BA Studiengang Deutsche Philologie, 50% 2. Hauptfach	BA program German Philology, 50% second major subject
300000	MA Deutsche Philologie Hauptfach, Schwerpunkt Linguistik	MA German Philology major subject, focus on linguistics	H		100	MA Deutsche Philologie Hauptfach, Schwerpunkt Linguistik	MA German Philology major subject, focus on linguistics
300020	MA Deutsche Philologie Hauptfach, Schwerpunkt Medivistik	MA German Philology major subject, focus on medieval studies	H		100	MA Deutsche Philologie Hauptfach, Schwerpunkt Medivistik	MA German Philology major subject, focus on medieval studies
300010	MA Deutsche Philologie Hauptfach, Schwerpunkt Neuere Deutsche Literatur	MA German Philology major subject, focus on literature	H		100	MA Deutsche Philologie Hauptfach, Schwerpunkt Neuere Deutsche Literatur	MA German Philology major subject, focus on literature
300100	MA Deutsche Philologie Begleitfach, Schwerpunkt Linguistik	MA German Philology minor subject, focus on linguistics	H		20	MA Deutsche Philologie Begleitfach, Schwerpunkt Linguistik	MA German Philology minor subject, focus on linguistics
300120	MA Deutsche Philologie Begleitfach, Schwerpunkt Medivistik/Frhe Neuzeit	MA German Philology minor subject, focus on medieval studies	H		20	MA Deutsche Philologie Begleitfach, Schwerpunkt Medivistik/Frhe Neuzeit	MA German Philology minor subject, focus on medieval studies
300110	MA Deutsche Philologie Begleitfach, Schwerpunkt Neuere Deutsche Literatur	MA German Philology minor subject, focus on literature	H		20	MA Deutsche Philologie Begleitfach, Schwerpunkt Neuere Deutsche Literatur	MA German Philology minor subject, focus on literature
\.


--
-- TOC entry 2789 (class 0 OID 219684)
-- Dependencies: 191 2810
-- Data for Name: tblSdFakultaet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdFakultaet" ("lngSdUniID", "lngSdFakultaetID", "strFakultaetUnivISID", "strFakultaetNr", "strFakultaetName", "strFakultaetLink") FROM stdin;
0	0		9	Neuphilologie	http://www.shj-online.de
\.


--
-- TOC entry 2790 (class 0 OID 219694)
-- Dependencies: 192 2810
-- Data for Name: tblSdKurstyp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdKurstyp" ("lngSdSeminarID", "lngKurstypID", "strKurstypUnivISID", "strKurstypBezeichnung", "strKurstypBeschreibung", "intKurstypSemesterMinimum", "strKurstypEinordnung", "blnKurstypFormularanmeldung", "blnKurstypKvvOnlyGrouped", "intKurstypSequence", "lngKurstypLeistungsID", "sngKurstypCreditPts", "intKurstypSemesterMin", "intKurstypSemesterMax", "blnKurstypTeilmodul", "blnKurstypVv", "strKurstypCustom1", "strKurstypCustom2", "strKurstypCustom3", "strKurstypBezeichnung_en", "strKurstypBeschreibung_en", "strKurstypCustom1_en", "strKurstypCustom2_en", "strKurstypCustom3_en", "intKurstypCommitmentMode", "intKurstypKurswahlMin", "intKurstypTauschMin", "intKurstypTauschMax") FROM stdin;
1	38		Tutorium EV Sprachwissenschaft	\N	0		t	t	100	0	4	0	25	\N	\N									0	3	5	15
1	4		Pronunciation Practice BE	This is a class in the language lab which aims at improving your English pronunciation. As it is largely based on the theoretical knowledge you\r\nacquire in the lecture Introduction to English Phonology and Phonetics, it should be taken in the same semester as the lecture, but certainly not before the lecture. The Schein that you receive for passing this class is the so-called "Aussprachetest." You have to sign up online for either British English (BE) or American English (AE) classes before the start of the semester in order to obtain a place. Please note that you will lose your place in this course if you do not attend the first session (N.B.: courses start in the 1st week of the semester).	0		t	t	700	3	1	0	25	f	f		\N	\N			\N	\N	\N	0	2	5	15
1	22		Pronunciation Practice AE	This is a class in the language lab which aims at improving your English pronunciation. As it is largely based on the theoretical knowledge you\r\nacquire in the lecture Introduction to English Phonology and Phonetics, it should be taken in the same semester as the lecture, but certainly not before the lecture. The Schein that you receive for passing this class is the so-called "Aussprachetest." You have to sign up online for either British English (BE) or American English (AE) classes before the start of the semester in order to obtain a place. Please note that you will lose your place in this course if you do not attend the first session (N.B.: courses start in the 1st week of the semester).	0		t	t	710	3	1	0	25	f	t		\N	\N			\N	\N	\N	0	2	5	15
1	32	\N	Tutorium EV Literaturwissenschaft	Die Termine für die Tutorien stehen noch nicht fest!	0	\N	f	t	110	1	4	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	3	5	15
1	5	\N	Grammar/Tense and Aspect	The aims of this course are twofold: to help you use tense and aspect correctly, and to help you identify typical errors and explain your corrections. Almost all the classes (regular attendance: 1 credit point) will be based on homework set the week before (estimated homework time: 2 hours per week, 1 credit point). Your grade will be based on a centralized exam at the end of the course (1 credit point).	0	\N	t	t	715	5	3	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	4	5	25
1	21		Oberseminare		0		f	f	500	500	0	0	25	\N	\N									0	2	5	25
1	40		Projektseminar		0		f	f	400	21	8	0	25	\N	\N									0	2	5	25
1	37	\N	Grammar and Style I (Lecture)	\N	0	\N	f	t	0	5	0	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	16	\N	Proseminar I Sprachwissenschaft	\N	0	\N	f	f	200	11	5	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	30090		Planung und Durchführung von Forschungsprojekten		0		f	\N	0	30090	3	0	25	\N	\N				Research Design					0	2	5	25
1	30100		Einführung ins Projektmanagementn		0		f	\N	0	30100	3	0	25	\N	\N				Introduction to Project Management					0	2	5	25
1	33		Translation into German for Foreign Exchange Students		0		f	f	0	\N	0	0	25	\N	\N									0	2	5	25
1	39		Preparation Course for Assistant Teachers		0		f	f	660	\N	0	0	25	\N	\N									0	2	5	25
1	13	\N	Phonetik	\N	0	\N	f	f	10	4	4	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	30080		Projektseminar Literaturwissenschaft		0		f	\N	0	30080	8	0	25	\N	\N				Project Seminar Literature					0	2	5	25
1	26	\N	Text in Context	Dieser Veranstaltungstyp ist besonders geeignet für\r\nExamenskandidatinnen und -kandidaten.<br><br>Die angemessene Vorbereitung auf die Spezialgebiete im Staatsexamen oder in der Magisterprüfung verlangt die Fähigkeit, ein Werk in seiner literaturgeschichtlichen Zugehörigkeit und in seinem kulturellen und sozialgeschichtlichen Kontext zu deuten. Demgemäß bieten die als Lektürekurse konzipierten Veranstaltungen Ihnen einen Rahmen, innerhalb dessen Sie Ihre eigenverantwortliche Beschäftigung mit den Texten einer Epoche durch Präsentation und Diskussion vertiefen können. Behandelt werden exemplarisch ausgewählte Werke der jeweiligen Epoche auf der Basis der "Lektüreliste zur Vorbereitung auf die Interpretationsklausur im Staatsexamen" (cf. <i>Studienführer</i>). Neben der interpretatorischen Arbeit werden auch Hilfsmittel und Wege zur Erschließung größerer Zusammenhänge besprochen.	0	\N	f	f	610	500	0	0	25	f	f		\N	\N	Text in Context	\N	\N	\N	\N	0	2	5	25
1	20	\N	Hauptseminare Sprachwissenschaft	\N	0	\N	f	f	300	21	8	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	19	\N	Hauptseminar Literaturwissenschaft	\N	0	\N	f	f	310	16	8	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	30040		Mündliche Abschlussprüfung MA		0		f	\N	0	30040	4	0	25	\N	\N				Final Oral Examination MA					0	2	5	25
1	30050		MA Abschlussarbeit		0		f	\N	0	30050	30	0	25	\N	\N				MA Thesis					0	2	5	25
1	35		Translation II for Non-Native Speakers of German		0		f	t	0	\N	0	0	25	\N	\N									0	2	5	25
1	30070		Oberseminar Literaturwissenschaft		0		f	\N	0	30070	8	0	25	\N	\N				Graduate Seminar Literature					0	2	5	25
1	-1	\N	Sonstiges	\N	0	\N	f	f	0	0	4	0	0	f	t		\N	\N	Other	\N	\N	\N	\N	0	2	5	25
1	20200	\N	Mündliche und Schriftliche Präsentation von Forschung auf Englisch	\N	0	\N	f	f	737	20200	0	0	0	f	f		\N	\N	Oral and Written Presentation of Research in English	\N	\N	\N	\N	0	2	5	25
1	0		Dummy		0		f	\N	0	\N	0	0	25	\N	\N									0	2	5	25
1	12	\N	Fachdidaktik	\N	0	\N	f	f	650	50	0	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	2		Einführung Literaturwissenschaft		0		f	f	70	1	4	0	25	f	f		\N	\N			\N	\N	\N	0	2	5	25
1	11	\N	Grammar and Style II	\N	0	\N	f	f	0	14	0	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	10100	\N	Übergreifende Kompetenzen/Übungen	In einem gemeinsamen interdisziplinären Lehrveranstaltungspool Übergreifende\r\nKompetenzen werden von den Instituten und Seminaren der Neuphilologischen, der Philosophischen und der Theologischen Fakultät ausgewählte Lehrveranstaltungen auch für\r\nfachfremde Studierende geöffnet, die im Rahmen ihres Bachelor-Studiums Leistungspunkte aus dem Bereich der Übergreifenden Kompetenzen erwerben können. Ist die Teilnehmerzahl einer Veranstaltung beschränkt, so werden die eigenen Studierenden des Faches bevorzugt aufgenommen; es empfiehlt sich also eine frühzeitige Anmeldung bzw. Nachfrage bei den Dozenten/Dozentinnen, ob noch Plätze zur Verfügung stehen.<br />\r\nBitte entnehmen Sie die Informationen zur Art des Leistungsnachweises und zur Anzahl der zu vergebenen Leistungspunkte den kommentierten Vorlesungsverzeichnissen oder erfragen Sie diese direkt bei den Dozenten/Dozentinnen der Lehrveranstaltungen.<br />\r\nGrundsätzlich gilt für den Erwerb von Leistungspunkten:<br />\r\na) Die bloße Teilnahme an einer Veranstaltung reicht nicht aus - es ist auf jeden Fall ein Leistungsnachweis zu erbringen, der allerdings in der Regel unbenotet ist.<br />\r\nb) Wenn Sie nicht sicher sind, ob Ihnen eine Veranstaltung, die Sie besuchen möchten, für den Bereich Übergreifende Kompetenzen angerechnet werden kann, wenden Sie sich bitte an den zuständigen Studienberater desjenigen Faches, in dem die Anrechnung erfolgen soll.\r\nDie für das aktuelle Semester gemeldeten Veranstaltungen können Sie online über\r\n<a href="http://lsf.uni-heidelberg.de">LSF (http://lsf.uni-heidelberg.de)</a> abfragen: über Veranstaltungssuche gelangen Sie auf\r\neine Suchmaske, in der Sie durch Anklicken von Ja in der letzten Zeile Übergreifende\r\nKompetenzen und die Auswahl der drei oben genannten Fakultäten unter Einrichtung den\r\ngesamten Pool abrufen können. Sollten Sie Ihre Suche einschränken wollen (z.B. auf einzelne Fakultäten oder Fächer usw.), so können Sie das durch eine spezifischere Auswahl im Feld Einrichtung und/oder mit Hilfe der andern Suchkriterien tun. <br />\r\nDas anglistische Seminar bietet folgende Veranstaltungen an, die <b>von Studierenden der Anglistik nutzbar</b> sind.\r\n	0	\N	f	f	850	7110	0	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	1	\N	Einführung Sprachwissenschaft	Diese Vorlesung mit Begleittutorien soll in den wissenschaftlichen Umgang mit Sprache einführen,\r\neine Vorstellung von der Komplexität des Gebietes der Sprachwissenschaft vermitteln und die\r\nGrundlagen schaffen für die Behandlung spezieller sprachwissenschaftlicher Fragestellungen in den\r\nweiterführenden Pro- und Hauptseminaren.\r\n	0	\N	f	t	60	0	4	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	20100	\N	Advanced Writing:  Academic Writing for MA Students	\N	0	\N	f	f	742	20100	0	0	0	f	t		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	34		Grammar/Tense and Aspect for Repeat Students	Only students who have failed Grammar 1 in a previous semester may register for this course! \r\n\r\nStudents in the Repeat Course will be asked to approach the learning materials with more self-reliance than in the original course. They will be expected to review the Grammar 1 handouts and formulate questions for class discussion as homework. Class work will then consist of in-depth discussion of typical mistakes and exam type exercises.	0		t	t	720	5	0	0	25	\N	\N									0	1	5	25
1	10050	\N	Vorlesung moderne Sprachwissenschaft	\N	0	\N	t	f	30	10050	4	0	25	f	f	BA	\N	\N	\N	\N	\N	\N	\N	0	1	5	25
1	10110	\N	Stylistics/Grammar and Style II	\N	0	\N	t	f	745	10110	4	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	4	5	25
1	10130	\N	English in Use	\N	0	\N	t	f	735	10130	3	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	10140	\N	Advanced English in Use	\N	0	\N	t	f	755	10140	4	0	25	f	f	BA	\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	10040	\N	Vorlesung historische Sprachwissenschaft	\N	0	\N	t	f	30	10040	4	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	1	5	25
1	20230		Fachdidaktik II	Fachdidaktik GymPO nach Praxissemester	0		t	f	652	20230	5	0	0	f	f	GY	\N	\N	Specialized Didactics 2		\N	\N	\N	0	3	5	25
1	10020	\N	Proseminar II historische Sprachwissenschaft (Überblick)	Einführung in die Grundbegriffe und Methoden der historischen Sprachwissenschaft; Vermittlung von Überblickswissen über alle Perioden der Geschichte des Englischen von den Anfängen bis zur Gegenwart; Einführung in die grundlegenden Prozesse und Faktoren des Sprachwandels; Befähigung zur Beschreibung ausgewählter Sprachwandelphänomene aus sprachinterner und\r\nexterner Perspektive. Verständnis der grundlegenden typologischen Umgestaltung der englischen Sprache.	0	\N	f	f	210	10020	6	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	10030	\N	Proseminar II moderne Sprachwissenschaft	Vermittlung von Einsichten im Bereich der angewandten englischen Sprachwissenschaft, d.h. in die Soziolinguistik, vergleichende Linguistik oder Psycholinguistik. Kenntnis der relevanten Methoden zur Beschreibung von variablem Sprachgebrauch, Sprachvergleich bzw. Spracherwerb und -verarbeitung; Gewinnung und Analyse authentischer Daten. Ziel des Proseminars ist die empirische Untersuchung von Einzelphänomenen, die Erstellung und Verwendung     von Datenbanken, sowie eine vertiefte Auseinandersetzung mit den einschlägigen Theorien, Methoden und Hypothesen.<br>\r\n<b>In diesen Kursen können Studierende im Studiengang Magister oder Staatsexamen einen Schein "PS I Sprachwissenschaft" erwerben.	0	\N	f	f	225	10030	6	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	28		Vorbereitungskurs für Examenskandidaten	This course will prepare you for Klausur I of the Staatsexamen. We will go through a past exam each week, and you will have the opportunity to have homework marked and graded on a regular basis. The course will conclude with a mock exam.<br />\r\nNote: This course is only open to students taking their exams at the end of the term.\r\n\r\nRegistration: Registration is through SignUp only.	0		t	f	620	500	0	0	25	f	f	LA								0	3	5	25
1	10120		Advanced Writing/Academic Essay Writing	Teilnahmevoraussetzungen.\r\n\r\nNew Lehramt: Tense and Aspect, Essential Skills for Writing.\r\n\r\nOld Lehramt: Grammar 1, Translation 1, Writing 1.\r\n\r\nNew 75% BA: Essential Skills for Writing (Tense and Aspect recommended).\r\n\r\nNew 50% BA: Essential Skills for Writing.\r\n\r\nOld 75% BA: Phonetics, Grammar, Writing, Translation.\r\n\r\nOld 50% BA: Phonetics, Grammar, Writing.	0		t	f	740	10120	4	0	25	f	f		\N	\N		This course offers you the opportunity to improve your language skills while learning to organize and write various types of academic papers. It will cover strategies for approaching writing assignments,\r\ntools such as outlines and game plans for structuring your papers, and proofreading and editing tips to help you polish your work. After completing the class, you will be prepared to write the kinds of academic essays most often required for university courses as well as on essay examinations.   	\N	\N	\N	0	1	5	25
1	20005		Exposition and Argumentation	Only for Staatsexamen and BA students who began their studies in winter 2010/11 or later (or who switch to the new Prüfungsordnung). All other students please look at "Stylistics".\r\n\r\nTeilnahmevoraussetzungen:\r\n\r\nNew Lehramt: Tense and Aspect, Structure and Idiom, Essential Skills for Writing, Academic Essay Writing.\r\n\r\nOld Lehramt: Grammar 1, Translation 1, Writing 1.\r\n\r\nNew 75% BA: Tense and Aspect, Structure and Idiom, Essential Skills for Writing, Academic Essay Writing.\r\n\r\nNew 50% BA: Essential Skills for Writing, Academic Essay Writing.\r\n\r\nOld 75% BA: Phonetics, Grammar, Writing, Translation.\r\n\r\nOld 50% BA: Phonetics, Grammar, Writing.	0		t	f	746	20005	4	0	0	f	f		\N	\N	Exposition and Argumentation	The intention of this course is to enable students to understand and produce expository and argumentative texts, that is to say, texts that describe, explain, argue and persuade. We will be dealing with a wide variety of written texts and styles of language, but concentrating on non-fiction (to distinguish this course from "Text Types: Description and Narration").  	\N	\N	\N	0	3	5	25
1	9	\N	Translation II (E-G)	In this course you will learn to translate English-language literary texts into German using tools which help you reproduce for your readers the effects which the original authors create for theirs. To achieve this aim, you will learn the limitations of word-by-word translation and the importance of contextuality.  We will see that the sentence cannot be understood and translated in isolation from the paragraph nor the paragraph in isolation from the entire text.  Consequently, we will acknowledge these textual relationships and base our choices as translators on a thorough literary and linguistic analysis of the originals.\r\nCourse requirements:\r\na) steady attendance and active class participation (regular homework assignments to be handed in); b) a group project; and c) a final exam in form of an in-class translation\r\n	0	\N	t	t	750	18	4	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	31		Ethisch-philosoph. Grundlagenstudium II		0		f	f	800	22	6	0	25	f	f		\N	\N			\N	\N	\N	0	2	5	25
1	6		Writing/Essential Skills for Writing	This is a pre-essay-writing course in which you will learn to compose well-structured and varied sentences. The course will deal with coordination and subordination, non-finite and verbless clauses, relative clauses and the noun phrase, and thematization. Emphasis will be placed on both analysis and production. Exercise types will include error detection and correction and elementary paragraph production. \r\n<b>New LA students should have passed Tense & Aspect to register for this course! 75% BA students are advised to take Tense & Aspect before registering for this course.</b><br><br>\r\n3 Leistungspunkte (regular attendance: 1 LP, homework time: 1 LP, exam: 1 LP)	0		t	t	725	12	3	0	25	f	f		\N	\N			\N	\N	\N	0	4	5	25
1	7		Translation into English/Structure and Idiom	This course is intended to be taken after Tense & Aspect (Grammar/Grammar and Style I), and after or alongside Essential Skills for Writing (Writing/Writing I). The course deals with contrastive problems for native speakers of German, concentrating, typically, on problems of grammar rather than vocabulary. Typical problem areas are: conditionals, modality, reported speech, adverbs/adjectives, gerund/infinitive, word order. The German texts that are translated will usually have been adapted in order to concentrate on these problem areas.\r\n3 Leistungspunkte (regular attendance: 1 LP, homework time: 1 LP, exam:\r\n 1 LP)	0		t	t	730	13	3	0	25	f	f		\N	\N			\N	\N	\N	0	4	5	25
1	20000		Description and Narration	Only for Staatsexamen and BA students who began their studies in winter 2010/11 or later (or who switch to the new Prüfungsordnung). All other students please look at "Stylistics".\r\n\r\nTeilnahmevoraussetzungen:\r\n\r\nNew Lehramt: Tense and Aspect, Structure and Idiom, Essential Skills for Writing, Academic Essay Writing.\r\n\r\nOld Lehramt: Grammar 1, Translation 1, Writing 1.\r\n\r\nNew 75% BA: Tense and Aspect, Structure and Idiom, Essential Skills for Writing, Academic Essay Writing.\r\n\r\nNew 50% BA:  Essential Skills for Writing, Academic Essay Writing.\r\n\r\nOld 75% BA: Phonetics, Grammar, Writing, Translation.\r\n\r\nOld 50% BA: Phonetics, Grammar, Writing. 	0		t	f	747	20000	4	0	0	f	f		\N	\N	Description and Narration	The intention of this course is to enable students to understand and produce descriptive and narrative texts. We will start with description, focusing on journal writing as our prime example.  We will then move on to narration, which uses description as one of many elements to tell a story or narrate an event.  In order to illuminate these principles, texts such as hymns, fables, fairy tales, ballads and short stories will be examined, translated and produced throughout the semester.\r\n\r\nStudents who have failed Grammar and Style 2 or Text Types (regardless of the course title or the instructor) in a previous semester must enroll via email for Grammar and Style 2 for Repeat Students, which appears under "Sonstiges" in SignUp.\r\n\r\nEmails should be sent to:\r\n\r\nc.burmedi@urz.uni-heidelberg.de	\N	\N	\N	0	4	5	25
1	30060		Grundlagenkolloquium Literaturwissenschaft		0		f	\N	0	30060	8	0	25	\N	\N				Introduction to Research in Literature					0	2	5	25
1	30010		Oberseminar Linguistik		0		f	\N	0	30010	4	0	25	\N	\N				Graduate Seminar Linguistics					0	2	5	25
1	30		Lektürekurs		0		f	f	900	500	0	0	25	\N	\N									0	2	5	25
1	27	\N	Sprachwissenschaftliche Repetitorien	\N	0	\N	f	f	600	500	0	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	14	\N	Proseminar I Literaturwissenschaft	\N	0	\N	f	f	230	10	5	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	20300		HCA-Proseminar	Proseminar zur Wahl für Studierende des HCA	0	HCA	f	f	0	30200	5	0	0	f	f		\N	\N	HCA-Proseminar		\N	\N	\N	0	2	5	25
1	25	\N	Vorlesungen Literaturwissenschaft	Vermittlung von Überblickswissen über eine Gattung oder Epoche, ggf. unter Zuspitzung auf paradigmatische Problemstellungen oder Autor(inn)en; exemplarische hermeneutische Praxis unter Berücksichtigung der anglistischen Methodenvielfalt; Hinführung zu literaturtheoretischem Bewusstsein.	0	\N	t	f	40	10160	4	0	25	f	f	BA	\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	24		Kolloquien		0		f	f	450	500	0	0	25	\N	\N									0	2	5	25
1	10070	\N	Proseminar I Kulturwissenschaft (theoretisch)	\N	0	\N	f	f	260	10070	5	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	10150	\N	Vorlesung Kulturwissenschaft	Vertiefung im Bereich der Kulturwissenschaft, ihrer Methoden und Theorien.\r\n	0	\N	t	f	50	10150	4	0	0	f	t	BA	\N	\N	\N	\N	\N	\N	\N	0	1	5	25
1	20010		Fundamentals of Research and Writing	Credit only for Staatsexamen and BA students who begin their studies in winter 2010/11 or later (or who switch to the new Prüfungsordnung) and have already passed the Einführungsveranstaltung.	0		f	f	115	20010	2	0	0	f	f		\N	\N	Fundamentals of Research and Writing		\N	\N	\N	0	3	5	25
1	20220		Fachdidaktik I	Fachdidaktik GymPO vor Praxissemester	0		t	f	651	20220	5	0	0	f	f	LA	\N	\N	Specialized Didactics 1		\N	\N	\N	0	2	5	25
1	10090	\N	Proseminar II Kulturwissenschaft/Landeskunde	Befähigung zur theoretisch reflektierten Analyse ausgewählter Phänomene des englischsprachigen Kulturraumes in historischer Perspektive; Befähigung zur kritischen Analyse kultureller\r\nOrdnungs- und Sinngebungen und ihrer medialen Repräsentation.\r\n<br>\r\nLehramtsstudierende können in allen Veranstaltungen dieses Typs einen Landeskundeschein erwerben.	0	\N	f	f	270	10090	6	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	15	\N	Proseminar II Literaturwissenschaft	Befähigung zur sozial-, kultur-, medien- und geistesgeschichtlichen Verortung der Literatur bzw. zur Einordnung in intertextuelle \r\nZusammenhänge; Befähigung zur Einordnung spezifischer literarischer Texte in den größeren Zusammenhang der Geschichte der Gattung bzw. der Literaturgeschichte; Befähigung zur Anwendung von literaturwissenschaftlichen Modellen und Theorien zur Analyse des Funktionspotentials der behandelten Texte;\r\nFähigkeit, historische Differenzen und epochenübergreifende Entwicklungsprozesse         wie Pluralisierung, Modernisierung, Konstruktion     kultureller und nationaler Identitäten und Internationalisierung zu reflektieren.	0	\N	f	f	240	15	6	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	36		Tutorien		0		f	f	1000	500	0	0	25	\N	\N									0	2	5	25
1	10010	\N	Proseminar II historische Sprachwissenschaft (Periode)	Eingehende Untersuchung einer der Epochen der englischen Sprachgeschichte (Altenglisch, Mittelenglisch, Frühneuenglisch, Neuenglisch); Erörterung und umfassende Analyse der zentralen\r\nAnalyseebenen der Sprache (Phonologie,  Morphologie, Lexikologie, Syntax) unter sprachhistorischen Gesichtspunkten; Befähigung zur eigenständigen Lektüre sowie zur sprach- und kulturhistorischen Einordnung grundlegender Texte der jeweiligen Epoche.	0	\N	f	f	220	10010	6	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
1	10080	\N	Proseminar I Kulturwissenschaft (anwendungsorientiert)/Landeskunde	Lehramtsstudierende können hier einen Landeskundeschein erwerben.	0	\N	f	f	250	10080	5	0	25	f	f		\N	\N	\N	\N	\N	\N	\N	0	2	5	25
\.


--
-- TOC entry 2791 (class 0 OID 219719)
-- Dependencies: 193 2810
-- Data for Name: tblSdKvvInhalt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdKvvInhalt" ("lngSdSeminarID", "intSdKvvInhaltNr", "strKvvInhaltHeading", "strKvvInhaltHeadingDescription", "intKvvInhaltHeadingSequence", "strKvvInhaltTyp") FROM stdin;
1	1	Vorlesungen		10	V
1	2	Einführungsveranstaltungen		20	EV
1	3	Proseminare		30	PS
1	4	Hauptseminare		40	HpS
1	5	Projektseminare		50	PrS
1	6	Kolloquien		60	K
1	7	Oberseminare		70	OS
1	8	Examensvorbereitung		80	Rep
1	10	Fachdidaktik		100	Ü
1	1203	Sonstiges	\N	131	S
1	15	Tutorien		140	Tut
1	13	Ethisch-Philosophisches Grundstudium		125	EPG
1	1001	Übergreifende Kompetenzen		150	Ü
1	1102	Sprachpraxis	\N	110	Ü
\.


--
-- TOC entry 2792 (class 0 OID 219727)
-- Dependencies: 194 2810
-- Data for Name: tblSdKvvInhaltXKurstyp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdKvvInhaltXKurstyp" ("lngSdSeminarID", "intKvvInhaltNr", "lngKurstypID", "strCustom1", "strCustom2", "strCustom3") FROM stdin;
1	1	25			
1	1	13			
1	2	38			
1	2	32			
1	3	16			
1	3	15			
1	3	14			
1	4	19			
1	4	20			
1	5	40			
1	6	24			
1	7	21			
1	8	26			
1	8	27			
1	2	1			
1	10	39			
1	1102	20100			
1	1203	-1			
1	1102	10120			
1	1	10150			
1	2	2			
1	13	31			
1	1102	20200			
1	15	36			
1	1	10040			
1	1	10050			
1	3	10010			
1	3	10020			
1	3	10030			
1	3	10070			
1	3	10080			
1	3	10090			
1	1203	30			
1	1102	4			
1	1102	22			
1	1102	5			
1	1102	34			
1	1102	6			
1	1102	7			
1	1102	10130			
1	1102	10110			
1	1102	9			
1	1102	10140			
1	1001	10100			
1	1102	20000			
1	1102	20005			
1	3	20010			
1	10	20220			
1	8	28			
1	7	30070			
1	7	30010			
1	10	20230			
\.


--
-- TOC entry 2793 (class 0 OID 219736)
-- Dependencies: 195 2810
-- Data for Name: tblSdLeistung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdLeistung" ("lngSdSeminarID", "lngLeistungID", "strLeistungBezeichnung", "strLeistungBezeichnung_en", "strLeistungBeschreibung", "strLeistungBeschreibung_en", "strLeistungZuordnung", "sngLeistungCreditPts", "strLeistungCustom1", "strLeistungCustom2", "strLeistungCustom3", "intLeistungCommitmentMode") FROM stdin;
1	50	Fachdidaktik	Didactics			Fachdidaktik	0		\N	\N	0
1	6110	BA: Mündliche Prüfung	BA: Oral Exam	To Do		Abschluss	5				0
1	500	Keiner Leistung zugeordnet				Sonstiges	0				0
1	20	Landeskunde	Landeskunde			Kulturwissenschaft	0		\N	\N	100
1	8	Latinum				Sonstiges	0				0
1	20220	Fachdidaktik I	Didactics I			Fachdidaktik	5				0
1	3	Pronunciation Practice/Aussprachetest	Pronunciation Practice	Die Studierenden erkennen typische Aussprachefehler im Englischen bei sich selbst und Anderen. Sie sind in der Lage, diese Fehler bei sich selbst und Anderen zu korrigieren.		Phonetik	1	Kontaktzeit \\tab \\tab 30 \\par\nKontaktzeit \\tab \\tab 15 \\par\nVor-/Nachbereitung. \\tab \\tab 15	\N	\N	0
1	20210	Orientierungstest				Sonstiges	0				0
1	22	EPG II	Ethics and Philosophy			Sonstiges	6				100
1	18	Translation II (E-G)	Translation II (E-G) (language course)			Sprachpraxis	0	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30			0
1	30040	Mündliche Abschlussprüfung MA	Final Oral Examination MA	To Do		Abschluss	4				0
1	30050	MA Abschlussarbeit	MA Thesis	To Do		Abschluss	30				0
1	30060	Grundlagenkolloquium Literaturwissenschaft	Introduction to Research in Literature			Literaturwissenschaft	8				0
1	30070	Oberseminar Literaturwissenschaft	Graduate Seminar Literature			Literaturwissenschaft	8				0
1	30080	Projektseminar Literaturwissenschaft	Project Seminar Literature			Sonstiges	8				0
1	30090	Planung und Durchführung von Forschungsprojekten	Research Design			Sonstiges	3				0
1	10070	Proseminar I Kulturwissenschaft (theoretisch)	Introductory Seminar in Cultural Studies (theoretical orientation)	Nach erfolgreicher Teilnahme an dieser Veranstaltung sind die Studierenden in der Lage, ein breites Spektrum kulturwissenschaftlicher Theorien und Methoden zu definieren und diese selbständig auf ausgewählte kulturwissenschaftliche\nProblemstellungen anzuwenden. Die Veranstaltung befähigt die Studierenden damit zur theoretisch reflektierten Analyse ausgewählter Phänomene\ndes englischsprachigen Kulturraumes\nin historischer Perspektive. Darüber hinaus haben die Studierenden nach erfolgreichem Abschluss dieser Veranstaltung die theoretischen Grundlagen für ein differenziertes Denken, Verstehen und Handeln in interkulturellen Zusammenhängen erworben.		Kulturwissenschaft	5	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 60 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60 			0
1	10160	Vorlesung Literaturwissenschaft	Lecture Course in Literary Studies	Nach erfolgreichem Absolvieren dieser Veranstaltung haben die Studierenden ihr in der Einführung vermitteltes Wissen über theoretische\nGrundlagen der Literaturwissenschaft sowie über narratologische, dramen- und\nlyriktheoretische Zugänge zur Literatur in der exemplarischen Anwendung auf eine bestimmte Gattung oder Epoche erweitert und vertieft. Sie vermögen dieses Wissen zu reproduzieren und in Zuspitzung\nauf paradigmatische literaturwissenschaftliche\nProblemstellungen zu diskutieren.		Literaturwissenschaft	4	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nmündl. oder schriftl. Prüfung \\tab \\tab 30	\N	\N	100
1	30200	HCA-Proseminar	HCA-Proseminar	Proseminar für Studierende am HCA		Sonstiges	0		\N	\N	0
1	10090	Proseminar II Kulturwissenschaft/Landeskunde	Intermediate Seminar in Cultural Studies	Nach erfolgreicher Teilnahme an dieser Veranstaltung haben die Studierenden ihre im Proseminar I Kulturwissenschaft erworbene Fähigkeit vertieft, ausgewählte Phänomene des englischsprachigen Kulturraumes in historischer Perspektive\ntheoretisch zu reflektieren und zu klassifizieren. Zudem vermögen sie mediale Repräsentationen kultureller Ordnungs- und Sinngebungen selbstständig mithilfe zentraler kulturwissenschaftlicher Konzepte und Methoden vor dem Hintergrund ihres gesellschaftlichen, historischen und politischen Kontext kritisch zu analysieren und in ihrer Relevanz und ihren Auswirkungen zu beurteilen.		Kulturwissenschaft	6	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 90 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60	\N	\N	100
1	5	Grammar/Tense and Aspect	Grammar/Tense and Aspect (language course)	Die Studierenden können nach erfolgreicher Teilnahme an dieser Veranstaltung das englische Tempus- und Aspektsystem korrekt anwenden und die Nuancen des muttersprachlichen Aspektgebrauchs erkennen und verstehen.  Darüber hinaus können die Studierenden typische nicht-muttersprachliche Fehler aufdecken; sie verfügen über das Werkzeug, die Korrektur solcher Fehler einsichtig zu erklären.\\par\nInsgesamt verfügen die Studierenden über ein verschärftes Urteilsvermögen hinsichtlich korrekter sprachlicher Äußerungen.  		Sprachpraxis	3	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 30 \\par\nKlausur \\tab \\tab 30	\N	\N	0
1	20005	Exposition and Argumentation	Exposition and Argumentation (language course)	Nach erfolgreichem Besuch dieser Veranstaltung verfügen die Studierenden über Fertigkeiten und Einsichten, die ihnen die Analyse und das Verfassen von darlegenden und argumentativen Texten ermöglichen.\\par\nDie Studierenden können lange, komplexe Texte in gebotener Kürze zusammenfassen, indem sie die grundlegenden Inhalte präzise herausarbeiten und diese luzid und originalgetreu wiedergeben.  Sie sind in der Lage, Textauszüge unterschiedlichsten Textsorten zuzuordnen und dies detailliert zu begründen, indem sie innere und äußere Merkmale adäquat darlegen. \\par\n Beim Verfassen von Texten wie Editorials, Briefe an Herausgeber und Bewerbungen können die Studierenden klar argumentieren und unter Berücksichtigung kultureller Konventionen ihren Standpunkt logisch konzise sowie stilistisch angemessen darlegen.		Sprachpraxis	4	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30	\N	\N	0
1	10	Proseminar I Literaturwissenschaft	Introductory Seminar in Literary Studies	Die Studierenden können die in der Einführung vermittelten Analysetechniken sicher innerhalb einer Periode der Literaturgeschichte eines englischsprachigen Landes von der Renaissance bis zur Gegenwart anwenden. Sie können mündlich sowie schriftlich in der Fremdsprache Gattungs- bzw. Epochendarstellungen und exemplarische Analysen kanonischer Hauptwerke ausführen.		Literaturwissenschaft	5	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 60 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60 	\N	\N	100
1	15	Proseminar II Literaturwissenschaft	Intermediate Seminar in Literary Studies	Die Studierenden können die zuvor erlernten Analysetechniken über historische Perioden und Grenzen von Genre und Kulturkreis hinweg sicher anwenden. Sie können mündlich sowie schriftlich in der Fremdsprache literaturwissenschaftlich relevante Aspekte über historische, geographische und kulturelle Kontexte hinweg untersuchen und darstellen.		Literaturwissenschaft	6	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 90 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60	\N	\N	100
1	10050	Vorlesung moderne Sprachwissenschaft	Lecture Course in Modern Linguistics	Die Studierenden besitzen vertiefte Kenntnisse einer linguistischen Disziplin, eines linguistischen Prozesses oder bestimmter linguistischer Strukturen. Sie sind in der Lage, angeleitet hochkomplexe Zusammenhänge zu durchschauen und linguistische Methoden kritisch zu bewerten. Sie können ihr Wissen organisieren und wiedergeben.		Sprachwissenschaft	0	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nmündl. oder schriftl. Prüfung \\tab \\tab 30	\N	\N	100
1	10040	Vorlesung historische Sprachwissenschaft	Lecture Course in Historical Linguistics	Die Studierenden besitzen vertiefte Kenntnisse eines historischen Abschnitts des Englischen, des Sprachwandels allgemein und des Wandels einzelner linguistischer Strukturen. Sie sind in der Lage, angeleitet hochkomplexe Zusammenhänge zu durchschauen und historisch-linguistische Methoden kritisch zu bewerten. Sie können ihr Wissen organisieren und wiedergeben.		Sprachwissenschaft	0	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nmündl. oder schriftl. Prüfung \\tab \\tab 30			100
1	20010	Fundamentals of Research and Writing	Fundamentals of Research and Writing	Nach erfolgreicher Teilnahme an dieser Veranstaltung können die Studierenden fremdsprachliche wissenschaftliche Texte gezielt recherchieren, exzerpieren und in englischer Sprache zusammenfassen sowie zitieren. Die Studierenden kennen die Grundsätze guter wissenschaftlicher Praxis.		Sonstiges	2	Kontaktzeit \\tab \\tab 15 \\par\nVor-/Nachbereitung. \\tab \\tab 30 \\par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 15	\N	\N	0
1	5110	Bachelorarbeit	Bachelor Thesis	Die BA-Arbeit soll zeigen, dass der Prüfling in der Lage ist, innerhalb einer vorgegebenen Frist (6 Wochen) ein Problem aus dem Gebiet der Englischen Philologie selbstständig mit wissenschaftlichen Methoden zu bearbeiten.\nDie Arbeit wird mit 12 LP bewertet. Sie wird in dem Teilgebiete verfasst, das als Schwerpunkt gewählt wurde, muss in englischer Sprache verfasst sein und eine deutsche Zusammenfassung enthalten.		Abschluss	12				0
1	17	Proseminar II Sprachwissenschaft	Intermediate Seminar in Linguistics			Sprachwissenschaft	0	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 90 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60			0
1	19	Writing II				Sprachpraxis	0	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30			0
1	21	Hauptseminar Sprachwissenschaft	Advanced Seminar in English Linguistics			Sprachwissenschaft	8	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 90 \\par\nReferat od. äquiv. Leistung \\tab \\tab 30 \\par\nAbschlussprüfung/-arbeit \\tab \\tab 90 \\par	\N	\N	100
1	14	Grammar and Style II				Sprachpraxis	0	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30			0
1	10010	Proseminar II historische Sprachwissenschaft (Periode)	Intermediate Seminar Historical Linguistics (historical period)	Die Studierenden können in der ausgewählten historischen Periode des Englischen Texte lesen und beschreiben. Sie kennen die Merkmale des Englischen der gewählten Zeit auf allen Sprachebenen und sind mit den historischen Kontexten vertraut. Die Studierenden sind mit den in der historischen Linguistik verwendeten Methoden vertraut. Sie sind in der Lage, Sprachwandel zu verstehen und die Konstruktion einer historischen Sprachstufe kritisch zu hinterfragen.		Sonstiges	6	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 90 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60	\N	\N	100
1	20000	Description and Narration	Description and Narration (language course)	Nach erfolgreichem Besuch dieser Veranstaltung haben die Studierenden Fertigkeiten und Einsichten, die ihnen die Analyse und das Verfassen von darstellenden und narrativen Texten ermöglichen.\\par\nDie Studierenden können belletristische Texte bildlich-anschaulich und stilistisch überzeugend verfassen.  Dabei setzen sie textsortenspezifische Kriterien ästhetisch wirksam um, so dass überzeugende Balladen, Fabeln, Märchen usw. entstehen. \\par\nDie Studierenden sind in der Lage, eine Vielzahl von darstellenden und narrativen Textsorten auf ihre Merkmale hin zu überprüfen und ggf. stilgrecht vom Deutschen ins Englische zu übersetzen.  Sie verfügen über das Werkzeug, aus den verschiedensten Texten texsortenspezifische Merkmale herauszufiltern, so dass sie unter Einsatz der eigenen Kreativität Texte ähnlicher Struktur wirkungsvoll verfassen können.		Sprachpraxis	4	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30	\N	\N	0
1	10130	English in Use	English in Use (language course)	Nach erfolgreichem Abschluss dieser Veranstaltung beherrschen die Studierenden die im jeweiligen Kurstitel formulierten Skills und können sie effektiv und gezielt im weiteren Studium und in berufsbezogenen Kontexten einsetzen. Sie können z.B. \\par\n- auf Englisch fachspezifische Themenkomplexe und/oder eigene Arbeitsergebnisse kompetent präsentieren, Plenumsdiskussionen effektiv moderieren und/oder sich mit authentischem Sprachgebrauch angemessen und argumentativ begründet im Diskurs einbringen,\\par\n- englische Texte, Gespräche und Kommunikationsvorgänge analysieren, um relevante (auch kulturspezifische) Aspekte der Kommunikation zu erkennen, sie mit einer entsprechenden Situation im Deutschen vergleichen und kulturspezifische Unterschiede und Ähnlichkeiten feststellen, um interkulturell sprachlich kompetent zu handeln (z.B. wie man jemanden höflich anspricht, wie man ein Gespräch höflich beendet).		Sprachpraxis	3	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 30 \\par\nKlausur \\tab \\tab 30	\N	\N	100
1	10030	Proseminar II moderne Sprachwissenschaft	Intermediate Seminar Modern Linguistics	Die Studierenden können Faktenwissen zu einem sprachwissenschaftlichen Teilgebiet wiedergeben. Sie sind in der Lage, sich mit den wichtigsten Theorien zum Fachgebiet auseinander zu setzen und wenden diese Theorien praktisch an. Sie sind befähigt, mündlich auch komplexe Zusammenhänge verständlich zu präsentieren. Sie können eigene wissenschaftliche Fragestellungen entwickeln und in einer kurzen Hausarbeit bearbeiten. Sie sind sich der Standards einer wissenschaftlichen Arbeitsweise bewusst und befolgen diese.		Sprachwissenschaft	6	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 90 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60	\N	\N	100
1	10020	Proseminar II historische Sprachwissenschaft (Überblick)	Intermediate Seminar Historical Linguistics (historical overview)	Die Studierenden können die wichtigsten Ereignisse und Personen benennen, die die englische Sprache geprägt haben. Sie können die geschichtliche Entwicklung des Englischen auf allen Sprachebenen überblicksartig nachzeichnen und sind in der Lage, Sprachwandelprozesse kritisch zu reflektieren. Die Studierenden kennen die Theorien zum Sprachwandel und die Konstruktion einer historischen Sprachstufe kritisch zu hinterfragen.		Sprachwissenschaft	6	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 90 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60	\N	\N	100
1	20230	Fachdidaktik II	Didactics II			Fachdidaktik	0				0
1	4	Phonetik	Lecture: Introduction to English Phonetics and Phonology	Die Studierenden können grundlegende Fakten und Prozesse der artikulatorischen Phonetik und der Phonologie erklären. Sie sind sich der phonologischen Struktur der englischen Sprache bewusst und können dieses Wissen auf ihre eigene Aussprache im Englischen anwenden.		Phonetik	4	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30	\N	\N	0
1	20100	Advanced Writing:  Academic Writing for MA Students	Advanced Writing:  Academic Writing for MA Students	\N	\N	Sprachpraxis	0	\N	\N	\N	0
1	20200	Mündliche und Schriftliche Präsentation von Forschung auf Englisch	Oral and Written Presentation of Research in English	\N	\N	Sprachpraxis	0	\N	\N	\N	0
1	10110	Stylistics/Grammar and Style II	Stylistics/Grammar and Style II (language course)			Sprachpraxis	4	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30	\N	\N	100
1	16	Hauptseminar Literaturwissenschaft	Advanced Seminar in Literary Studies			Literaturwissenschaft	8	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 90 \\par\nReferat od. äquiv. Leistung \\tab \\tab 30 \\par\nAbschlussprüfung/-arbeit \\tab \\tab 90 \\par	\N	\N	100
1	30000	Grundlagenkolloquium Sprachwissenschaft	Introduction to Research in English Linguistics			Sprachwissenschaft	8				0
1	30010	Oberseminar Linguistik	Graduate Seminar Linguistics			Sprachwissenschaft	4				0
1	30020	Projektseminar Sprachwissenschaft	Project Seminar Linguistics			Sprachwissenschaft	8				0
1	9	Fremdsprachenkenntnisse		in mindestens zwei modernen Fremdsprachen		Sonstiges	0				0
1	30030	Methodologie und Forschungspraxis	Methodology and Research			Sonstiges	8				0
1	30100	Einführung ins Projektmanagementn	Introduction to Project Management			Sonstiges	3				0
1	30110	Independent Studies				Sonstiges	0				0
1	10150	Vorlesung Kulturwissenschaft	Lecture Course in Cultural Studies	Nach erfolgreicher Teilnahme an dieser Veranstaltung verfügen die Studierenden über die Fähigkeit, ein breites Spektrum kulturwissenschaftlicher Theorien und Methoden zu skizzieren und beispielhaft auf ausgewählte kulturelle Phänomene der englischsprachigen Welt anzuwenden. Darüberhinaus besitzen die Studierenden ein geschärftes Bewusstsein für kulturen- und fächerübergreifende Zusammenhänge und vermögen deren gesellschaftliche, politische und ethische Implikationen darzulegen.		Kulturwissenschaft	0	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nmündl. oder schriftl. Prüfung \\tab \\tab 30	\N	\N	100
1	1	Einführung Literaturwissenschaft	Introduction to the Study of English Literatures	Studierende lernen grundlegende Methoden zur literatur- und textwissenschaftlichen Analyse kennen; sie kennen und verstehen die Beschreibungsmodelle für die drei literarischen Großgattungen Lyrik, Erzählprosa und Drama, sowie maßgebliche theoretische Ansätze der Literaturwissenschaft und den Umgang mit Hilfsmitteln auf die Analyse\n  literarischer Texte in englischer Sprache.		Literaturwissenschaft	4	Kontaktzeit \\tab \\tab 30 \\par\nTutorium \\tab \\tab 15 \\par\nVor-/Nachbereitung. \\tab \\tab 45 \\par\nKlausur \\tab \\tab 30 	\N	\N	0
1	0	Einführung Sprachwissenschaft	Introduction to the Study of English Linguistics	Nach erfolgreichem Besuch der Einführungsvorlesung sind Studierende befähigt, die verschiedenen Ebenen des Sprachsystems zu identifizieren. Sie kennen die grundlegenden Analyseeinheiten der Linguistik und vermögen, diese auf einzelne Sprachbeispiele anzuwenden. Die Studierenden verwenden linguistische Terminologie korrekt und angemessen. Sie sind mit den wichtigsten Theorien der Disziplin vertraut und besitzen einen Überblick über die essentiellen empirischen Methoden der Linguistik.		Sprachwissenschaft	4	Kontaktzeit \\tab \\tab 30 \\par\nTutorium \\tab \\tab 15 \\par\nVor-/Nachbereitung. \\tab \\tab 45 \\par\nKlausur \\tab \\tab 30 	\N	\N	0
1	7110	Übergreifende Kompetenzen	Key Qualifications	Das Modul fördert die Ausbildung spezifischer persönlichkeitsbezogener Schlüsselkompetenzen und berufsbezogener Schlüsselqualifikationen der Studierenden. Ziel des Moduls ist es, die Möglichkeiten der Studierenden zu erweitern, sich mit anderen Fächern, anderen Kulturen und anderen Sprachen auseinanderzusetzen. Die Fähigkeiten, mit anderen Disziplinen, ihrer je eigenen Terminologie und Methodologie in einen fruchtbaren Dialog einzutreten, sich auf fremde Kulturen mit ihren je spezifischen Normen, Standards und Traditionen einzustellen und schließlich mit Menschen aus anderen Sprachkreisen in Kommunikation zu kommen, gehören zu den zentralen übergreifenden Kompetenzen und erhalten daher innerhalb des Studiengangs eine herausgehobene Bedeutung.\\par\nDas Modul besteht aus dem Besuch verschiedener Lehrveranstaltungen etwa aus dem Bereich der Vermittlungskompetenz oder der Rhetorischen Kommunikation. Weitere Möglichkeiten (Praktika, Projektarbeit etc.) regelt die Anlage „Übergreifende Kompetenzen“ der Prüfungsordnung (Allgemeiner Teil). \\par\nDas Lehrangebot wird teils vom Lehrprogramm für Hörer aller Fakultäten der Universität Heidelberg zur Verfügung gestellt, teils vom Zentralen Sprachlabor. Der Besuch der Lehrveranstaltungen wird ergänzt durch deren Vor- und Nachbereitung sowie durch Eigenstudium der Studierenden auf dem Gebiet der interdisziplinären und interkulturellen Studien. Konkrete Literaturhinweise für das Eigenstudium werden in allen Lehrveranstaltungen gegeben.\nDie Zusammenstellung des jeweiligen Lehrangebots aus dem gegebenen größeren Rahmen wird in die Verantwortung der Studierenden übertragen. Diese treffen aus dem vorhandenen umfangreichen Angebot eine für ihre Persönlichkeitsbildung und ihre eigenen Qualifikations- und Berufsperspektiven geeignete Auswahl. Eine Inanspruchnahme von Beratung bei der Auswahl der Lehrveranstaltungen und der Gestaltung des Eigenstudiums durch den Modulverantwortlichen ist erwünscht. Die Anerkennung von fachübergreifenden Leistungen übernimmt ebenfalls der Modulverantwortliche.		Sonstiges	0		\N	\N	100
1	13	Translation into English/Structure and Idiom	Translation into English/Structure and Idiom (language course)	Nach erfolgreichem Besuch dieser Veranstaltung besitzen die Studierenden einen geschärften Blick für strukturelle Unterschiede zwischen der deutschen und der englischen Sprache hinsichtlich Satzstruktur, Modalität und Wortschatz.  Durch diese erhöhte Kritikfähigkeit gehen sie mit für deutsche Muttersprachler häufig vorkommenden Fehlerquellen souverän um.\\par\nDie Studierenden können mit den angeeigneten methodischen Strategien ihr Sprachvermögen reflektiert weiterentwickeln.		Sprachpraxis	3	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 30 \\par\nKlausur \\tab \\tab 30	\N	\N	0
1	12	Writing/Essential Skills for Writing	Writing/Essential Skills for Writing (language course)	Nach erfolgreicher Teilnahme an dieser Veranstaltung können die Studierenden logisch strukturierte, kohärente Kurztexte verfassen, die den englischen Normen in Zeichensetzung, Satzstruktur und Wahl der Konnektoren entsprechen.  Darüber hinaus verfügen die Studierenden über eine variantenreichere Schreibkompetenz, so dass sie in der Lage sind, sich einer umfangreichen Palette an Satzstrukturen zu bedienen.  \\par\n\nDie Studierenden sind in der Lage, Texte jeglichen Umfangs und jeglichen Inhalts auf typische Fehler eigenständig zu überprüfen und entsprechend zu verbessern.  Zudem verfügen sie über das Werkzeug, die Korrektur solcher Fehler einsichtig zu erklären.		Sprachpraxis	3	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 30 \\par\nKlausur \\tab \\tab 30	\N	\N	0
1	10140	Advanced English in Use	Advanced English in Use (language course)	Nach erfolgreichem Abschluss der Veranstaltung beherrschen die Studierenden die im jeweiligen Kurstitel beschriebenen Skills und können sie für literatur-, sprach- und kulturwissenschaftliche Frage- und Aufgabenstellungen des Faches effektiv und zielsprachlich einsetzen.\\par\nSie können z.B.\\par\n- verschiedene fiktionale und nicht-fiktionale Text- und Diskurstypen erkennen, in ihrer Sprachlichkeit methodisch fundiert analysieren und für die eigene, zunehmend eigenständige Textproduktion nutzen, z. B. lexikalische Mittel der Textkohäsion gezielt einsetzen, \\par\n- bei der Übersetzung literarischer englischer Texte ins Deutsche im kontrastiven Vergleich sprachlicher Strukturen sprachenpaargebundene, text- und genrespezifische Besonderheiten erkennen (z.B. Textmarkierungen, implizierte Vorwegnahmen, semantische Netze, Ton), in ihrem spezifischen sprach- und kulturhistorischen Kontext verstehen und stilistisch und funktional angemessen und weitgehend ohne Interferenzen aus dem Englischen wiedergeben. 		Sprachpraxis	4	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30			100
1	10120	Advanced Writing/Academic Essay Writing	Advanced Writing/Academic Essay Writing (language course)	Nach erfolgreicher Teilnahme an dieser Veranstaltung sind die Studierenden in der Lage, verschiedene Grade der Abstraktion zu erkennen und sich ihrer effektiv und stilsicher zu bedienen.   Sie verstehen die verschiedenen möglichen Zwecke eines wissenschaftlichen Textes oder eines Teiles davon (wie zum Beispiel einen Prozess beschreiben, ein Konzept definieren, ein literarisches Werk interpretieren) und können beim eigenen Schreiben das passende Muster auswählen und stilistisch angemessen einsetzen. Sie beherrschen verschiedene Methoden zur Organisation von längeren Texten, so dass sie auch zu komplexen Themen klar verständliche und logisch organisierte Essays verfassen können. \\par\nDie Studierenden beherrschen die essenziellen Schritte bei der Konzeption und beim Schreiben wissenschaftlicher Arbeiten, im Besonderen Themenwahl, Entwicklung einer These, Organisation von Argumenten, Techniken zur Überwindung von Schreibblockaden, Überarbeitung und Korrekturen.\\par Durch diese intensive Auseinandersetzung mit dem Schreibprozess sind die Studierenden außerdem in der Lage, ihre eigene Arbeit zu bewerten und konstruktive Kritik zu schriftlichen Arbeiten anderer zu liefern.		Sprachpraxis	4	Kontaktzeit \\tab \\tab 30 \\par\nVor-/Nachbereitung. \\tab \\tab 60 \\par\nKlausur \\tab \\tab 30	\N	\N	0
1	10080	Proseminar I Kulturwissenschaft (anwendungsorientiert)	Introductory Seminar in Cultural Studies (practical orientation)	Nach erfolgreicher Teilnahme an dieser Veranstaltung verfügen die Studierenden über vertiefte Kenntnisse der Kulturgeschichte sowie der gegenwärtigen\nKultur eines englischsprachigen Landes. Sie vermögen diese Kenntnisse zu \nreproduzieren und sie im Rahmen der Diskussion ausgewählter kultureller Phänomene des betreffenden Landes anzuwenden und zu reflektieren. Zudem besitzen die Studierenden nach Absolvieren dieser Veranstaltung ein geschärftes Bewusstsein für die Phänomene der Diversität und Multikulturalität sowie ausgeprägte Fähigkeiten im Denken, Verstehen und Handeln in interkulturellen Zusammenhängen.		Kulturwissenschaft	5	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 60 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60 	\N	\N	100
1	11	Proseminar I Sprachwissenschaft	Introductory Seminar in Linguistics	Die Studierenden können Faktenwissen zu einem sprachwissenschaftlichen Teilgebiet wiedergeben. Sie erkennen linguistische Zusammenhänge und sind in der Lage, sich mit den wichtigsten Theorien zum Fachgebiet auseinander zu setzen. Sie sind befähigt, mündlich auch komplexe Zusammenhänge verständlich zu präsentieren. Sie können eigene wissenschaftliche Fragestellungen entwickeln und in einer kurzen Hausarbeit bearbeiten. Sie sind sich der Standards einer wissenschaftlichen Arbeitsweise bewusst und befolgen diese.		Sprachwissenschaft	5	Kontaktzeit \\tab \\tab 30 par\nVor- und Nachbereitung \\par\n(inkl. Referat o.ä.) \\tab \\tab 60 par\nMündliche und/oder  \\par\nschriftliche Prüfung \\tab \\tab 60 		\N	100
\.


--
-- TOC entry 2794 (class 0 OID 219751)
-- Dependencies: 196 2810
-- Data for Name: tblSdModul; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdModul" ("lngSdSeminarID", "lngModulID", "strModulBezeichnung", "strModulBeschreibung", "lngModulNummer", "strModulEinordnung", "intModulSemester", "intModulSemesterMin", "intModulSemesterMax", "strModulCustom1", "strModulCustom2", "strModulCustom3", "strModulBezeichnung_en", "strModulBeschreibung_en", "strModulCustom1_en", "strModulCustom2_en", "strModulCustom3_en", "blnModulWaehlbar", "blnModulVarLP") FROM stdin;
1	108	ZP PS Sprache	ZP PS Sprache	520	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	122	Aufbaustudien Kulturwissenschaft	PS II (6 LP):\r\nBefähigung zur theoretisch reflektierten Analyse ausgewählter Phänomene des englischsprachigen Kulturraumes in historischer Perspektive; Befähigung zur kritischen Analyse kultureller\r\nOrdnungs- und Sinngebungen und ihrer medialen Repräsentation.\r\nVL (4 LP):\r\nVertiefung im Bereich der Kulturwissenschaft, ihrer Methoden und Theorien.	1130	\N	0	0	0	25% KW 4.-5. Semester	\N	\N	Intermediate Studies Culture	\N	\N	\N	\N	t	f
1	123	Aufbauseminar Sprach- und Literaturwissenschaft	\N	1140	\N	0	0	0	50% Wahlpflichtmodul 4.-6. Semester	\N	\N	Intermediate Seminar Linguistics and Literature	\N	\N	\N	\N	t	f
1	126	Aufbaustudien Sprach- und Literaturwissenschaft	\N	1170	\N	0	0	0	75% Wahlpflichtmodul 4.-6. Semester	\N	\N	Intermediate Studies Linguistics and Literature	\N	\N	\N	\N	t	f
1	113	Phonetik	Phonetikvorlesung (3,5 LP):\r\nAnwendung der Grundbegriffe der artikulatorischen Phonetik und der Phonologie auf die Beschreibung der britischen Standard-Akzente\r\n(Received Pronunciation bzw. General American).\r\nSprachlabor (1 LP):\r\nVerbesserung der eigenen Aussprache durch die Anwendung der theoretischen phonetischen Kenntnisse.	1040	\N	0	0	0	25% Sprachwiss., 25% Literaturwiss. oder 25% Kulturwissenschaft, 1.-2. Semester	\N	\N	Phonetics	\N	\N	\N	\N	t	f
1	121	Aufbaustudien Literaturwissenschaft	PS II (6 LP):\r\nBefähigung zur sozial-, kultur-, medien- und geistesgeschichtlichen Verortung der Literatur bzw. zur Einordnung in intertextuelle Zusammenhänge; Befähigung zur Einordnung spezifischer literarischer Texte in den größeren Zusammenhang der Geschichte der Gattung bzw. der Literaturgeschichte; Befähigung zur Anwendung von literaturwissenschaftlichen Modellen und Theorien zur Analyse des Funktionspotentials der behandelten Texte;\r\nFähigkeit, historische Differenzen und epochenübergreifende Entwicklungsprozesse          wie Pluralisierung, Modernisierung, Konstruktion      kultureller und nationaler Identitäten und Internationalisierung zu reflektieren.\r\nVL (4 LP):\r\nVermittlung von Überblickswissen über eine Gattung oder Epoche, ggf. unter Zuspitzung auf paradigmatische Problemstellungen oder\r\nAutor(inn)en; exemplarische hermeneutische Praxis unter Berücksichtigung der anglistischen Methodenvielfalt; Hinführung zu literaturtheoretischem Bewusstsein.	1120	\N	0	0	0	25% Literaturwissenschaft 4.-5. Semester	\N	\N	Intermediate Studies Literature	\N	\N	\N	\N	t	f
1	105	ZP Nebenfach Zulassungsvoraussetzung	ZP Nebenfach Zulassungsvoraussetzung -- identisch für NF Sprachwissenschaft und NF Literaturwissenschaft. Auch Magister ohne Latein	120	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	100	Orientierungsprüfung HF	Orientierungsprüfung Hauptfach Englisch	1	\N	2	0	2	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	101	Orientierungsprüfung NF Sprachwissenschaft	Orientierungsprüfung Nebenfach Sprachwissenschaft	10	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	102	Orientierungsprüfung NF Literaturwissenschaft	Orientierungsprüfung Nebenfach Literaturwissenschaft	20	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	111	Einführung Literaturwissenschaft	Literaturwissenschaft: Fähigkeit zur Anwendung grundlegender Kenntnisse über Literaturbegriff und literaturwissenschaftliche Methodik, literatur- und textwissenschaftliche Analyse, Beschreibungs-\r\nmodelle für die drei literarischen Großgattungen Lyrik, Erzählprosa und Drama, maßgebliche theoretische Ansätze der Literaturwissenschaft\r\nund den Umgang mit Hilfsmitteln auf die Analyse literarischer Texte in englischer Sprache.	1020	\N	0	0	0	25% Literatur- oder Kulturwissenschaft, 1. Semester	\N	\N	Introduction to Literature	\N	\N	\N	\N	t	f
1	103	ZP Hauptfach Zulassungsvoraussetzung mit Latein	Zwischenprüfung Hauptfach, Zulassungsvoraussetzungen (zählen nicht zur Note), mit Latein	100	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	104	ZP Hauptfach Zulassungsvoraussetzung ohne Latein	ZP Hauptfach ohne Latein Zulassungsvoraussetzungen -- Fremdsprachenkenntnisse ersetzen Latein	110	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	106	Sprachpraxis Grundstudium	Sprachpraxis Grundstudium (Teil der Zwischenprüfung)	500	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	107	ZP PS Literatur	Zwischenprüfung	510	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	t	f
1	110	Einführung Sprachwissenschaft	Fähigkeit zur Anwendung grundlegender\r\nKenntnisse in den Teilbereichen der englischen Sprachwissenschaft (Phonetik und Phonologie, Morphologie, Syntax, Semantik, Pragmatik,\r\nSozio- und Varietätenlinguistik) sowie der historischen Entwicklung der englischen Sprache und Kenntnisse sprachwissenschaftlicher Arbeitsweisen.	1010	\N	0	0	0	25% Sprachwissenschaft, 1. Semester	\N	\N	Introduction to Linguistics	\N	\N	\N	\N	t	f
1	109	Einführungsmodul	Literaturwissenschaft: Fähigkeit zur Anwendung grundlegender Kenntnisse über Literaturbegriff und literaturwissenschaftliche Methodik, literatur- und textwissenschaftliche Analyse, Beschreibungs-\r\nmodelle für die drei literarischen Großgattungen Lyrik, Erzählprosa und Drama, maßgebliche theoretische Ansätze der Literaturwissenschaft und den Umgang mit Hilfsmitteln auf die Analyse literarischer Texte in englischer Sprache.\r\n\r\nSprachwissenschaft: Fähigkeit zur Anwendung grundlegender Kenntnisse in den Teilbereichen der englischen Sprachwissenschaft (Phonetik und Phonologie, Morphologie, Syntax, Semantik, Pragmatik, Sozio- und Varietätenlinguistik) sowie der historischen Entwicklung der englischen Sprache und Kenntnisse sprach-wissenschaftlicher\r\nArbeitsweisen.	1000	\N	0	0	0	50% oder 75% 1. Semester	\N	\N	Introduction Module	\N	\N	\N	\N	t	f
1	115	Übersetzung und Englisch Praxisnah	Translation into English (Übersetzung ins Englische):\r\nHauptschwerpunkt dieser Veranstaltung ist die vergleichende bzw. kontrastive Behandlung englischer und deutscher Sprachstrukturen\r\nBesonderes Augenmerk richtet sich dabei auf die unterschiedliche Verwendung der Zeiten, die indirekte Rede, Konditionalsätze Modalverben und den Wortschatz. \r\nEnglish in Use (Englisch Praxisnah):\r\nZentrale Ziele dieser Veranstaltungen sind der Erwerb der "Handwerkzeuge", d. h. der relevanten fremdsprachlich-kulturellen Kommunikationstools des schriftlichen und mündlichen Ausdrucks\r\nsowie die Vertiefung fachspezifischer Lerntechniken für den handlungskompetenten Umgang mit der englischen Gegenwartssprache, Literatur und Kultur (reading, vocabulary, writing, speaking, listening etc.).	1060	\N	0	0	0	75% 1.-3. Semester	\N	\N	Translation and English in Use	\N	\N	\N	\N	t	f
1	116	Textproduktion und Stilistik für Fortgeschrittene	Das Modul dient der Zusammenführung und der weiteren Vertiefung bereits erworbener fremdsprachlich-kommunikativer Sprachkompetenzen. Aus "Handwerkszeug" wird "Denkwerkzeug": sichere, flüssige, effiziente und effektive Kommunikation in der Weltsprache Englisch als Grundvoraussetzung fachbezogener, inhaltlichmethodischer Auseinandersetzung mit (und Produktion von) Texten und Interaktionsformen, wie sie in modernen kommunikations-, literatur- und kulturwissenschaftlichen Berufsfeldern unabdingbar\r\nsind.	1070	\N	0	0	0	50% oder 75% 4.-5. Semester	\N	\N	Advanced Writing and Stylistics	\N	\N	\N	\N	t	f
1	117	Basismodul Sprachwissenschaft	Vertiefung der im Einführungsmodul erworbenen methodischen und theoretischen Kenntnisse anhand eines oder zweier Kernbereiche\r\nder englischen Sprachwissenschaft (d.h. der Semantik, Phonologie, Morphologie, Syntax oder Pragmatik). Für die Vorlesung und das Seminar sind möglichst zwei verschiedene Kernbereiche zu wählen.\r\nAnwendung der erlernten Analysemethoden, exemplarische Vertiefung einzelner linguistischer Fragestellungen; vertiefende Beschreibung des Englischen im Rahmen der behandelten strukturellen Ebenen; Erlernen von eigenständigem Arbeiten, Erhebung und Analyse authentischer Daten (korpusbasiert), Übung im mündlichen Vortrag und Verfassen wissenschaftlicher Texte.	1080	\N	0	0	0	25% Sprachwissenschaft, 50% oder 75% 2.-3. Semester	\N	\N	Linguistic Core Studies	\N	\N	\N	\N	t	f
1	114	Englisch Praxisnah	Zentrale Ziele dieses Moduls sind der Erwerb der "Handwerkzeuge" d. h. der relevanten fremdsprachlich-kulturellen Kommunikationstools\r\ndes schriftlichen und mündlichen Ausdrucks sowie die Vertiefung fachspezifischer Lerntechniken für den handlungskompetenten Umgang mit der englischen Gegenwartssprache, Literatur und Kultur (reading, vocabulary, writing, translation, speaking, listening etc.).	1050	\N	0	0	0	25% Sprach-, Literatur oder Kulturwissenschaft, 3.-5. Semester	\N	\N	English in Use	\N	\N	\N	\N	t	f
1	80	Anglistik OP Literatur/Kulturwiss.		80		\N	0	25				OP Lit./Cult.					f	f
1	81	Anglistik OP Sprachwiss.		81		\N	0	25				OP Linguistics					f	f
1	112	Phonetik, Grammatik, Textproduktion	Phonetikvorlesung und Sprachlabor (VL 3,5 LP; LAB 1 LP):\r\nAnwendung der Grundbegriffe der artikulatorischen Phonetik und der Phonologie auf die Beschreibung der britischen und amerikanischen Standard-Akzente (Received Pronunciation bzw. General American). Verbesserung der eigenen Aussprache durch die\r\nAnwendung der theoretischen phonetischen Kenntnisse.\r\nGrammar und Writing (je 3 LP):\r\nKorrekte Anwendung des englischen Tempus- und Aspektsystems, das Schreiben gut strukturierter und komplexer englischer Sätze, das Erkennen und die Korrektur typischer Fehler. Diese Fähigkeiten sind Voraussetzung für alle nachfolgenden sprachpraktischen Übungen sowie das Verfassen englischer Texte.	1030	\N	0	0	0	50% 1.-3. Semester; 75% 1.-2. Semester	\N	\N	Phonetics, Grammar, Writing	\N	\N	\N	\N	t	f
1	118	Basismodul Literaturwissenschaft	Inhaltliche Beschreibung \r\n- Erweiterung des in der Einführung vermittelten Wissens über theoretische Grundlagen der Literaturwissenschaft und narratologische, dramen- und lyriktheoretische\r\nZugänge zur Literatur \r\n- Einübung der in der Einführung vermittelten\r\nAnalysetechniken entweder an einer Periode der englischen Literaturgeschichte von der Renaissance bis zur Postmoderne oder an\r\neiner literarischen Hauptgattung durch Bearbeitung vorliegender Gattungs- bzw. Epochendarstellungen und exemplarischen Analysen kanonischer Hauptwerke innerhalb der Epoche. Dabei sollten in den zwei Veranstaltungen des Moduls möglichst eine Gattung und eine\r\nEpoche bearbeitet werden - Betrachtung der behandelten Werke im historischen Kontext im Sinne einer kulturwissenschaftlichen Annäherung an die Literatur Lernziele - Beherrschung zentraler literaturwissenschaftlicher Analysekategorien \r\n- Einsicht in Epochenstile und Gattungskonventionen \r\n- Einsicht in Relevanz der Epoche bzw. Gattung für die Gegenwart	1090	\N	0	0	0	25% LW, 50% oder 75% 2.-3. Semester	\N	\N	Literary Core Studies	\N	\N	\N	\N	t	f
1	120	Aufbaustudien Sprachwissenschaft	PS II Sprachwissenschaft (historisch; Überblick) (6 LP):\r\nEinführung in die Grundbegriffe und Methoden der historischen Sprachwissenschaft; Vermittlung von Überblickswissen über alle Perioden der Geschichte des Englischen von den Anfängen bis zur Gegenwart; Einführung in die grundlegenden Prozesse und Faktoren des Sprachwandels; Befähigung zur Beschreibung ausgewählter Sprachwandelphänomene aus sprachinterner und    externer Perspektive; Verständnis der grundlegenden typologischen Umgestaltung der englischen Sprache.\r\nVorlesung (4 LP):\r\nZiel der sprachwissenschaftlichen Vorlesung in diesem Modul ist ein Überblick über relevante Theorien, Methoden und den Gebrauch\r\nvon Hilfsmitteln sowie ein inhaltlicher Überblick über den jeweilige Bereich der angewandten englischen Sprachwissenschaft bzw. historischen Sprachwissenschaft.	1110	\N	0	0	0	25% Sprachwissenschaft 4.-5. Semester	\N	\N	Intermediate Studies Linguistics	\N	\N	\N	\N	t	f
1	300	Anglistik BA-Arbeit		5100		\N	0	25				Bachelor Thesis Module					t	f
1	400	BA: Mündliche Prüfung		6100		\N	0	25				BA: Oral Exam					t	f
1	124	Aufbauseminar Sprach- und Kulturwissenschaft	\N	1150	\N	0	0	0	50% Wahlpflichtmodul 4.-6. Semester	\N	\N	Intermediate Seminar Linguistics and Culture	\N	\N	\N	\N	t	f
1	127	Aufbaustudien Sprach- und Kulturwissenschaft	\N	1180	\N	0	0	0	75% Wahlpflichtmodul 4.-6. Semester	\N	\N	Intermediate Studies Linguistics and Culture	\N	\N	\N	\N	t	f
1	119	Basismodul Kulturwissenschaft	Proseminar:\r\nErwerb des Überblicks über ein breites Feld verschiedener kulturwissenschaftlicher Theorien und Methoden; Fähigkeit zur reflektierten  Anwendung der behandelten Theorien bei kulturwissenschaftlichen Problemstellungen;     Kenntnisse der Kulturgeschichte und gegenwärtigen Kultur eines englischsprachigen Landes; Selbständige Bearbeitung eines\r\nbegrenzten Themengebiets; Fähigkeit zur Vorbereitung und Durchführung einer kurzen, medial unterstützten Präsentation [Studierende im Begleitfach müssen ein Proseminar mit theoretischer Ausrichtung belegen; Studierenden im Hauptfach bzw. 1./2.Hauptfach steht die Wahl frei (siehe Anlage 1 der PO).]\r\nVorlesung:\r\nVorstellung der Kulturwissenschaft und ihrer Methodik; Einführung kulturwissenschaftlicher Theorien; Darstellung von aktuellen\r\nAnwendungen kulturwissenschaftlicher Theorien.	1100	\N	0	0	0	50% oder 75% 2.-3. Semester	\N	\N	Cultural Core Studies	\N	\N	\N	\N	t	f
1	601	Basismodul Kulturwissenschaft (25KW)	Proseminar:\r\nErwerb des Überblicks über ein breites Feld verschiedener kulturwissenschaftlicher Theorien und Methoden; Fähigkeit zur reflektierten  Anwendung der behandelten Theorien bei kulturwissenschaftlichen Problemstellungen;     Kenntnisse der Kulturgeschichte und gegenwärtigen Kultur eines englischsprachigen Landes; Selbständige Bearbeitung eines\r\nbegrenzten Themengebiets; Fähigkeit zur Vorbereitung und Durchführung einer kurzen, medial unterstützten Präsentation [Studierende im Begleitfach müssen ein Proseminar mit theoretischer Ausrichtung belegen; Studierenden im Hauptfach bzw. 1./2.Hauptfach steht die Wahl frei (siehe Anlage 1 der PO).]\r\nVorlesung:\r\nVorstellung der Kulturwissenschaft und ihrer Methodik; Einführung kulturwissenschaftlicher Theorien; Darstellung von aktuellen\r\nAnwendungen kulturwissenschaftlicher Theorien.	1101	\N	0	0	0	25% Kulturwiss., 2.-3. Semester	\N	\N	Cultural Core Studies (25KW)	\N	\N	\N	\N	t	f
1	100005	ZP Hauptfach Zulassungsvoraussetzung ohne L u. F.	\N	111	\N	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	f	f
1	600	Aufbauseminar (WPM)	Dachmodul für Wahlpflichtmodul im 50% BA	3000		0	0	25				Intermediate Seminar					t	f
1	125	Aufbauseminar Sprach-, Literatur- und Kulturwiss.	\N	1160	\N	0	0	0	75% 3.-5. Semester	\N	\N	Intermed. Sem. Linguistics, Literature and Culture	\N	\N	\N	\N	t	f
1	100035	Grammatik Modul		\N		\N	0	25				Grammar Module\n					t	f
1	100045	Schreibmodul		\N		\N	0	25				Writing Module\n					t	f
1	100055	Englisch Praxisnah für Fortgeschrittene		\N		\N	0	25				Advanced English in Use					t	f
1	100095	Vertiefungsstudien Sprach- und Literaturwissenschaft		\N		\N	0	25				Intermediate Studies Linguistics and Literature					t	f
1	100135	Vertiefungsseminar Sprach- und Literaturwissenschaft		\N		\N	0	25				Intermediate Seminar Linguistics and Literature					t	f
1	100225	Texttypen		\N		\N	0	25				Text Types\n					t	f
1	100255	Modul Ethisch-Philosophisches Grundlagenstudium		\N		\N	0	25									t	f
1	100265	Zulassungsvoraussetzungen		\N		\N	0	25									t	f
1	100275	Fortgeschrittenenmodul Sprach- und Literaturwissenschaft		\N		\N	0	25									t	f
1	100285	Fachdidaktik I		\N		\N	0	25				Specialized Didactics 1\n					t	f
1	100295	Fachdidaktik II		\N		\N	0	25				Specialized Didactics 2\n					t	f
1	200	Aufbaustudien (75% BA WPM)	Dachmodul für Wahlpflichtmodul im 75% BA	2000		0	0	25				Intermediate Studies (75% BA)					t	f
1	100325	HCA: Basismodul Literatur und Kultur.		\N		\N	0	25				Basic Module Literary and Cultural Studies (HCA)\n					t	f
1	200000	Grundlagenkolloquium Sprachwissenschaft (MA HF)		200000		\N	0	25				Introduction to Research in English Linguistics					t	f
1	200010	Aufbaumodul Sprachwissenschaft (MA HF Linguistik)		200010		\N	0	25				Intermediate Studies in English Linguistics					t	f
1	200020	Ausgewählte Probleme der englischen Sprachpraxis (MA HF)		200020		\N	0	25				Select Issues in English Usage (MA Major)					t	f
1	100145	Vertiefungssem. Sprach- und Kultur- od. Literaturwiss.		0		0	0	25				Interm. Sem. Linguistics and Culture or Literature					t	f
1	200030	Vertiefungsmodul Sprachwissenschaft (MA HF Linguistik)		200030		\N	0	25				Advanced Studies in English Linguistics					t	f
1	200040	Graduiertenmodul Sprachwissenschaft (MA HF Linguistik)		200040		\N	0	25				Graduate Studies in English Linguistics					t	f
1	200050	Examensmodul (MA HF Linguistik)		200050		\N	0	25				Exam Module (MA Major Linguistics)					t	f
1	200060	Grundlagenkolloquium Literaturwissenschaft (MA HF)		200060		\N	0	25				Introduction to Research in Literature					t	f
1	200070	Aufbaumodul Literaturwissenschaft (MA HF Literature)		200070		\N	0	25				Intermediate Studies in Literature					t	f
1	200080	Vertiefungsmodul Literaturwissenschaft (MA HF Literature)		200080		\N	0	25				Advanced Studies in Literature					t	f
1	200090	Graduiertenmodul Literaturwissenschaft (MA HF Lit.)		200090		\N	0	25				Graduate Studies in Literature					t	f
1	200100	Verkürztes Aufbaumodul Sprachwissenschaft		200100		\N	0	25				Essential Intermediate English Linguistics					t	f
1	200110	Vorlesungen zur Englischen Sprachwissenschaft		200110		\N	0	25				Lectures in English Linguistics					t	f
1	200120	Kernfragen der Sprachpraxis (MA NF)		200120		\N	0	25				Essential Issues of English Usage					t	f
1	200130	Vertiefungsseminar Sprachwissenschaft (MA NF)		200130		\N	0	25				Advanced Seminar in English Linguistics					t	f
1	200140	Verkürztes Aufbaumodul Literaturwissenschaft		200140		\N	0	25				Essential Intermediate Studies in Literature					t	f
1	200150	Vorlesungen zur Literaturwissenschaft (MA NF)		200150		\N	0	25				Lectures in Literature (MA Minor Literature)					t	f
1	200160	Vertiefungsseminar Literaturwissenschaft (MA NF)		200160		\N	0	25				Advanced Seminar in Literature (MA Minor)					t	f
1	200170	Methodologie und Forschungspraxis (MA NF)		200170		\N	0	25				Methodology and Research (MA Minor)					t	f
1	9100011	Zusatzmodul	Zusatzmodul Lehramt GymPO	\N		\N	0	25				Surplus Module					t	f
1	9100021	Grundlagenmodul Sprachwissenschaft (MA HF Linguistik 2012)		\N		\N	0	25				Module Basic English Linguistics (MA 2012)					t	f
1	9100031	Vertiefungsmodul Sprachwissenschaft (MA HF Linguistik 2012)		\N		\N	0	25				Module Advanced English Linguistics (MA 2012)					t	f
1	9100041	Prüfungsmodul MA-Arbeit (MA HF 2012)		\N		\N	0	25				Module Exam English Linguistics (MA 2012): Thesis\n					t	f
1	9100051	Prüfungsmodul Abschlussprüfung (MA HF 2012)		\N		\N	0	25				Module Exam English Linguistics (MA 2012): Oral Examination\n					t	f
1	9100061	Grundlagenmodul Literaturwissenschaft (MA HF Literaturwissenschaft 2012)		\N		\N	0	25				Module Basic Literary Studies (MA 2012)					t	f
1	100235	Aufbaumodul Sprach-, Literatur- und Kulturwissenschaft/Landeskunde		0		0	0	25				Intermediate Module Linguistics, Literature and Cultural Studies					t	f
1	9100071	Vertiefungsmodul Literaturwissenschaft (MA HF Literaturwissenschaft 2012)		\N		\N	0	25				Module Advanced Literary Studies (MA 2012)					t	f
1	9100081	Nebenfachmodul Englische Linguistik (MA NF Sprachwissenschaft 2012)		\N		\N	0	25				Module Minor Basic English Linguistics (MA 2012)					t	f
1	9100091	Nebenfachmodul Englische Literaturwissenschaft (MA NF Literaturwissenschaft 2012)		\N		\N	0	25				Module Minor Basic English Literary Studies (MA 2012)					t	f
1	100315	Einführungsmodul Sprachwissenschaft		0		0	0	25				Introductory Module English Linguistics					t	f
1	100010	Fremdsprachenkenntnisse	Fremdsprachenkenntnisse GymPO	100010	Grundstudium	4	1	4				Knowledge of Latin or other Roman Language					f	f
1	100305	Wahlmodul		0		0	0	25	Engl. vgl. Glossar: http://www.uni-heidelberg.de/md/zentral/einrichtungen/rektorat/kum/glossar_kum_20120309.pdf			Elective Module					t	f
1	100175	Vertiefungsstudien Kulturwissenschaft	Das Modul ermöglicht den Studierenden, weitere Themengebiete in der Kulturwissenschaft abzudecken, durch ein Proseminar II und eine Vorlesung nach Wahl. Sie vertiefen ihre Fakten- und Theoriekenntnisse in der Kulturwissenschaft und stärken die zuvor erworbenen Kompetenzen in den Gebieten der wissenschaftlichen Recherche, der Diskussion komplexer Thematiken, der mündlichen Präsentation sowie der schriftlichen Bearbeitung wissenschaftlicher Fragestellungen. 	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Intermediate Studies Culture\n					t	f
1	100185	Aufbaumodul Literaturwissenschaft	Das Aufbaumodul ermöglicht den Studierenden eine produktive eigene Beschäftigung mit den Inhalten des Fachs. Sie erlernen wissenschaftliche Arbeitsweisen wie die Recherche und Verarbeitung bisher erschienener Werke und Studien und verfolgen erste eigene, engst umgrenzte wissenschaftliche Projekte, von der Auswahl der literarischen Werke über geeignete Analysemethoden zur kritischen Auswertung der Ergebnisse. In Gruppenarbeit und Diskussionen mit KommilitonInnen und Lehrenden entwickeln sie diskursiv ihr Verständnis der Literaturwissenschaft und festigen im Referat ihre Kompetenz der wissenschaftlichen Präsentation in englischer Sprache. \\par \nIm Rahmen des Moduls besuchen die Studierenden die Übung ‚Fundamentals of Research and Writing‘ sowie ein Proseminar I Literaturwissenschaft.	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Literary Core Studies\n					t	f
1	100195	Vertiefungsstudien Literaturwissenschaft	Das Modul ermöglicht den Studierenden, weitere Themengebiete in der Literaturwissenschaft abzudecken, durch ein Proseminar II und eine Vorlesung nach Wahl. Sie vertiefen ihre Fakten- und Theoriekenntnisse in der Literaturwissenschaft und stärken die zuvor erworbenen Kompetenzen in den Gebieten der wissenschaftlichen Recherche, der Diskussion komplexer Thematiken, der mündlichen Präsentation sowie der schriftlichen Bearbeitung wissenschaftlicher Fragestellungen.	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Intermediate Studies Literature\n					t	f
1	100025	Phonetikmodul	Das Modul vermittelt die wissenschaftlich-theoretischen Grundlagen des Lautsystems der englischen Sprache (in einer Vorlesung) ebenso wie die praktische Umsetzung des theoretischen Wissens (in einer Übung). Nach Absolvieren des Moduls sind Studierende mit den artikulatorischen Grundlagen der Lautung, mit den einzelnen Lauten und Lautkombinationen sowie dem rhythmischen System des Englischen ebenso wie mit verschiedenen regionalen und sozialen Akzenten und typisch deutschen Aussprachefehlern vertraut. Die Fähigkeit zur Analyse von Sprachmustern wird im Modul weiter vertieft.	\N		\N	0	25	- Vortrag der Lehrenden im Plenum \\par - Arbeitsaufgaben \\par -Einzelberatung \\par -Eigenstudium			Phonetics Module\n					t	f
1	100065	Vorlesungsmod. Sprach-, Literatur und Kulturwiss.	Das Modul bietet den Studierenden die Möglichkeit, ihre im Einführungsmodul erworbenen Grundkenntnisse in ausgewählten Themengebieten zu vertiefen. Sie besuchen jeweils eine Vorlesung aus den drei Teilgebieten der Englischen Philologie und erweitern durch den Besuch ebenso wie durch die Vor- und Nachbereitung ihre terminologischen, methodischen und theoretischen Kenntnisse und Kompetenzen. Das Modul schärft die Fähigkeit der Studierenden, Zusammenhänge zwischen verschiedenen Fachgebieten, Perioden, Prozessen und Theorien zu erkennen.	\N		\N	0	25	- Vortrag der Lehrenden im Plenum \\par -Eigenstudium			Lecture Course Literature, Linguistics and Culture					t	f
1	100075	Aufbaumodul Sprach-, Literatur- und Kulturwissenschaft	Das Aufbaumodul ermöglicht den Studierenden eine produktive eigene Beschäftigung mit den Inhalten des Fachs. Sie erlernen wissenschaftliche Arbeitsweisen, wie die Recherche und Verarbeitung bisher erschienener Werke und Studien und verfolgen erste eigene, engst umgrenzte wissenschaftliche Projekte, von der Auswahl der Sprachdaten oder literarischen Werke über geeignete Analysemethoden zur kritischen Auswertung der Ergebnisse. In Gruppenarbeit und Diskussionen mit KommilitonInnen und Lehrenden entwickeln sie diskursiv ihr Verständnis der Teilgebiete der Englischen Philologie und festigen im Referat ihre Kompetenz der wissenschaftlichen Präsentation in englischer Sprache. \\par \nIm Rahmen des Moduls besuchen die Studierenden die Übung ‚Fundamentals of Research and Writing‘, ein Proseminar I Sprachwissenschaft, ein Proseminar I Literaturwissenschaft und ein Proseminar I Kulturwissenschaft (theoretisch oder anwendungsorientiert).	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Core Studies Literature, Linguistics and Culture					t	f
1	100085	Vertiefungsseminar Sprach-, Literatur- und Kulturwiss.	Das Modul ermöglicht den Studierenden, weitere Themengebiete in allen Bereichen der Englischen Philologie abzudecken, durch jeweils ein Proseminar II in der historischen Sprachwissenschaft (zu einer historischen Periode des Englischen), der Literatur- und der Kulturwissenschaft. Sie vertiefen ihre Fakten- und Theoriekenntnisse im jeweiligen Bereich und stärken die zuvor erworbenen Kompetenzen in den Gebieten der wissenschaftlichen Recherche, der Diskussion komplexer Thematiken, der mündlichen Präsentation sowie der schriftlichen Bearbeitung wissenschaftlicher Fragestellungen.	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Intermediate Seminar Linguistics, Lit. and Culture					t	f
1	100105	Vertiefung Literatur- oder Kultur- und Sprachwiss.	Das Modul ermöglicht es den Studierenden, in ihren Studien der Englische Philologie auf ein hohes Spezialisierungsniveau voranzuschreiten. Sie wählen aus dem Fächerkanon der Sprach- und Literaturwissenschaft weitere Gebiete aus, um ihre Kenntnisse der beiden Gebiete zu vervollständigen. Weiterhin erlaubt die wiederholte Einübung der Bearbeitung wissenschaftlicher Fragestellungen eine Vorbereitung auf die Bachelor-Arbeit.\nIm Rahmen des Moduls besuchen die Studierenden ein Proseminar II Sprachwissenschaft (entweder modern oder, soweit noch nicht belegt, zum historischen Überblick oder einer historischen Periode), eine Vorlesung Sprachwissenschaft (historisch oder modern), ein Proseminar II Literaturwissenschaft, eine Vorlesung Literaturwissenschaft und zusätzlich eine dritte Vorlesung nach Wahl (Sprach-, Literatur-, oder Kulturwissenschaft).	0		0	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Intermediate Literature or Culture and Linguistics					t	f
1	100205	Aufbaumodul Sprachwissenschaft	Das Aufbaumodul ermöglicht den Studierenden eine produktive eigene Beschäftigung mit den Inhalten des Fachs. Sie erlernen wissenschaftliche Arbeitsweisen, wie die Recherche und Verarbeitung bisher erschienener Werke und Studien und verfolgen erste eigene, engst umgrenzte wissenschaftliche Projekte, von der Auswahl der Sprachdaten über geeignete Analysemethoden zur kritischen Auswertung der Ergebnisse. In Gruppenarbeit und Diskussionen mit KommilitonInnen und Lehrenden entwickeln sie diskursiv ihr Verständnis der Sprachwissenschaft und festigen im Referat ihre Kompetenz der wissenschaftlichen Präsentation in englischer Sprache.  \\par\nIm Rahmen des Moduls besuchen die Studierenden die Übung ‚Fundamentals of Research and Writing‘ sowie ein Proseminar I Sprachwissenschaft.	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Linguistic Core Studies\n					t	f
1	100215	Vertiefungsstudien Sprachwissenschaft	Das Modul ermöglicht den Studierenden, weitere Themengebiete in der Sprachwissenschaft abzudecken durch den Besuch eines Proseminars II zum Überblick der Sprachgeschichte des Englischen und eine Vorlesung aus der historischen Linguistik. Sie vertiefen ihre Fakten- und Theoriekenntnisse in der Sprachwissenschaft und stärken die zuvor erworbenen Kompetenzen in den Gebieten der wissenschaftlichen Recherche, der Diskussion komplexer Thematiken, der mündlichen Präsentation sowie der schriftlichen Bearbeitung wissenschaftlicher Fragestellungen. 	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Intermediate Studies Linguistics\n					t	f
1	100125	Mündliche Abschlussprüfung	In der Vorbereitung auf die mündliche Abschlussprüfung konsolidieren die Studierenden ihre Fähigkeit, ihre Kenntnisse in den Bereichen Sprachwissenschaft und Literatur-/Kulturwissenschaft zu organisieren, zu strukturieren und zu vernetzen. Zusätzlich bietet die Prüfung die Möglichkeit, die stringente mündliche wissenschaftliche Argumentationsweise weiter einzuüben.  	\N		\N	0	25	- Eigenstudium \\par - Einzelberatung \\par - Vortrag der Studierenden und Diskussion in der Prüfung			Final Oral Exam\n					t	f
1	100155	Einführungsmodul Literaturwissenschaft	Das Modul führt die Studierenden in die Englische Literaturwissenschaft ein. Es vermittelt erste Fachkenntnisse und offeriert Einblicke in die Forschungsmethoden und Theorien der Disziplin.  Nach Absolvieren des Moduls sind die Studierenden in der Lage, Fachbegriffe korrekt anzuwenden, literarische Werke zu erfassen und auf einfachem Niveau zu analysieren. Sie haben grundlegende wissenschaftliche Arbeitstechniken erlernt und eine Basis an Grundwissen über die englischen Literatur(en) erworben.	0		0	0	25	- Vortrag der Lehrenden im Plenum \\par - Arbeitsgruppen (in Tutorien) \\par - Arbeitsaufgaben (in Tutorien) \\par -Eigenstudium			Introductory Module Literary Studies					t	f
1	100165	Aufbaumodul Kulturwissenschaft	Das Aufbaumodul ermöglicht den Studierenden eine produktive eigene Beschäftigung mit den Inhalten des Fachs. Sie erlernen wissenschaftliche Arbeitsweisen, wie die Recherche und Verarbeitung bisher erschienener Werke und Studien und verfolgen erste eigene, engst umgrenzte wissenschaftliche Projekte. In Gruppenarbeit und Diskussionen mit KommilitonInnen und Lehrenden entwickeln sie diskursiv ihr Verständnis der Kulturwissenschaft und festigen im Referat ihre Kompetenz der wissenschaftlichen Präsentation in englischer Sprache. \\par\nIm Rahmen des Moduls besuchen die Studierenden die Übung ‚Fundamentals of Research and Writing‘ sowie ein Proseminar I Kulturwissenschaft (theoretisch orientiert).	\N		\N	0	25	- Vortrag der Studierenden im Plenum \\par - Diskussion im Plenum \\par - Arbeitsgruppen \\par - Vortrag der Lehrenden in Plenum \\par - Arbeitsaufgaben \\par - Eigenstudium \\par - Einzelberatung			Cultural Core Studies\n					t	f
1	100015	Einführungsmodul Sprach- und Literaturwissenschaft	Das Modul führt die Studierenden in die Englische Philologie mit ihren beiden grundlegenden Teilgebieten Sprach- und Literaturwissenschaft ein. Anhand jeweils einer Einführungsvorlesung mit dazugehörigem Tutorium vermittelt es erste Fachkenntnisse und offeriert Einblicke in die Forschungsmethoden und Theorien der Disziplinen. Nach Absolvieren des Moduls sind die Studierenden in der Lage, Fachbegriffe korrekt anzuwenden, Sprachdaten und literarische Werke zu erfassen und auf einfachem Niveau zu analysieren. Sie haben grundlegende wissenschaftliche Arbeitstechniken erlernt und eine Basis an Grundwissen über die englische Sprache sowie die englischen Literatur(en) erworben.	0		0	0	25	- Vortrag der Lehrenden im Plenum \\par - Arbeitsgruppen (in Tutorien) \\par - Arbeitsaufgaben (in Tutorien) \\par - Eigenstudium			Introduction Module					t	f
1	100115	Bachelor-Arbeit	Die Bachelor-Arbeit bietet den Studierenden die Möglichkeit, ihre im Laufe des Studiums erworbenen Kenntnisse und Kompetenzen unter Beweis zu stellen. Hierzu gehört insbesondere die eigenständige Bearbeitung einer eng umgrenzten wissenschaftlichen Fragestellung (aus Sprach-, Literatur- oder Kulturwissenschaft) inklusive Literaturrecherche, Daten- bzw. Quellenauswahl, Methodenkompetenz und Analysefähigkeiten. Zusätzlich stärken die Studierenden ihre schriftliche Ausdrucks- und Argumentationsfähigkeit.	\N		\N	0	25	-Eigenstudium \\par - Einzelberratung			Bachelor Thesis\n					t	f
1	500	Übergreifende Kompetenzen		7100		\N	0	25				Key Qualifications					t	t
1	100245	Vertiefungsmodul Sprach-, Literatur- und Kulturwissenschaft/Landeskunde		\N		\N	0	25				Specialization Module Linguistics, Literature and Cultural Studies					t	f
\.


--
-- TOC entry 2795 (class 0 OID 219770)
-- Dependencies: 197 2810
-- Data for Name: tblSdModulXLeistung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdModulXLeistung" ("lngSdSeminarID", "lngModulID", "lngLeistungID", "sngMinCreditPts", "strCustom1", "strCustom2", "strCustom3", "strCustom1_en", "strCustom2_en", "strCustom3_en", "blnModulLeistungTranskript") FROM stdin;
1	100	1	0	\N	\N	\N	\N	\N	\N	t
1	100	0	0	\N	\N	\N	\N	\N	\N	t
1	101	0	0	\N	\N	\N	\N	\N	\N	f
1	102	1	0	\N	\N	\N	\N	\N	\N	f
1	110	0	5	\N	\N	\N	\N	\N	\N	t
1	9100021	10010	6		-4711					\N
1	103	3	0	\N	\N	\N	\N	\N	\N	t
1	103	8	0	\N	\N	\N	\N	\N	\N	t
1	103	4	0	\N	\N	\N	\N	\N	\N	t
1	104	3	0	\N	\N	\N	\N	\N	\N	t
1	104	9	0	\N	\N	\N	\N	\N	\N	t
1	104	4	0	\N	\N	\N	\N	\N	\N	t
1	105	3	0	\N	\N	\N	\N	\N	\N	t
1	105	4	0	\N	\N	\N	\N	\N	\N	t
1	106	5	0	\N	\N	\N	\N	\N	\N	t
1	106	13	0	\N	\N	\N	\N	\N	\N	t
1	106	12	0	\N	\N	\N	\N	\N	\N	t
1	107	10	0	\N	\N	\N	\N	\N	\N	t
1	108	11	0	\N	\N	\N	\N	\N	\N	t
1	9100021	10020	6		-4711					\N
1	120	10020	6	\N	\N	\N	\N	\N	\N	t
1	120	10040	4	\N	\N	\N	\N	\N	\N	t
1	123	10020	6	\N	\N	\N	\N	\N	\N	t
1	123	15	6	\N	\N	\N	\N	\N	\N	t
1	124	10020	6	\N	\N	\N	\N	\N	\N	t
1	124	10090	6	\N	\N	\N	\N	\N	\N	t
1	126	10050	0	\N	\N	\N	\N	\N	\N	t
1	126	10040	0	\N	\N	\N	\N	\N	\N	t
1	126	10160	0	\N	\N	\N	\N	\N	\N	t
1	126	10150	0	\N	\N	\N	\N	\N	\N	t
1	126	10010	0	\N	\N	\N	\N	\N	\N	t
1	126	10020	0	\N	\N	\N	\N	\N	\N	t
1	126	10030	0	\N	\N	\N	\N	\N	\N	t
1	126	15	0	\N	\N	\N	\N	\N	\N	t
1	127	10040	0	\N	\N	\N	\N	\N	\N	t
1	127	10050	0	\N	\N	\N	\N	\N	\N	t
1	127	10150	0	\N	\N	\N	\N	\N	\N	t
1	127	10160	0	\N	\N	\N	\N	\N	\N	t
1	127	10030	0	\N	\N	\N	\N	\N	\N	t
1	127	10010	0	\N	\N	\N	\N	\N	\N	t
1	127	10020	0	\N	\N	\N	\N	\N	\N	t
1	127	10090	0	\N	\N	\N	\N	\N	\N	t
1	122	10090	6	\N	7300	\N	\N	\N	\N	t
1	114	10130	3	\N	3200	\N	\N	\N	\N	t
1	113	4	3.5	\N	2110	\N	\N	\N	\N	t
1	111	1	5	\N	1200	\N	\N	\N	\N	t
1	121	15	6	\N	7200	\N	\N	\N	\N	t
1	118	10	5.5	\N	5202	\N	\N	\N	\N	t
1	118	10160	4	\N	5102	\N	\N	\N	\N	t
1	121	10160	4	\N	7500	\N	\N	\N	\N	t
1	112	4	3.5	\N	2110	\N	\N	\N	\N	t
1	109	1	5	\N	1200	\N	\N	\N	\N	t
1	109	0	5	\N	1100	\N	\N	\N	\N	t
1	119	10070	5.5	\N	5203	\N	\N	\N	\N	f
1	119	10150	4	\N	5103	\N	\N	\N	\N	t
1	117	10050	4	\N	5101	\N	\N	\N	\N	t
1	116	10110	4	\N	4200	\N	\N	\N	\N	t
1	116	10120	4	\N	4100	\N	\N	\N	\N	t
1	112	12	3	\N	2300	\N	\N	\N	\N	t
1	112	5	3	\N	2200	\N	\N	\N	\N	t
1	119	10080	5.5	\N	5203	\N	\N	\N	\N	f
1	125	10090	6	\N	6300	\N	\N	\N	\N	t
1	125	15	6	\N	6200	\N	\N	\N	\N	t
1	125	10010	6	\N	6100	\N	\N	\N	\N	t
1	115	10130	3	\N	3200	\N	\N	\N	\N	t
1	115	13	3	\N	3100	\N	\N	\N	\N	t
1	9100021	10030	6		-4711					\N
1	100305	10080	5		\N	\N	\N	\N	\N	t
1	9100021	21	8		-4711					\N
1	9100021	10040	4		-4711					\N
1	9100021	10050	4		-4711					\N
1	9100031	10040	4		-4711					\N
1	9100031	10050	4		-4711					\N
1	9100031	21	8		-4711					\N
1	9100031	30110	7		-4711					\N
1	9100041	30050	30		-4711					\N
1	9100051	30040	10		-4711					\N
1	100010	9	0							t
1	100010	8	0							t
1	100305	10	5		\N	\N	\N	\N	\N	t
1	100005	4	0	\N	\N	\N	\N	\N	\N	t
1	100005	3	0	\N	\N	\N	\N	\N	\N	t
1	122	10150	4	\N	7600	\N	\N	\N	\N	t
1	9100061	15	6		-4711					\N
1	9100061	10160	4		-4711					\N
1	9100061	10150	4		-4711					\N
1	9100061	16	8		-4711					\N
1	9100071	10160	4		-4711					\N
1	9100071	10150	4		-4711					\N
1	9100071	16	8		-4711					\N
1	9100071	30110	7		-4711					\N
1	100305	11	5		\N	\N	\N	\N	\N	t
1	300	5110	12		5110					\N
1	400	6110	8		6110					\N
1	500	7110	1		-4711					\N
1	9100081	10010	6		-4711					\N
1	9100081	10020	6		-4711					\N
1	9100081	10030	6		-4711					\N
1	80	1	4							\N
1	80	4	4							\N
1	100305	10070	5		\N	\N	\N	\N	\N	t
1	9100081	21	8		-4711					\N
1	9100081	10040	4		-4711					\N
1	9100081	10050	4		-4711					\N
1	9100081	30110	2		-4711					\N
1	600	10090	6		7300					\N
1	200	10010	6		7120					\N
1	600	15	6		7200					\N
1	600	10020	6		7130					\N
1	200	10090	6		7300					\N
1	200	10030	6		7100					\N
1	200	15	6		7200					\N
1	200	10160	4		7500					\N
1	200	10020	6		7130					\N
1	601	10070	5.5	\N	5203	\N	\N	\N	\N	f
1	601	10150	4	\N	5103	\N	\N	\N	\N	f
1	113	3	1	\N	2120	\N	\N	\N	\N	t
1	112	3	1	\N	2120	\N	\N	\N	\N	t
1	117	11	5.5	Unklar: PS I moderne SW?	5201	\N	\N	\N	\N	t
1	200	10150	4		7730					\N
1	200	10040	4		7710					\N
1	200	10050	4		7400					\N
1	100015	1	4		-4711					\N
1	100015	0	4		-4711					\N
1	100025	4	4		-4711					\N
1	100025	3	1		-4711					\N
1	100035	5	3		-4711					\N
1	100035	13	3		-4711					\N
1	100045	12	3		-4711					\N
1	100045	10120	4		-4711					\N
1	100055	10140	4		-4711					\N
1	100065	10050	4		-4711					\N
1	100065	10160	4		-4711					\N
1	100065	10150	4		-4711					\N
1	100075	11	5		-4711					\N
1	100075	10	5		-4711					\N
1	100075	10080	5		-4711					\N
1	100075	10070	5		-4711					\N
1	100075	20010	2		-4711					\N
1	100085	10010	6		-4711					\N
1	100085	15	6		-4711					\N
1	100085	10090	6		-4711					\N
1	100095	10010	6		-4711					\N
1	100095	10030	6		-4711					\N
1	100095	10020	6		-4711					\N
1	100095	10040	4		-4711					\N
1	100095	10050	4		-4711					\N
1	100095	15	6		-4711					\N
1	100095	10160	4		-4711					\N
1	100095	10150	4		-4711					\N
1	100105	10010	6		-4711					\N
1	100105	10030	6		-4711					\N
1	100105	10020	6		-4711					\N
1	100105	10040	4		-4711					\N
1	100105	10050	4		-4711					\N
1	100105	10090	6		-4711					\N
1	100105	10160	4		-4711					\N
1	100105	10150	4		-4711					\N
1	100115	5110	12		-4711					\N
1	100125	6110	5		-4711					\N
1	100135	10020	6		-4711					\N
1	100135	15	6		-4711					\N
1	100145	10020	6		-4711					\N
1	100145	10090	6		-4711					\N
1	100165	10070	5		-4711					\N
1	100165	20010	2		-4711					\N
1	100175	10090	6		-4711					\N
1	100175	10150	4		-4711					\N
1	100185	10	5		-4711					\N
1	100185	20010	2		-4711					\N
1	100195	15	6		-4711					\N
1	100195	10160	4		-4711					\N
1	9100091	15	6		-4711					\N
1	100205	11	5		-4711					\N
1	100205	20010	2		-4711					\N
1	100215	10020	6		-4711					\N
1	100215	10040	4		-4711					\N
1	100225	20005	4		-4711					\N
1	100225	20000	4		-4711					\N
1	100235	11	5		-4711					\N
1	100235	10	5		-4711					\N
1	100235	10080	5		-4711					\N
1	100235	10070	5		-4711					\N
1	100235	20010	2		-4711					\N
1	100245	10020	6		-4711					\N
1	100245	10010	6		-4711					\N
1	100245	15	6		-4711					\N
1	100245	10090	6		-4711					\N
1	100255	22	6		-4711					\N
1	100265	20210	-4711		-4711					\N
1	100275	16	8		-4711					\N
1	100275	21	8		-4711					\N
1	100285	20220	5		-4711					\N
1	100295	20230	5		-4711					\N
1	100305	10040	4		-4711					\N
1	9100091	10160	4		-4711					\N
1	100155	1	4		-4711					f
1	100305	10050	4		-4711					\N
1	100305	10150	4		-4711					\N
1	100305	10160	4		-4711					\N
1	100305	10130	3		-4711					\N
1	100305	10140	4		-4711					\N
1	100315	0	4		-4711					\N
1	100325	1	4		-4711					\N
1	114	5	3		3200					\N
1	114	12	3		3200					\N
1	114	13	3		3200					\N
1	9100091	10150	4		-4711					\N
1	9100091	16	8		-4711					\N
1	9100091	30110	2		-4711					\N
1	200000	30000	8		unknown					\N
1	200010	10040	4		unknown					\N
1	200010	10050	4		unknown					\N
1	200010	10010	6		unknown					\N
1	200010	10020	6		unknown					\N
1	200010	10030	6		unknown					\N
1	200020	10110	4		unknown					\N
1	200020	10120	4		unknown					\N
1	200020	10140	4		unknown					\N
1	200030	10040	4		unknown					\N
1	200030	10050	4		unknown					\N
1	200030	21	16		unknown					\N
1	200040	30010	4		unknown					\N
1	200040	21	8		unknown					\N
1	200040	30020	8		unknown					\N
1	200040	30030	8		unknown					\N
1	200050	30040	4		unknown					\N
1	200050	30050	30		unknown					\N
1	200060	30060	8		unknown					\N
1	200070	10160	4		unknown					\N
1	200070	15	6		unknown					\N
1	200080	10160	4		unknown					\N
1	200080	16	16		unknown					\N
1	200090	30070	8		unknown					\N
1	200090	16	8		unknown					\N
1	200090	30080	8		unknown					\N
1	200090	30030	8		unknown					\N
1	200100	10040	4		unknown					\N
1	200100	10050	4		unknown					\N
1	200100	10010	4		unknown					\N
1	200100	10020	4		unknown					\N
1	200100	10030	4		unknown					\N
1	200110	10040	4		unknown					\N
1	200110	10050	4		unknown					\N
1	200120	10110	4		unknown					\N
1	200120	10120	4		unknown					\N
1	200120	10140	4		unknown					\N
1	200130	21	4		unknown					\N
1	200140	10160	4		unknown					\N
1	200140	15	4		unknown					\N
1	200150	10160	8		unknown					\N
1	200160	16	4		unknown					\N
1	200170	30030	4		unknown					\N
1	200170	30090	3		unknown					\N
1	200170	30100	3		unknown					\N
1	200170	20200	3		unknown					\N
1	200020	20100	4		\N	\N	\N	\N	\N	t
1	200120	20100	4		\N	\N	\N	\N	\N	t
1	100105	15	6		\N	\N	\N	\N	\N	t
1	100145	15	6		\N	\N	\N	\N	\N	t
1	9100011	50	0							\N
1	9100011	5110	0							\N
1	9100011	6110	0							\N
1	9100011	500	0							\N
1	9100011	20	0							\N
1	9100011	10030	0							\N
1	9100011	20100	0							\N
1	9100011	7110	0							\N
1	9100011	14	0							\N
1	9100011	18	0							\N
1	9100011	19	0							\N
1	9100011	17	0							\N
1	9100011	20200	0							\N
1	9100011	10110	0							\N
1	9100011	8	0							\N
1	9100011	9	0							\N
1	9100011	30000	0							\N
1	9100011	30010	0							\N
1	9100011	30020	0							\N
1	9100011	30030	0							\N
1	9100011	30040	0							\N
1	9100011	30050	0							\N
1	9100011	30060	0							\N
1	9100011	30070	0							\N
1	9100011	30080	0							\N
1	9100011	30090	0							\N
1	9100011	30100	0							\N
1	100305	10030	0		\N	\N	\N	\N	\N	f
1	81	0	4							\N
1	81	4	4							\N
1	100305	15	6		\N	\N	\N	\N	\N	t
1	100305	10020	6		\N	\N	\N	\N	\N	t
1	100325	30200	5		-4711					\N
1	100305	10090	5		\N	\N	\N	\N	\N	t
1	200020	20005	4		\N	\N	\N	\N	\N	t
\.


--
-- TOC entry 2796 (class 0 OID 219783)
-- Dependencies: 198 2810
-- Data for Name: tblSdNote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdNote" ("lngSdSeminarID", "intNoteID", "strNoteNameDE", "sngNoteWertDE", "strNoteECTSGrade", "strNoteECTSDefinition", "sngNoteECTSCalc", "blnNoteBestanden", "strNoteCustom1", "strNoteCustom2", "strNoteCustom3") FROM stdin;
1	1	Sehr gut	1	A	Excellent	1	t			
1	2	Noch sehr gut	1.30000000000000004	A	Excellent	1.30000000000000004	t			
1	3	Gut und besser	1.69999999999999996	B	Very Good	1.69999999999999996	t			
1	4	Gut	2	B	Very Good	2	t			
1	5	Noch gut	2.29999999999999982	C	Good	2.29999999999999982	t			
1	6	Befriedigend und besser	2.70000000000000018	C	Good	2.70000000000000018	t			
1	7	Befriedigend	3	C	Good	3	t			
1	8	Noch befriedigend	3.29999999999999982	D	Satisfactory	3.29999999999999982	t			
1	9	Ausreichend und besser	3.70000000000000018	E	Sufficient	3.70000000000000018	t			
1	10	Ausreichend	4	E	Sufficient	4	t			
1	11	Mangelhaft	5	F	Fail	5	f			
1	12	Ungenügend	6	FX	Fail	6	f			
1	0	Dummygrade	0	\N	\N	0	t	\N	\N	\N
1	15	Erlassen (bestanden)	0	--	Pass	0	t			
1	14	Anerkannt (bestanden)	0	Anerkannt	Pass	0	t	\N	\N	\N
1	16	Nicht erschienen	0	--	Fail	7	f	\N	\N	\N
1	13	Unbenotet (bestanden)	0	Unbenotet	Pass	0	t	\N	\N	\N
\.


--
-- TOC entry 2797 (class 0 OID 219795)
-- Dependencies: 199 2810
-- Data for Name: tblSdNutzer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdNutzer" ("strNutzerUniID", "strNutzerVorname", "strNutzerNachname", "strNutzerEmail", "strNutzerTelefon", "strNutzerTitel", "strNutzerInstitut", "intNutzerLevel") FROM stdin;
\.


--
-- TOC entry 2798 (class 0 OID 219801)
-- Dependencies: 200 2810
-- Data for Name: tblSdPruefung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdPruefung" ("lngSdSeminarID", "lngPruefungID", "strPruefungBezeichnung", "strPruefungBeschreibung", "strPruefungFach", "strPruefungAbschluss", "strPruefungsordnung", "blnPruefungHauptfach", "strPruefungZUVAmt", "strPruefungZUVFach", "strPruefungZUVTyp", "sngPruefungMinCreditPts", "blnPruefungECTSGewicht", "strPruefungBezeichnung_en", "strPruefungBeschreibung_en", "strPruefungFach_en", "strPruefungAbschluss_en", "strPruefungCustom1", "strPruefungCustom2", "strPruefungCustom3", "blnPruefungTriggered") FROM stdin;
1	0	Orientierungsprüfung	HF	Englisch/Englische Philologie	LA / MA / Promotion	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	t	1125002	8351	  4	0	\N								\N
1	1	Orientierungsprüfung	NF - Sprachwissenschaft -	Englisch/Englische Philologie	LA / MA / Promotion	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.01	f	1125002	8372	  4	0	\N								\N
1	2	Orientierungsprüfung	NF - Literaturwissenschaft -	Englisch/Englische Philologie	LA / MA / Promotion	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.01	f	1125002	8362	  4	0	\N								\N
1	1000	Bachelor	BA 75%	Anglistik BA 75%	BA		t	1125002	GSBA	BA	0	\N								\N
1	1100	Bachelor	BA 50%	Anglistik BA 50%	BA		t	1125002	GSBA	BA	0	\N								\N
1	1101	Bachelor	BA 50% [2. HF]	Anglistik BA 50%	BA		t	1125002	GSBA	BA	0	\N								\N
1	1200	Bachelor	BA 25% S	Anglistik BA 25% Sprachwissenschaft	BA		f	1125002	GSBA	BA	0	\N								\N
1	1300	Bachelor	BA 25% L	Anglistik BA 25% Literaturwissenschaft	BA		f	1125002	GSBA	BA	0	\N								\N
1	1400	Bachelor	BA 25% K	Anglistik 25% Kulturwissenschaft	BA		f	1125002	GSBA	BA	0	\N								\N
1	100	Orientierungsprüfung BA HF	Orientierungsprüfung BA HF	Anglistik	BA	Prüfungsordnung der Universität Heidelberg für den Bachelorstudiengang	t	1125002	ASBA	4	0	t								\N
1	22	Zwischenprüfung im Hauptfach	HF (Magister ohne Latein)	Englische Philologie	Magister	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	t	1125002	8351	5	0	f	\N	\N	\N	\N	\N	\N	\N	\N
1	15	Zwischenprüfung im Hauptfach	(LA mit Latein)	Englisch	Lehramt	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	t	1125002	8351	5	0	f	\N	\N	\N	\N	\N	\N	\N	\N
1	16	Zwischenprüfung im Hauptfach	(LA ohne Latein)	Englisch/Englische Philologie	Lehramt	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	t	1125002	8351	5	0	f	\N	\N	\N	\N	\N	\N	\N	\N
1	20	Zwischenprüfung im Nebenfach	NF Lehramt ohne Latein	Englisch	Lehramt	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	f	1125002	8352	5	0	f	\N	\N	\N	\N	\N	\N	\N	\N
1	5044	Master					f				0	f	Master				\N	\N	\N	\N
1	5043	Master					f				0	f	Master				\N	\N	\N	\N
1	5045	Master					f				0	f	Master				\N	\N	\N	\N
1	21	Zwischenprüfung im Nebenfach Sprachwissenschaft	NF (Sprachwissenschaft)	Englisch/Englische Philologie (Sprachwissenschaft)	LA / MA / Promotion	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	f	1125002	8372	5	0	f	\N	\N	\N	\N	\N	\N	\N	\N
1	13	Zwischenprüfung im Hauptfach	HF (Magister mit Latein)	Englische Philologie	Magister	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	t	1125002	8351	5	0	f	\N	\N	\N	\N	\N	\N	\N	\N
1	17	Zwischenprüfung im NF Literaturwissenschaft	NF (Literaturwissenschaft)	Englisch/Englische Philologie (Literaturwiss.)	LA / MA / Promotion	Prüfungsordnung der Neuphilologischen Fakultät der Universität Heidelberg vom 28.03.2001	f	1125002	8362	5	0	f	\N	\N	\N	\N	\N	\N	\N	\N
1	1401	Bachelor	Bachelor Anglistik 75% neue Prüfungsordnung (ab WS 2010/11)	Bachelor 75% (PO ab 1.10.2010)	Bachelor	Prüfungsordnung ab 1.10.2010	t				0	t	Bachelor			Bachelor	\N	\N	\N	\N
1	1402	Bachelor	Bachelor Anglistik 50% 1. Hauptfach neue PO ab WS 2010/11	Bachelor 50% (PO ab 1.10.2010)	Bachelor	Neue PO ab 1.10.2010	t				0	t	Bachelor			Bachelor	\N	\N	\N	\N
1	1403	Bachelor	Bachelor Anglistik 2. HF 50% neue Prüfungsordnung (ab WS 2010/11)	Bachelor 50% (PO ab 1.10.2010)	Bachelor	Neue Prüfungsordnung ab WS 2010/11	t				0	t	Bachelor			Bachelor	\N	\N	\N	\N
1	1404	Bachelor	Bachelor 25% Kulturwissenschaft ab WS 2010/11	Bachelor Anglistik Kulturwissenschaft 25% 2010/11	Bachelor	Neue Prüfungsordnung ab WS 2010/11	f				0	t	Bachelor			Bachelor	\N	\N	\N	\N
1	1405	Bachelor	Bachelor 25% Anglistik Literaturwissenschaft ab WS 2010/11	Bachelor Anglistik Literaturwiss. 25% 2010/11	Bachelor	Neue Prüfungsordnung WS 2010/11	f				0	t	Bachelor			Bachelor	\N	\N	\N	\N
1	1406	Bachelor	Bachelor Anglistik Sprachwissenschaft 25% neue Prüfungsordnung (ab WS 2010/11)	Bachelor Anglistik Sprachwiss. 25% 2010/11	Bachelor	Neue Prüfungsordnung ab WS 2010/11	f				0	t	Bachelor			Bachelor	\N	\N	\N	\N
1	1407	Staatsexamen	Staatsexamen nach GymPO (neu im WS 2010/11)	Anglistik	Staatexamen	GymPO vom WS 2010/11	t				0	t	Staatsexamen		English	Staatsexamen	\N	\N	\N	\N
1	1408	Modul Literaturwiss.	Modul Literaturwiss. für HCA-Studierende				f				0	t	Modul Literaturwiss.				\N	\N	\N	\N
1	5000	MA	MA Hauptfach Anglistik, Schwerpunkt Linguistik	Germanistik	MA		t	1125002	GSMA	MA	0	\N								\N
1	5010	MA	MA Hauptfach Anglistik, Schwerpunkt Literaturwissenschaft	Germanistik	MA		t	1125002	GSMA	MA	0	\N								\N
1	5020	MA	MA Begleitfach Anglistik, Schwerpunkt Sprachwissenschaft	Germanistik	MA		f	1125002	GSMA	MA	0	\N								\N
1	5030	MA	MA Begleitfach Anglistik, Schwerpunkt Literaturwissenschaft	Germanistik	MA		f	1125002	GSMA	MA	0	\N								\N
1	5040	MA	MA Begleitfach Anglistik, Schwerpunkt Methodologie und Forschungspraxis	Germanistik	MA		f	1125002	GSMA	MA	0	\N								\N
1	5041	Master					f				0	f	Master				\N	\N	\N	\N
1	5042	Master					f				0	f	Master				\N	\N	\N	\N
1	5046	Master					f				0	f	Master				\N	\N	\N	\N
1	5047	Master					f				0	f	Master				\N	\N	\N	\N
1	5048	Zwischenprüfung					t				0	t	Intermediate Exam				\N	\N	\N	f
1	200001	Zwischenprüfung Anglistik	Zwischenprüfung Anglistik nach GymPO			GymPO	t	1125002		5	0	t								t
1	200000	Orientierungsprüfung Anglistik	Orientierungsprüfung Anglistik nach GymPO oder BA 50% oder 75%			GymPO	t	1125002		4	0	t								t
1	101	Orientierungsprüfung BA 25% K	Orientierungsprüfung BA 25% K	Anglistik	BA	Prüfungsordnung der Universität Heidelberg für den Bachelorstudiengang	f	1125002	GSBA	4	0	t								t
1	102	Orientierungsprüfung BA 25% S	Orientierungsprüfung BA 25% S	Anglistik	BA	Prüfungsordnung der Universität Heidelberg für den Bachelorstudiengang	f	1125002	GSBA	4	0	t								t
1	103	Orientierungsprüfung BA 25% L	Orientierungsprüfung BA 25% LS	Anglistik	BA	Prüfungsordnung der Universität Heidelberg für den Bachelorstudiengang	f	1125002	GSBA	4	0	t								t
\.


--
-- TOC entry 2799 (class 0 OID 219820)
-- Dependencies: 201 2810
-- Data for Name: tblSdPruefungAblauf; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdPruefungAblauf" ("lngSdSeminarID", "lngPruefungID", "lngAblaufID", "strPruefungAblaufBezeichnung", "strPruefungAblaufBeschreibung", "blnPruefungAblaufPrereq", "blnPruefungAblaufStudentinfo", "strCustom1", "strCustom2", "strCustom3") FROM stdin;
\.


--
-- TOC entry 2800 (class 0 OID 219830)
-- Dependencies: 202 2810
-- Data for Name: tblSdPruefungRegel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdPruefungRegel" ("lngSdSeminarID", "lngPruefungID", "lngRegelID", "strPruefungRegelBezeichnung", "strPruefungRegelBeschreibung", "strCustom1", "strCustom2", "strCustom3") FROM stdin;
1	200001	1	OR	Es können Latinum ODER Fremdsprachenkenntnisse eingebracht werden			
1	200001	2	OR	Es können PS I anwendungsorientierte oder \nPS I theoretische Proseminare Kulturwissenschaft eingebracht werden			
\.


--
-- TOC entry 2801 (class 0 OID 219841)
-- Dependencies: 203 2810
-- Data for Name: tblSdPruefungRegelDetail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdPruefungRegelDetail" ("lngSdSeminarID", "lngPruefungID", "lngRegelID", "lngLeistungsID", "lngModulID", "strCustom1", "strCustom2", "strCustom3") FROM stdin;
1	200001	1	8	100010			
1	200001	1	9	100010			
1	200001	2	10070	100235			
1	200001	2	10080	100235			
\.


--
-- TOC entry 2802 (class 0 OID 219847)
-- Dependencies: 204 2810
-- Data for Name: tblSdPruefungXFach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdPruefungXFach" ("lngSdSeminarID", "lngPruefungID", "intFachID", "strBemerkung", "blnPruefungFachAbschluss") FROM stdin;
1	5041	210915	\N	t
1	5043	211117	\N	t
1	200000	200822		f
1	100	83504	Orientierungspr. Anglistik HF 50	f
1	100	83505	Orientierungspr. Anglistik HF 50	f
1	100	83907	Orientierungspr. Anglistik HF 75	f
1	0	8351	Orientierungspr. Anglistik HF	f
1	0	8361	Orientierungspr. Anglistik HF	f
1	1000	83907	HF 75% BA Anglistik	t
1	1101	83504	HF 50% BA Anglistik, 2. HF	t
1	1100	83505	HF 50% BA Anglistik, 1. HF	t
1	1200	92402	HF 25% BA Anglistik S	t
1	1300	92302	HF 25% BA Anglistik L	t
1	1400	92202	HF 25% BA Anglistik K	t
1	0	8371	Orientierungspr. Anglistik HF	f
1	0	8352	Orientierungspr. Anglistik Beifach	f
1	1	8372	Orientierungspr. Anglistik NF Sprachwiss.	f
1	2	8362	Orientierungspr. Anglistik NF Litwiss.	f
1	15	8351	Zwischenpr. Anglistik HF	f
1	15	8361	Zwischenpr. Anglistik HF	f
1	15	8371	Zwischenpr. Anglistik HF	f
1	13	8351	Zwischenpr. Anglistik HF	f
1	13	8361	Zwischenpr. Anglistik HF	f
1	13	8371	Zwischenpr. Anglistik HF	f
1	16	8351	Zwischenpr. Anglistik HF	f
1	16	8361	Zwischenpr. Anglistik HF	f
1	16	8371	Zwischenpr. Anglistik HF	f
1	22	8351	Zwischenpr. Anglistik HF	f
1	22	8361	Zwischenpr. Anglistik HF	f
1	22	8371	Zwischenpr. Anglistik HF	f
1	17	8362	Zwischenpr. Anglistik NF Lit	f
1	20	8352	Zwischenpr. Anglistik NF	f
1	21	8372	Zwischenpr. Anglistik NF	f
1	1401	200216	\N	t
1	1402	200317	\N	t
1	1403	200418	\N	t
1	1404	200519	\N	t
1	1405	200620	\N	t
1	1406	200721	\N	t
1	1407	200822	\N	t
1	5000	210810	MA Hauptfach Anglistik, Schwerpunkt Linguistik	t
1	5010	210811	MA Hauptfach Anglistik, Schwerpunkt Literaturwissenschaft	t
1	5020	210812	MA Begleitfach Anglistik, Schwerpunkt Sprachwissenschaft	t
1	5030	210813	MA Begleitfach Anglistik, Schwerpunkt Literaturwissenschaft	t
1	5040	210814	MA Begleitfach Anglistik, Schwerpunkt Methodologie und Forschungspraxis	t
1	5042	211016	\N	t
1	5044	211218	\N	t
1	5046	211319	\N	t
1	5047	211420	\N	t
1	200001	200822		f
1	100	8351		t
1	100	8352		t
1	1408	200923	\N	t
1	101	200519	Orientierungspr. Anglistik NF K	f
1	103	200620	Orientierungspr. Anglistik NF L	f
1	102	200721	Orientierungspr. Anglistik NF S	f
1	200000	200216		f
1	200000	200317		f
1	200000	200418		f
\.


--
-- TOC entry 2803 (class 0 OID 219854)
-- Dependencies: 205 2810
-- Data for Name: tblSdPruefungXModul; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdPruefungXModul" ("lngSdSeminarID", "lngPruefungID", "lngModulID", "sngPruefungLeistungGewichtung", "sngMinCreditPts", "strCustom1", "strCustom2", "strCustom3", "strCustom1_en", "strCustom2_en", "strCustom3_en", "sngMinCreditPtsPLeistung", "sngMinCreditPtsSLeistung", "blnZulassungsvoraussetzung", "lngPruefungModulSequence") FROM stdin;
1	1100	112	1	10.5							10.5	\N	f	0
1	1101	118	1	9.5							9.5	\N	f	0
1	1400	601	1	9.5	\N	\N	\N	\N	\N	\N	9.5	0	f	0
1	0	100	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	1	101	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	2	102	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	13	103	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	15	103	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	15	106	0	9	\N	\N	\N	\N	\N	\N	9	0	f	0
1	15	107	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	15	108	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	16	104	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	16	106	0	9	\N	\N	\N	\N	\N	\N	9	0	f	0
1	13	106	0	9	\N	\N	\N	\N	\N	\N	9	0	f	0
1	13	107	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	13	108	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	16	107	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	16	108	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	17	105	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	22	106	0	9	\N	\N	\N	\N	\N	\N	9	0	f	0
1	21	105	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	21	106	0	9	\N	\N	\N	\N	\N	\N	9	0	f	0
1	21	108	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	17	106	0	9	\N	\N	\N	\N	\N	\N	9	0	f	0
1	22	107	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	17	107	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	22	108	0	5.5	\N	\N	\N	\N	\N	\N	5.5	0	f	0
1	5041	9100041	1	30							30	\N	\N	0
1	5041	9100051	2	10							10	\N	\N	0
1	5041	9100021	0	22	Es ist ein beliebiges PS II aus dieser Liste zu absolvieren, und zwei beliebige Vorlesungen aus der Liste\n						22	\N	\N	0
1	22	100005	0	0	\N	\N	\N	\N	\N	\N	0	0	t	0
1	5046	9100091	0	20	Es sind ein Proseminar II, eine Vorlesung Literatur- oder Kulturwissenschaft, ein Hauptseminar und einmal Independent Studies zu absolvieren\n						20	\N	\N	0
1	5046	9100021	1	22	Es ist ein beliebiges PS II aus dieser Liste zu absolvieren, und zwei beliebige Vorlesungen aus der Liste\n						22	\N	\N	0
1	200000	100015	0	\N							8	\N	t	0
1	1000	115	1	6							6	\N	f	0
1	1000	116	1	8							8	\N	f	0
1	1000	117	1	9.5							9.5	\N	f	0
1	1000	119	1	9.5							9.5	\N	f	0
1	1000	125	1	18							18	\N	f	0
1	1000	200	1	24							24	\N	f	0
1	1200	120	1	10							10	\N	f	0
1	1401	100075	1	17	Kulturwissenschaft entweder anwendungsorientiert oder theoretisch\n						17	\N	\N	0
1	5042	9100051	2	10							10	\N	\N	0
1	5042	9100061	1	22	Es sind zwei Vorlesungen Literatur- oder Kulturwissenschaft zu absolvieren\n						22	\N	\N	0
1	5042	9100041	0	30							30	\N	\N	0
1	1000	300	-1	12							12	\N	f	3000
1	1407	9100011	-1	0							\N	\N	\N	700
1	1000	400	2	8							8	\N	f	2000
1	1407	100010	0	0	\N	\N	\N	\N	\N	\N	0	0	f	500
1	5046	9100051	2	10							10	\N	\N	2000
1	5047	9100051	2	10							10	\N	\N	2000
1	5046	9100041	1	30							30	\N	\N	3000
1	5047	9100061	1	22	Es sind zwei Vorlesungen Literatur- oder Kulturwissenschaft zu absolvieren\n						22	\N	\N	0
1	5047	9100081	0	20	Es sind ein Proseminar II, eine Vorlesung, ein Hauptseminar und einmal Independent Studies zu absolvieren\n						20	\N	\N	0
1	200001	100015	0	\N							8	\N	t	0
1	200001	100010	0	\N							0	\N	t	0
1	200001	100035	1	\N							6	\N	t	0
1	200001	100045	1	\N							7	\N	t	0
1	200001	100025	1	\N							5	\N	t	0
1	200001	100235	1	\N							17	\N	t	0
1	200001	100285	1	\N							5	\N	t	0
1	1401	100025	1	5							5	\N	\N	0
1	5043	9100081	1	20	Es sind ein Proseminar II, eine Vorlesung, ein Hauptseminar und einmal Independent Studies zu absolvieren\n						20	\N	\N	0
1	5000	200000	1	8							8	0	f	0
1	5000	200010	1	10							10	0	f	0
1	5000	200020	1	12							12	0	f	0
1	5000	200030	1	20							20	0	f	0
1	5000	200040	1	16							16	0	f	0
1	5000	200050	1	34							34	0	f	0
1	5010	200060	1	8							8	0	f	0
1	5010	200070	1	10							10	0	f	0
1	5010	200020	1	12							12	0	f	0
1	5010	200080	1	20							20	0	f	0
1	5010	200090	1	16							16	0	f	0
1	5010	200050	1	34							34	0	f	0
1	5020	200100	1	8							8	0	f	0
1	5020	200110	1	8							8	0	f	0
1	5020	200120	1	12							12	0	f	0
1	5020	200130	1	8							8	0	f	0
1	5030	200140	1	8							8	0	f	0
1	5030	200150	1	8							8	0	f	0
1	5030	200120	1	4							4	0	f	0
1	5030	200160	1	8							8	0	f	0
1	5040	200170	1	20							20	0	f	0
1	5000	200140	1	8							8	0	f	0
1	5000	200150	1	8							8	0	f	0
1	5000	200120	1	4							4	0	f	0
1	5000	200160	1	8							8	0	f	0
1	5000	200170	1	20							20	0	f	0
1	1000	112	1	10.5							10.5	\N	f	0
1	1000	118	1	9.5							9.5	\N	f	0
1	5047	9100041	1	30							30	\N	\N	3000
1	5010	200170	0	20							20	0	f	0
1	100	109	0	0							0	\N	t	0
1	101	80	0	0							0	\N	t	0
1	103	80	0	0							0	\N	t	0
1	102	81	0	0							0	\N	t	0
1	1100	116	1	8							8	\N	f	0
1	1100	117	1	9.5							9.5	\N	f	0
1	1100	118	1	9.5							9.5	\N	f	0
1	1100	119	1	9.5							9.5	\N	f	0
1	1100	600	1	12							12	\N	f	0
1	1200	110	0	5							5	\N	f	0
1	1101	109	0	10							10	\N	f	0
1	1000	109	0	10							10	\N	f	0
1	1101	112	1	10.5							10.5	\N	f	0
1	1101	116	1	8							8	\N	f	0
1	1101	117	1	9.5							9.5	\N	f	0
1	1101	119	1	9.5							9.5	\N	f	0
1	1101	600	1	12							12	\N	f	0
1	1400	113	1	4.5							4.5	\N	f	0
1	1100	109	0	10							10	\N	f	0
1	1400	114	1	6							6	\N	f	0
1	1400	122	1	10							10	\N	f	0
1	1400	111	0	5							5	\N	f	0
1	1300	113	1	4.5							4.5	\N	f	0
1	1300	114	1	6							6	\N	f	0
1	1300	118	1	9.5							9.5	\N	f	0
1	1300	121	1	10							10	\N	f	0
1	1300	111	0	5							5	\N	f	0
1	1200	113	1	4.5							4.5	\N	f	0
1	1200	114	1	6							6	\N	f	0
1	1200	117	1	9.5							9.5	\N	f	0
1	1401	100015	0	8							8	\N	\N	0
1	1401	100065	0	12							12	\N	\N	0
1	1402	100015	0	8							8	\N	\N	0
1	1402	100065	0	12							12	\N	\N	0
1	1403	100015	0	8							8	\N	\N	0
1	1403	100065	0	12							12	\N	\N	0
1	1404	100155	0	4							4	\N	\N	0
1	1405	100155	0	4							4	\N	\N	0
1	1401	100035	1	6							6	\N	\N	0
1	1401	100045	1	7							7	\N	\N	0
1	1401	100055	1	8	zwei beliebige Kurse aus Advanced English in Use\n						8	\N	\N	0
1	1401	100085	1	18							18	\N	\N	0
1	1401	100105	1	24	Aus diesem Modul sind zu wählen:  1 PS Sprachwissenschaft, 1 PS Literatur- oder Kulturwissenschaft, 1 Vorlesung Sprachwissenschaft, 1 Vorlesung Literaturwissenschaft und 1 weitere beliebige Vorlesung						24	\N	\N	0
1	1402	100025	1	5							5	\N	\N	0
1	1407	100025	1	5							5	\N	\N	0
1	1402	100045	1	7							7	\N	\N	0
1	1000	500	0	20							20	\N	f	1000
1	1100	300	-1	12							12	\N	f	3000
1	1401	100115	-1	12							12	\N	\N	3000
1	1401	100125	2	8							8	\N	\N	2000
1	1407	100015	1	8							8	\N	\N	0
1	1100	400	2	5							5	\N	f	2000
1	1101	400	2	5							5	\N	f	2000
1	1402	100055	1	8	zwei beliebige Kurse aus Advanced English in Use\n						8	\N	\N	0
1	1402	100075	1	17	Kulturwissenschaft entweder anwendungsorientiert oder theoretisch\n						17	\N	\N	0
1	1407	100035	1	6							6	\N	\N	0
1	1403	100025	1	5							5	\N	\N	0
1	1407	100045	1	7							7	\N	\N	0
1	1403	100045	1	7							7	\N	\N	0
1	1403	100055	1	8	zwei beliebige Kurse aus Advanced English in Use\n						8	\N	\N	0
1	1403	100075	1	17	Kulturwissenschaft entweder anwendungsorientiert oder theoretisch\n						17	\N	\N	0
1	1403	100125	2	5							5	\N	\N	0
1	1407	100225	1	8							8	\N	\N	0
1	1404	100025	1	5							5	\N	\N	0
1	1407	100245	1	18	Es ist nur ein Proseminar Sprachwissenschaft zu belegen: entweder Überblick oder Periode\n						18	\N	\N	0
1	1404	100165	1	7							7	\N	\N	0
1	1404	100175	1	10							10	\N	\N	0
1	1407	100235	1	17	Es ist nur ein Proseminar Kulturwissenschaft zu belegen: entweder das anwendungsorientierte oder das theoretische\n						17	\N	\N	0
1	1405	100025	1	5							5	\N	\N	0
1	1405	100185	1	7							7	\N	\N	0
1	1405	100195	1	10							10	\N	\N	0
1	1404	114	1	9	3 Kurse English in Use. Es können auch andere sprachpraktische Kurse mit 3 LP angerechnet werden -- informieren Sie sich hierzu bei der Fachstudienberatung.\n						9	\N	\N	0
1	1406	100025	1	5							5	\N	\N	0
1	1406	100205	1	7							7	\N	\N	0
1	1406	100215	1	10							10	\N	\N	0
1	1405	114	1	9	3 Kurse English in Use						9	\N	\N	0
1	1403	100145	1	12	Zu absolvieren sind das PS II Sprachwissenschaft und ein weiteres PS II						12	\N	\N	0
1	1402	100145	1	12	Zu absolvieren sind das PS II Sprachwissenschaft und ein weiteres PS II						12	\N	\N	0
1	1407	100275	1	16							16	\N	\N	0
1	1406	114	1	9	3 Kurse English in Use						9	\N	\N	0
1	1406	100315	0	4							4	\N	\N	0
1	1408	100325	0	14							14	\N	\N	0
1	1100	500	0	10							10	\N	f	1000
1	1101	500	0	10							10	\N	f	1000
1	1401	500	0	20							20	\N	\N	1000
1	1403	500	0	10							10	\N	\N	1000
1	1402	500	0	10							10	\N	\N	1000
1	1402	100115	-1	12							12	\N	\N	3000
1	5046	9100031	1	38	Es sind zwei beliebige Vorlesungen aus dieser Liste zu absolvieren, sowie zwei Hauptseminare und zwei Einheiten Independent Studies\n						38	\N	\N	0
1	5047	9100071	1	38	Es sind zwei Vorlesungen Literatur- oder Kulturwissenschaft zu absolvieren, sowie zwei Hauptseminare und zwei Einheiten Independent Studies\n						38	\N	\N	0
1	5042	9100071	1	38	Es sind zwei Vorlesungen Literatur- oder Kulturwissenschaft zu absolvieren, sowie zwei Hauptseminare und zwei Einheiten Independent Studies\n						38	0	f	0
1	5041	9100031	1	38	Es sind zwei beliebige Vorlesungen aus dieser Liste zu absolvieren, sowie zwei Hauptseminare und zwei Einheiten Independent Studies\n						38	\N	\N	0
1	1407	100305	1	9	Beliebige Auswahl aus diesen Kurstypen\n						9	\N	\N	700
1	1402	100125	2	5							5	\N	\N	2000
1	5044	9100091	1	20	Es sind ein Proseminar II, eine Vorlesung Literatur- oder Kulturwissenschaft, ein Hauptseminar und einmal Independent Studies zu absolvieren\n						20	\N	\N	0
1	1407	100285	0	5							5	\N	\N	0
1	1407	100295	0	5							5	\N	\N	0
1	1407	100255	-1	6							6	\N	\N	0
\.


--
-- TOC entry 2804 (class 0 OID 219867)
-- Dependencies: 206 2810
-- Data for Name: tblSdPruefungXPruefung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdPruefungXPruefung" ("lngSdSeminarID", "lngPruefungID", "lngPruefungPrereqID", "strPruefungBemerkung") FROM stdin;
1	13	0	\N
1	15	0	\N
1	22	0	\N
1	16	0	\N
1	17	2	\N
1	21	1	\N
\.


--
-- TOC entry 2805 (class 0 OID 219874)
-- Dependencies: 207 2810
-- Data for Name: tblSdRaum; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdRaum" ("lngSdSeminarID", "strRaumBezeichnung", "strRaumBeschreibung", "strRaumUnivISID") FROM stdin;
1	108		
1	110		
1	112		
1	113		
1	114		
1	115		
1	116		
1	122		
1	333		
\.


--
-- TOC entry 2806 (class 0 OID 219882)
-- Dependencies: 208 2810
-- Data for Name: tblSdSeminar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdSeminar" ("lngUniID", "lngFakultaetID", "lngSeminarID", "strSeminarUnivISID", "strSeminarName", "strSeminarLink", "strSeminarCustom1", "strSeminarCustom2", "strSeminarCustom3", "strSeminarShort", "blnSeminarNoteCboLocal") FROM stdin;
0	0	1		Anglistik	http://as.uni-hd.de	\N	\N	\N	as	\N
\.


--
-- TOC entry 2807 (class 0 OID 219894)
-- Dependencies: 209 2810
-- Data for Name: tblSdSeminarXFach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdSeminarXFach" ("lngSeminarID", "intFachID", "strSdSeminarXFachBemerkung") FROM stdin;
1	92402	
1	92302	
1	92202	
1	200216	
1	200317	
1	200418	
1	200519	
1	200620	
1	200721	
1	200822	
1	200923	
1	210810	
1	210811	
1	210812	
1	210813	
1	210814	
1	210915	
1	211016	
1	211117	
1	211218	
1	211319	
1	211420	
\.


--
-- TOC entry 2808 (class 0 OID 219913)
-- Dependencies: 210 2810
-- Data for Name: tblSdUni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tblSdUni" ("lngSdUniID", "strUniName", "strUniOrt", "strUniLink") FROM stdin;
0	UP-Universität	Deutschland	http://www.shj-online.de
\.


--
-- TOC entry 2809 (class 0 OID 219917)
-- Dependencies: 211 2810
-- Data for Name: tmpDays; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "tmpDays" ("strTag", "intSort") FROM stdin;
Montag	1
Dienstag	2
Mittwoch	3
Donnerstag	4
Freitag	5
\.


--
-- TOC entry 2409 (class 2606 OID 220291)
-- Dependencies: 177 177 177 177 2811
-- Name: pkey_antrag; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentAntrag"
    ADD CONSTRAINT "pkey_antrag" PRIMARY KEY ("lngSdSeminarID", "strMatrikelnummer", "lngStudentAntragID");


--
-- TOC entry 2412 (class 2606 OID 220293)
-- Dependencies: 178 178 178 178 178 2811
-- Name: pkey_antragstatus; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentAntragStatus"
    ADD CONSTRAINT "pkey_antragstatus" PRIMARY KEY ("lngSdSeminarID", "strMatrikelnummer", "lngStudentAntragID", "lngStudentAntragStatusID");


--
-- TOC entry 2418 (class 2606 OID 220295)
-- Dependencies: 182 182 182 182 2811
-- Name: pkey_dokumente; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentDokument"
    ADD CONSTRAINT "pkey_dokumente" PRIMARY KEY ("lngSdSeminarID", "strMatrikelnummer", "strVerifikationscode");


--
-- TOC entry 2356 (class 2606 OID 220297)
-- Dependencies: 168 168 168 168 168 2811
-- Name: pkey_kurstermin; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursTermin"
    ADD CONSTRAINT "pkey_kurstermin" PRIMARY KEY ("lngSdSeminarID", "lngKursID", "intKursTerminNummer", "intKursTerminPrioritaet");


--
-- TOC entry 2341 (class 2606 OID 220305)
-- Dependencies: 163 163 163 163 163 2811
-- Name: pkey_tblbdanmeldung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdAnmeldung"
    ADD CONSTRAINT "pkey_tblbdanmeldung" PRIMARY KEY ("lngSdSeminarID", "strMatrikelnummer", "lngKursID", "lngKurstypID");


--
-- TOC entry 2343 (class 2606 OID 220307)
-- Dependencies: 164 164 164 164 164 164 2811
-- Name: pkey_tblbdanmeldungswap; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdAnmeldungSwap"
    ADD CONSTRAINT "pkey_tblbdanmeldungswap" PRIMARY KEY ("lngSdSeminarID", "strMatrikelnummer", "lngKursID", "lngKursIDWunsch", "lngKurstypID");


--
-- TOC entry 2336 (class 2606 OID 220311)
-- Dependencies: 161 161 161 2811
-- Name: pkey_tblbddata; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdData"
    ADD CONSTRAINT "pkey_tblbddata" PRIMARY KEY ("lngSdSeminarID", "strSemesterbezeichnung");


--
-- TOC entry 2346 (class 2606 OID 220313)
-- Dependencies: 165 165 2811
-- Name: pkey_tblbddozentbemerkung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdDozentBemerkung"
    ADD CONSTRAINT "pkey_tblbddozentbemerkung" PRIMARY KEY ("lngDozentBemerkungID");


--
-- TOC entry 2354 (class 2606 OID 220319)
-- Dependencies: 167 167 167 2811
-- Name: pkey_tblbdkurs; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKurs"
    ADD CONSTRAINT "pkey_tblbdkurs" PRIMARY KEY ("lngSdSeminarID", "lngKursID");


--
-- TOC entry 2363 (class 2606 OID 220321)
-- Dependencies: 169 169 169 169 2811
-- Name: pkey_tblbdkursxkurstyp; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursXKurstyp"
    ADD CONSTRAINT "pkey_tblbdkursxkurstyp" PRIMARY KEY ("lngSeminarID", "lngKurstypID", "lngKursID");


--
-- TOC entry 2369 (class 2606 OID 220323)
-- Dependencies: 170 170 170 170 2811
-- Name: pkey_tblbdkursxlink; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursXLink"
    ADD CONSTRAINT "pkey_tblbdkursxlink" PRIMARY KEY ("lngSdSeminarID", "lngKursID", "lngLinkID");


--
-- TOC entry 2374 (class 2606 OID 220325)
-- Dependencies: 171 171 2811
-- Name: pkey_tblbdkvvarchiv; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKvvArchiv"
    ADD CONSTRAINT "pkey_tblbdkvvarchiv" PRIMARY KEY ("lngID");


--
-- TOC entry 2380 (class 2606 OID 220327)
-- Dependencies: 172 172 172 2811
-- Name: pkey_tblbdkvvarchivxlinks; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKvvArchivXLinks"
    ADD CONSTRAINT "pkey_tblbdkvvarchivxlinks" PRIMARY KEY ("lngID", "lngLinkID");


--
-- TOC entry 2388 (class 2606 OID 220331)
-- Dependencies: 173 173 173 173 173 173 2811
-- Name: pkey_tblbdpruefungablauf; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdPruefungAblauf"
    ADD CONSTRAINT "pkey_tblbdpruefungablauf" PRIMARY KEY ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", "lngAblaufID");


--
-- TOC entry 2392 (class 2606 OID 220333)
-- Dependencies: 174 174 174 2811
-- Name: pkey_tblbdraumplanextern; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdRaumplanExtern"
    ADD CONSTRAINT "pkey_tblbdraumplanextern" PRIMARY KEY ("lngSdSeminarID", "lngLfdNr");


--
-- TOC entry 2394 (class 2606 OID 220337)
-- Dependencies: 175 175 175 175 175 2811
-- Name: pkey_tblbdsprechstunde; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdSprechstunde"
    ADD CONSTRAINT "pkey_tblbdsprechstunde" PRIMARY KEY ("lngSdSeminarID", "lngDozentID", "dtmSprechstundeDatum", "tmeSprechstundeStart");


--
-- TOC entry 2404 (class 2606 OID 220339)
-- Dependencies: 176 176 2811
-- Name: pkey_tblbdstudent; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudent"
    ADD CONSTRAINT "pkey_tblbdstudent" PRIMARY KEY ("lngStudentPID");


--
-- TOC entry 2416 (class 2606 OID 220341)
-- Dependencies: 181 181 2811
-- Name: pkey_tblbdstudentbemerkung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentBemerkung"
    ADD CONSTRAINT "pkey_tblbdstudentbemerkung" PRIMARY KEY ("lngStudentBemerkungID");


--
-- TOC entry 2429 (class 2606 OID 220345)
-- Dependencies: 183 183 183 183 183 183 183 183 2811
-- Name: pkey_tblbdstudentpruefungdetail; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentPruefungDetail"
    ADD CONSTRAINT "pkey_tblbdstudentpruefungdetail" PRIMARY KEY ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount", "lngLeistungsID", "lngStudentLeistungCount", "lngModulID");


--
-- TOC entry 2443 (class 2606 OID 220349)
-- Dependencies: 184 184 184 184 184 2811
-- Name: pkey_tblbdstudentxleistung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXLeistung"
    ADD CONSTRAINT "pkey_tblbdstudentxleistung" PRIMARY KEY ("lngSdSeminarID", "strMatrikelnummer", "lngLeistungsID", "lngStudentLeistungCount");


--
-- TOC entry 2452 (class 2606 OID 220353)
-- Dependencies: 185 185 185 185 185 2811
-- Name: pkey_tblbdstudentxpruefung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXPruefung"
    ADD CONSTRAINT "pkey_tblbdstudentxpruefung" PRIMARY KEY ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount");


--
-- TOC entry 2456 (class 2606 OID 220355)
-- Dependencies: 186 186 186 2811
-- Name: pkey_tblbdtermin; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdTermin"
    ADD CONSTRAINT "pkey_tblbdtermin" PRIMARY KEY ("lngSeminarID", "lngTerminID");


--
-- TOC entry 2458 (class 2606 OID 220357)
-- Dependencies: 187 187 2811
-- Name: pkey_tblinfo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblInfo"
    ADD CONSTRAINT "pkey_tblinfo" PRIMARY KEY ("strVersion");


--
-- TOC entry 2467 (class 2606 OID 220377)
-- Dependencies: 189 189 189 2811
-- Name: pkey_tblsddozent; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdDozent"
    ADD CONSTRAINT "pkey_tblsddozent" PRIMARY KEY ("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2469 (class 2606 OID 220379)
-- Dependencies: 190 190 2811
-- Name: pkey_tblsdfach; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdFach"
    ADD CONSTRAINT "pkey_tblsdfach" PRIMARY KEY ("intFachID");


--
-- TOC entry 2475 (class 2606 OID 220381)
-- Dependencies: 191 191 191 2811
-- Name: pkey_tblsdfakultaet; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdFakultaet"
    ADD CONSTRAINT "pkey_tblsdfakultaet" PRIMARY KEY ("lngSdUniID", "lngSdFakultaetID");


--
-- TOC entry 2481 (class 2606 OID 220385)
-- Dependencies: 192 192 192 2811
-- Name: pkey_tblsdkurstyp; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdKurstyp"
    ADD CONSTRAINT "pkey_tblsdkurstyp" PRIMARY KEY ("lngSdSeminarID", "lngKurstypID");


--
-- TOC entry 2485 (class 2606 OID 220387)
-- Dependencies: 193 193 193 2811
-- Name: pkey_tblsdkvvinhalt; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdKvvInhalt"
    ADD CONSTRAINT "pkey_tblsdkvvinhalt" PRIMARY KEY ("lngSdSeminarID", "intSdKvvInhaltNr");


--
-- TOC entry 2492 (class 2606 OID 220389)
-- Dependencies: 194 194 194 194 2811
-- Name: pkey_tblsdkvvinhaltxkurstyp; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdKvvInhaltXKurstyp"
    ADD CONSTRAINT "pkey_tblsdkvvinhaltxkurstyp" PRIMARY KEY ("lngSdSeminarID", "intKvvInhaltNr", "lngKurstypID");


--
-- TOC entry 2496 (class 2606 OID 220391)
-- Dependencies: 195 195 195 2811
-- Name: pkey_tblsdleistung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdLeistung"
    ADD CONSTRAINT "pkey_tblsdleistung" PRIMARY KEY ("lngSdSeminarID", "lngLeistungID");


--
-- TOC entry 2502 (class 2606 OID 220393)
-- Dependencies: 196 196 196 2811
-- Name: pkey_tblsdmodul; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdModul"
    ADD CONSTRAINT "pkey_tblsdmodul" PRIMARY KEY ("lngSdSeminarID", "lngModulID");


--
-- TOC entry 2510 (class 2606 OID 220395)
-- Dependencies: 197 197 197 197 2811
-- Name: pkey_tblsdmodulxleistung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdModulXLeistung"
    ADD CONSTRAINT "pkey_tblsdmodulxleistung" PRIMARY KEY ("lngSdSeminarID", "lngModulID", "lngLeistungID");


--
-- TOC entry 2515 (class 2606 OID 220397)
-- Dependencies: 198 198 198 2811
-- Name: pkey_tblsdnote; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdNote"
    ADD CONSTRAINT "pkey_tblsdnote" PRIMARY KEY ("lngSdSeminarID", "intNoteID");


--
-- TOC entry 2521 (class 2606 OID 220399)
-- Dependencies: 200 200 200 2811
-- Name: pkey_tblsdpruefung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefung"
    ADD CONSTRAINT "pkey_tblsdpruefung" PRIMARY KEY ("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2526 (class 2606 OID 220401)
-- Dependencies: 201 201 201 201 2811
-- Name: pkey_tblsdpruefungablauf; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungAblauf"
    ADD CONSTRAINT "pkey_tblsdpruefungablauf" PRIMARY KEY ("lngSdSeminarID", "lngPruefungID", "lngAblaufID");


--
-- TOC entry 2531 (class 2606 OID 220403)
-- Dependencies: 202 202 202 202 2811
-- Name: pkey_tblsdpruefungregel; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungRegel"
    ADD CONSTRAINT "pkey_tblsdpruefungregel" PRIMARY KEY ("lngSdSeminarID", "lngPruefungID", "lngRegelID");


--
-- TOC entry 2538 (class 2606 OID 220405)
-- Dependencies: 203 203 203 203 203 203 2811
-- Name: pkey_tblsdpruefungregeldetail; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungRegelDetail"
    ADD CONSTRAINT "pkey_tblsdpruefungregeldetail" PRIMARY KEY ("lngSdSeminarID", "lngPruefungID", "lngRegelID", "lngLeistungsID", "lngModulID");


--
-- TOC entry 2545 (class 2606 OID 220407)
-- Dependencies: 204 204 204 204 2811
-- Name: pkey_tblsdpruefungxfach; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXFach"
    ADD CONSTRAINT "pkey_tblsdpruefungxfach" PRIMARY KEY ("lngSdSeminarID", "lngPruefungID", "intFachID");


--
-- TOC entry 2553 (class 2606 OID 220409)
-- Dependencies: 205 205 205 205 2811
-- Name: pkey_tblsdpruefungxmodul; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXModul"
    ADD CONSTRAINT "pkey_tblsdpruefungxmodul" PRIMARY KEY ("lngSdSeminarID", "lngPruefungID", "lngModulID");


--
-- TOC entry 2559 (class 2606 OID 220411)
-- Dependencies: 206 206 206 206 2811
-- Name: pkey_tblsdpruefungxpruefung; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXPruefung"
    ADD CONSTRAINT "pkey_tblsdpruefungxpruefung" PRIMARY KEY ("lngSdSeminarID", "lngPruefungID", "lngPruefungPrereqID");


--
-- TOC entry 2564 (class 2606 OID 220413)
-- Dependencies: 207 207 207 2811
-- Name: pkey_tblsdraum; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdRaum"
    ADD CONSTRAINT "pkey_tblsdraum" PRIMARY KEY ("lngSdSeminarID", "strRaumBezeichnung");


--
-- TOC entry 2572 (class 2606 OID 220415)
-- Dependencies: 208 208 208 208 2811
-- Name: pkey_tblsdseminar; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdSeminar"
    ADD CONSTRAINT "pkey_tblsdseminar" PRIMARY KEY ("lngUniID", "lngFakultaetID", "lngSeminarID");


--
-- TOC entry 2578 (class 2606 OID 220417)
-- Dependencies: 209 209 209 2811
-- Name: pkey_tblsdseminarxfach; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdSeminarXFach"
    ADD CONSTRAINT "pkey_tblsdseminarxfach" PRIMARY KEY ("lngSeminarID", "intFachID");


--
-- TOC entry 2580 (class 2606 OID 220421)
-- Dependencies: 210 210 2811
-- Name: pkey_tblsduni; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdUni"
    ADD CONSTRAINT "pkey_tblsduni" PRIMARY KEY ("lngSdUniID");


--
-- TOC entry 2460 (class 2606 OID 220423)
-- Dependencies: 188 188 2811
-- Name: tblPostprocessing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblPostprocessing"
    ADD CONSTRAINT "tblPostprocessing_pkey" PRIMARY KEY ("strMatrikelnummer");


--
-- TOC entry 2517 (class 2606 OID 220425)
-- Dependencies: 199 199 2811
-- Name: tblSdNutzer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdNutzer"
    ADD CONSTRAINT "tblSdNutzer_pkey" PRIMARY KEY ("strNutzerUniID");


--
-- TOC entry 2430 (class 1259 OID 220427)
-- Dependencies: 184 184 184 2811
-- Name: idx6-19-ModulXLeistung-StudentXLeistung; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx6-19-ModulXLeistung-StudentXLeistung" ON "tblBdStudentXLeistung" USING "btree" ("lngSdSeminarID", "lngLeistungsID", "lngModulID");


--
-- TOC entry 2461 (class 1259 OID 220442)
-- Dependencies: 189 2811
-- Name: idx_114_{C7C513FD-304D-4BA9-900; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_114_{C7C513FD-304D-4BA9-900" ON "tblSdDozent" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2462 (class 1259 OID 220443)
-- Dependencies: 189 2811
-- Name: idx_115_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_115_lngSeminarID" ON "tblSdDozent" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2463 (class 1259 OID 220444)
-- Dependencies: 189 189 189 2811
-- Name: idx_117_LogicKey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_117_LogicKey" ON "tblSdDozent" USING "btree" ("lngSdSeminarID", "strDozentNachname", "strDozentPasswort");


--
-- TOC entry 2464 (class 1259 OID 220445)
-- Dependencies: 189 2811
-- Name: idx_118_strDozentSerialID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_118_strDozentSerialID" ON "tblSdDozent" USING "btree" ("strDozentCertSerialID");


--
-- TOC entry 2465 (class 1259 OID 220446)
-- Dependencies: 189 2811
-- Name: idx_119_strDozentUnivISID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_119_strDozentUnivISID" ON "tblSdDozent" USING "btree" ("strDozentUnivISID");


--
-- TOC entry 2470 (class 1259 OID 220447)
-- Dependencies: 191 2811
-- Name: idx_120_{7311B5D6-7C0E-413A-925; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_120_{7311B5D6-7C0E-413A-925" ON "tblSdFakultaet" USING "btree" ("lngSdUniID");


--
-- TOC entry 2471 (class 1259 OID 220448)
-- Dependencies: 191 2811
-- Name: idx_121_lngFakultaetID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_121_lngFakultaetID" ON "tblSdFakultaet" USING "btree" ("lngSdFakultaetID");


--
-- TOC entry 2472 (class 1259 OID 220449)
-- Dependencies: 191 2811
-- Name: idx_122_lngUniID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_122_lngUniID" ON "tblSdFakultaet" USING "btree" ("lngSdUniID");


--
-- TOC entry 2473 (class 1259 OID 220450)
-- Dependencies: 191 2811
-- Name: idx_123_strFakultaetUnivISID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_123_strFakultaetUnivISID" ON "tblSdFakultaet" USING "btree" ("strFakultaetUnivISID");


--
-- TOC entry 2476 (class 1259 OID 220453)
-- Dependencies: 192 2811
-- Name: idx_126_leistung_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_126_leistung_idx" ON "tblSdKurstyp" USING "btree" ("lngKurstypLeistungsID");


--
-- TOC entry 2477 (class 1259 OID 220454)
-- Dependencies: 192 2811
-- Name: idx_127_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_127_lngSeminarID" ON "tblSdKurstyp" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2478 (class 1259 OID 220455)
-- Dependencies: 192 2811
-- Name: idx_128_strKurstypUnivISID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_128_strKurstypUnivISID" ON "tblSdKurstyp" USING "btree" ("strKurstypUnivISID");


--
-- TOC entry 2479 (class 1259 OID 220456)
-- Dependencies: 192 192 2811
-- Name: idx_129_tblSdLeistungtblSdKurst; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_129_tblSdLeistungtblSdKurst" ON "tblSdKurstyp" USING "btree" ("lngSdSeminarID", "lngKurstypLeistungsID");


--
-- TOC entry 2482 (class 1259 OID 220457)
-- Dependencies: 193 2811
-- Name: idx_130_{40D0FEF4-7337-4E56-B05; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_130_{40D0FEF4-7337-4E56-B05" ON "tblSdKvvInhalt" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2483 (class 1259 OID 220458)
-- Dependencies: 193 2811
-- Name: idx_131_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_131_lngSeminarID" ON "tblSdKvvInhalt" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2486 (class 1259 OID 220459)
-- Dependencies: 194 194 2811
-- Name: idx_132_{0903AB7C-45D9-4733-898; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_132_{0903AB7C-45D9-4733-898" ON "tblSdKvvInhaltXKurstyp" USING "btree" ("lngSdSeminarID", "lngKurstypID");


--
-- TOC entry 2487 (class 1259 OID 220460)
-- Dependencies: 194 194 2811
-- Name: idx_133_{C3341EEC-A435-4C27-814; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_133_{C3341EEC-A435-4C27-814" ON "tblSdKvvInhaltXKurstyp" USING "btree" ("lngSdSeminarID", "intKvvInhaltNr");


--
-- TOC entry 2488 (class 1259 OID 220461)
-- Dependencies: 194 2811
-- Name: idx_134_foreign_kurstyp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_134_foreign_kurstyp_idx" ON "tblSdKvvInhaltXKurstyp" USING "btree" ("lngKurstypID");


--
-- TOC entry 2489 (class 1259 OID 220462)
-- Dependencies: 194 2811
-- Name: idx_135_foreign_kvvinhalt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_135_foreign_kvvinhalt_idx" ON "tblSdKvvInhaltXKurstyp" USING "btree" ("intKvvInhaltNr");


--
-- TOC entry 2490 (class 1259 OID 220463)
-- Dependencies: 194 2811
-- Name: idx_136_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_136_lngSeminarID" ON "tblSdKvvInhaltXKurstyp" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2493 (class 1259 OID 220464)
-- Dependencies: 195 2811
-- Name: idx_137_lngleistungsid1_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_137_lngleistungsid1_idx" ON "tblSdLeistung" USING "btree" ("lngLeistungID");


--
-- TOC entry 2494 (class 1259 OID 220465)
-- Dependencies: 195 2811
-- Name: idx_138_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_138_lngSeminarID" ON "tblSdLeistung" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2497 (class 1259 OID 220466)
-- Dependencies: 196 2811
-- Name: idx_139_lngModulID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_139_lngModulID" ON "tblSdModul" USING "btree" ("lngModulID");


--
-- TOC entry 2498 (class 1259 OID 220468)
-- Dependencies: 196 2811
-- Name: idx_140_lngModulNummer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_140_lngModulNummer" ON "tblSdModul" USING "btree" ("lngModulNummer");


--
-- TOC entry 2499 (class 1259 OID 220469)
-- Dependencies: 196 2811
-- Name: idx_141_lngSdSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_141_lngSdSeminarID" ON "tblSdModul" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2500 (class 1259 OID 220470)
-- Dependencies: 196 2811
-- Name: idx_142_tblSdSeminartblSdModul; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_142_tblSdSeminartblSdModul" ON "tblSdModul" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2503 (class 1259 OID 220471)
-- Dependencies: 197 2811
-- Name: idx_143_intKvvInhaltNr; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_143_intKvvInhaltNr" ON "tblSdModulXLeistung" USING "btree" ("lngModulID");


--
-- TOC entry 2504 (class 1259 OID 220472)
-- Dependencies: 197 2811
-- Name: idx_144_lngKurstypID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_144_lngKurstypID" ON "tblSdModulXLeistung" USING "btree" ("lngLeistungID");


--
-- TOC entry 2505 (class 1259 OID 220473)
-- Dependencies: 197 2811
-- Name: idx_145_lngSdSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_145_lngSdSeminarID" ON "tblSdModulXLeistung" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2506 (class 1259 OID 220474)
-- Dependencies: 197 197 2811
-- Name: idx_146_tblSdLeistungtblSdModul; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_146_tblSdLeistungtblSdModul" ON "tblSdModulXLeistung" USING "btree" ("lngSdSeminarID", "lngLeistungID");


--
-- TOC entry 2507 (class 1259 OID 220475)
-- Dependencies: 197 197 2811
-- Name: idx_147_tblSdModultblSdModulXKu; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_147_tblSdModultblSdModulXKu" ON "tblSdModulXLeistung" USING "btree" ("lngSdSeminarID", "lngModulID");


--
-- TOC entry 2508 (class 1259 OID 220476)
-- Dependencies: 197 2811
-- Name: idx_148_tblSdSeminartblSdModulX; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_148_tblSdSeminartblSdModulX" ON "tblSdModulXLeistung" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2511 (class 1259 OID 220477)
-- Dependencies: 198 2811
-- Name: idx_149_lngNoteID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_149_lngNoteID" ON "tblSdNote" USING "btree" ("intNoteID");


--
-- TOC entry 2512 (class 1259 OID 220479)
-- Dependencies: 198 2811
-- Name: idx_150_lngSdSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_150_lngSdSeminarID" ON "tblSdNote" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2513 (class 1259 OID 220480)
-- Dependencies: 198 2811
-- Name: idx_151_tblSdSeminartblSdNote; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_151_tblSdSeminartblSdNote" ON "tblSdNote" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2518 (class 1259 OID 220481)
-- Dependencies: 200 2811
-- Name: idx_152_{FD4127D7-5829-4399-A21; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_152_{FD4127D7-5829-4399-A21" ON "tblSdPruefung" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2519 (class 1259 OID 220482)
-- Dependencies: 200 2811
-- Name: idx_153_lngpruefungsid1_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_153_lngpruefungsid1_idx" ON "tblSdPruefung" USING "btree" ("lngPruefungID");


--
-- TOC entry 2522 (class 1259 OID 220483)
-- Dependencies: 201 2811
-- Name: idx_154_lngAblaufID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_154_lngAblaufID" ON "tblSdPruefungAblauf" USING "btree" ("lngAblaufID");


--
-- TOC entry 2523 (class 1259 OID 220484)
-- Dependencies: 201 2811
-- Name: idx_155_lngPruefungID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_155_lngPruefungID" ON "tblSdPruefungAblauf" USING "btree" ("lngPruefungID");


--
-- TOC entry 2524 (class 1259 OID 220485)
-- Dependencies: 201 201 2811
-- Name: idx_156_tblSdPruefungtblSdPruef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_156_tblSdPruefungtblSdPruef" ON "tblSdPruefungAblauf" USING "btree" ("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2527 (class 1259 OID 220486)
-- Dependencies: 202 2811
-- Name: idx_157_lngPruefungID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_157_lngPruefungID" ON "tblSdPruefungRegel" USING "btree" ("lngPruefungID");


--
-- TOC entry 2528 (class 1259 OID 220487)
-- Dependencies: 202 2811
-- Name: idx_158_lngRegelID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_158_lngRegelID" ON "tblSdPruefungRegel" USING "btree" ("lngRegelID");


--
-- TOC entry 2529 (class 1259 OID 220488)
-- Dependencies: 202 202 2811
-- Name: idx_159_tblSdPruefungtblSdPruef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_159_tblSdPruefungtblSdPruef" ON "tblSdPruefungRegel" USING "btree" ("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2532 (class 1259 OID 220490)
-- Dependencies: 203 2811
-- Name: idx_160_lngLeistungsID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_160_lngLeistungsID" ON "tblSdPruefungRegelDetail" USING "btree" ("lngLeistungsID");


--
-- TOC entry 2533 (class 1259 OID 220491)
-- Dependencies: 203 2811
-- Name: idx_161_lngModulID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_161_lngModulID" ON "tblSdPruefungRegelDetail" USING "btree" ("lngModulID");


--
-- TOC entry 2534 (class 1259 OID 220492)
-- Dependencies: 203 2811
-- Name: idx_162_lngPruefungID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_162_lngPruefungID" ON "tblSdPruefungRegelDetail" USING "btree" ("lngPruefungID");


--
-- TOC entry 2535 (class 1259 OID 220493)
-- Dependencies: 203 2811
-- Name: idx_163_lngRegelID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_163_lngRegelID" ON "tblSdPruefungRegelDetail" USING "btree" ("lngRegelID");


--
-- TOC entry 2536 (class 1259 OID 220494)
-- Dependencies: 203 203 203 2811
-- Name: idx_164_tblSdPruefungRegeltblSd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_164_tblSdPruefungRegeltblSd" ON "tblSdPruefungRegelDetail" USING "btree" ("lngSdSeminarID", "lngPruefungID", "lngRegelID");


--
-- TOC entry 2539 (class 1259 OID 220495)
-- Dependencies: 204 2811
-- Name: idx_165_intFachID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_165_intFachID" ON "tblSdPruefungXFach" USING "btree" ("intFachID");


--
-- TOC entry 2540 (class 1259 OID 220496)
-- Dependencies: 204 2811
-- Name: idx_166_lngPruefungID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_166_lngPruefungID" ON "tblSdPruefungXFach" USING "btree" ("lngPruefungID");


--
-- TOC entry 2541 (class 1259 OID 220497)
-- Dependencies: 204 2811
-- Name: idx_167_lngSdSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_167_lngSdSeminarID" ON "tblSdPruefungXFach" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2542 (class 1259 OID 220498)
-- Dependencies: 204 2811
-- Name: idx_168_tblSdFachtblSdPruefungX; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_168_tblSdFachtblSdPruefungX" ON "tblSdPruefungXFach" USING "btree" ("intFachID");


--
-- TOC entry 2543 (class 1259 OID 220499)
-- Dependencies: 204 204 2811
-- Name: idx_169_tblSdPruefungtblSdPruef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_169_tblSdPruefungtblSdPruef" ON "tblSdPruefungXFach" USING "btree" ("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2546 (class 1259 OID 220501)
-- Dependencies: 205 2811
-- Name: idx_170_lngleistungsid2_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_170_lngleistungsid2_idx" ON "tblSdPruefungXModul" USING "btree" ("lngModulID");


--
-- TOC entry 2547 (class 1259 OID 220502)
-- Dependencies: 205 2811
-- Name: idx_171_lngpruefungsid2_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_171_lngpruefungsid2_idx" ON "tblSdPruefungXModul" USING "btree" ("lngPruefungID");


--
-- TOC entry 2548 (class 1259 OID 220503)
-- Dependencies: 205 2811
-- Name: idx_172_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_172_lngSeminarID" ON "tblSdPruefungXModul" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2549 (class 1259 OID 220504)
-- Dependencies: 205 205 2811
-- Name: idx_173_tblSdModultblSdPruefung; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_173_tblSdModultblSdPruefung" ON "tblSdPruefungXModul" USING "btree" ("lngSdSeminarID", "lngModulID");


--
-- TOC entry 2550 (class 1259 OID 220505)
-- Dependencies: 205 205 2811
-- Name: idx_174_tblSdPruefungtblSdPruef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_174_tblSdPruefungtblSdPruef" ON "tblSdPruefungXModul" USING "btree" ("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2551 (class 1259 OID 220506)
-- Dependencies: 205 2811
-- Name: idx_175_tblSdSeminartblSdPruefu; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_175_tblSdSeminartblSdPruefu" ON "tblSdPruefungXModul" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2554 (class 1259 OID 220507)
-- Dependencies: 206 2811
-- Name: idx_176_lngPruefungID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_176_lngPruefungID" ON "tblSdPruefungXPruefung" USING "btree" ("lngPruefungID");


--
-- TOC entry 2555 (class 1259 OID 220508)
-- Dependencies: 206 2811
-- Name: idx_177_lngPruefungPrereqID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_177_lngPruefungPrereqID" ON "tblSdPruefungXPruefung" USING "btree" ("lngPruefungPrereqID");


--
-- TOC entry 2556 (class 1259 OID 220509)
-- Dependencies: 206 206 2811
-- Name: idx_178_tblSdPruefungtblSdPruef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_178_tblSdPruefungtblSdPruef" ON "tblSdPruefungXPruefung" USING "btree" ("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2557 (class 1259 OID 220510)
-- Dependencies: 206 206 2811
-- Name: idx_179_tblSdPruefungtblSdPruef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_179_tblSdPruefungtblSdPruef" ON "tblSdPruefungXPruefung" USING "btree" ("lngSdSeminarID", "lngPruefungPrereqID");


--
-- TOC entry 2560 (class 1259 OID 220512)
-- Dependencies: 207 2811
-- Name: idx_180_{7EFC5EE8-5CAA-4984-B4C; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_180_{7EFC5EE8-5CAA-4984-B4C" ON "tblSdRaum" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2561 (class 1259 OID 220513)
-- Dependencies: 207 2811
-- Name: idx_181_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_181_lngSeminarID" ON "tblSdRaum" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2562 (class 1259 OID 220514)
-- Dependencies: 207 2811
-- Name: idx_182_strRaumUnivISID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_182_strRaumUnivISID" ON "tblSdRaum" USING "btree" ("strRaumUnivISID");


--
-- TOC entry 2565 (class 1259 OID 220515)
-- Dependencies: 208 208 2811
-- Name: idx_185_{DE58899A-9A16-4EE5-B96; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_185_{DE58899A-9A16-4EE5-B96" ON "tblSdSeminar" USING "btree" ("lngUniID", "lngFakultaetID");


--
-- TOC entry 2566 (class 1259 OID 220516)
-- Dependencies: 208 2811
-- Name: idx_186_lngFakultaetID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_186_lngFakultaetID" ON "tblSdSeminar" USING "btree" ("lngFakultaetID");


--
-- TOC entry 2567 (class 1259 OID 220517)
-- Dependencies: 208 2811
-- Name: idx_187_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_187_lngSeminarID" ON "tblSdSeminar" USING "btree" ("lngSeminarID");


--
-- TOC entry 2568 (class 1259 OID 220518)
-- Dependencies: 208 2811
-- Name: idx_188_lngUniID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_188_lngUniID" ON "tblSdSeminar" USING "btree" ("lngUniID");


--
-- TOC entry 2569 (class 1259 OID 220519)
-- Dependencies: 208 2811
-- Name: idx_189_strSeminarUnivISID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_189_strSeminarUnivISID" ON "tblSdSeminar" USING "btree" ("strSeminarUnivISID");


--
-- TOC entry 2333 (class 1259 OID 220520)
-- Dependencies: 161 2811
-- Name: idx_18_{300EC23C-198E-48D6-B86D; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_18_{300EC23C-198E-48D6-B86D" ON "tblBdData" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2573 (class 1259 OID 220521)
-- Dependencies: 209 2811
-- Name: idx_190_intFachID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_190_intFachID" ON "tblSdSeminarXFach" USING "btree" ("intFachID");


--
-- TOC entry 2574 (class 1259 OID 220522)
-- Dependencies: 209 2811
-- Name: idx_191_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_191_lngSeminarID" ON "tblSdSeminarXFach" USING "btree" ("lngSeminarID");


--
-- TOC entry 2575 (class 1259 OID 220523)
-- Dependencies: 209 2811
-- Name: idx_192_tblSdFachtblSdSeminarXF; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_192_tblSdFachtblSdSeminarXF" ON "tblSdSeminarXFach" USING "btree" ("intFachID");


--
-- TOC entry 2576 (class 1259 OID 220524)
-- Dependencies: 209 2811
-- Name: idx_193_tblSdSeminartblSdSemina; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_193_tblSdSeminartblSdSemina" ON "tblSdSeminarXFach" USING "btree" ("lngSeminarID");


--
-- TOC entry 2334 (class 1259 OID 220528)
-- Dependencies: 161 2811
-- Name: idx_19_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_19_lngSeminarID" ON "tblBdData" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2347 (class 1259 OID 220533)
-- Dependencies: 167 167 2811
-- Name: idx_24_{9A33D994-2D49-49F3-BBA0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_24_{9A33D994-2D49-49F3-BBA0" ON "tblBdKurs" USING "btree" ("lngSdSeminarID", "strKursRaum2");


--
-- TOC entry 2348 (class 1259 OID 220534)
-- Dependencies: 167 167 2811
-- Name: idx_25_{B2907D8C-81B8-4DBD-8665; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_25_{B2907D8C-81B8-4DBD-8665" ON "tblBdKurs" USING "btree" ("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2349 (class 1259 OID 220535)
-- Dependencies: 167 167 2811
-- Name: idx_26_{F7B415C7-B1D1-4C99-B532; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_26_{F7B415C7-B1D1-4C99-B532" ON "tblBdKurs" USING "btree" ("lngSdSeminarID", "strKursRaum");


--
-- TOC entry 2350 (class 1259 OID 220536)
-- Dependencies: 167 2811
-- Name: idx_27_lngdozentid_idx_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_27_lngdozentid_idx_idx" ON "tblBdKurs" USING "btree" ("lngDozentID");


--
-- TOC entry 2351 (class 1259 OID 220537)
-- Dependencies: 167 2811
-- Name: idx_28_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_28_lngSeminarID" ON "tblBdKurs" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2352 (class 1259 OID 220538)
-- Dependencies: 167 2811
-- Name: idx_29_strUnivISID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_29_strUnivISID" ON "tblBdKurs" USING "btree" ("strKursUnivISID");


--
-- TOC entry 2357 (class 1259 OID 220539)
-- Dependencies: 169 2811
-- Name: idx_30_lngKursID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_30_lngKursID" ON "tblBdKursXKurstyp" USING "btree" ("lngKursID");


--
-- TOC entry 2358 (class 1259 OID 220540)
-- Dependencies: 169 2811
-- Name: idx_31_lngKurstypID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_31_lngKurstypID" ON "tblBdKursXKurstyp" USING "btree" ("lngKurstypID");


--
-- TOC entry 2359 (class 1259 OID 220541)
-- Dependencies: 169 2811
-- Name: idx_32_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_32_lngSeminarID" ON "tblBdKursXKurstyp" USING "btree" ("lngSeminarID");


--
-- TOC entry 2360 (class 1259 OID 220542)
-- Dependencies: 169 169 2811
-- Name: idx_33_tblBdKurstblBdKursXKurst; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_33_tblBdKurstblBdKursXKurst" ON "tblBdKursXKurstyp" USING "btree" ("lngSeminarID", "lngKursID");


--
-- TOC entry 2361 (class 1259 OID 220543)
-- Dependencies: 169 169 2811
-- Name: idx_34_tblSdKurstyptblBdKursXKu; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_34_tblSdKurstyptblBdKursXKu" ON "tblBdKursXKurstyp" USING "btree" ("lngSeminarID", "lngKurstypID");


--
-- TOC entry 2364 (class 1259 OID 220544)
-- Dependencies: 170 170 2811
-- Name: idx_35_{B0A4D71D-FDAB-4DB6-832F; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_35_{B0A4D71D-FDAB-4DB6-832F" ON "tblBdKursXLink" USING "btree" ("lngSdSeminarID", "lngKursID");


--
-- TOC entry 2365 (class 1259 OID 220545)
-- Dependencies: 170 2811
-- Name: idx_36_lngkursid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_36_lngkursid_idx" ON "tblBdKursXLink" USING "btree" ("lngKursID");


--
-- TOC entry 2366 (class 1259 OID 220546)
-- Dependencies: 170 2811
-- Name: idx_37_lnglinkid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_37_lnglinkid_idx" ON "tblBdKursXLink" USING "btree" ("lngLinkID");


--
-- TOC entry 2367 (class 1259 OID 220547)
-- Dependencies: 170 2811
-- Name: idx_38_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_38_lngSeminarID" ON "tblBdKursXLink" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2370 (class 1259 OID 220548)
-- Dependencies: 171 2811
-- Name: idx_39_{E8BA05DA-E2A0-4458-9706; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_39_{E8BA05DA-E2A0-4458-9706" ON "tblBdKvvArchiv" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2371 (class 1259 OID 220549)
-- Dependencies: 171 2811
-- Name: idx_40_lngFakultaetID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_40_lngFakultaetID" ON "tblBdKvvArchiv" USING "btree" ("lngSdFakultaetID");


--
-- TOC entry 2372 (class 1259 OID 220550)
-- Dependencies: 171 2811
-- Name: idx_41_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_41_lngSeminarID" ON "tblBdKvvArchiv" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2375 (class 1259 OID 220551)
-- Dependencies: 172 2811
-- Name: idx_42_{D3B80E22-282F-49DF-ADFD; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_42_{D3B80E22-282F-49DF-ADFD" ON "tblBdKvvArchivXLinks" USING "btree" ("lngID");


--
-- TOC entry 2376 (class 1259 OID 220552)
-- Dependencies: 172 2811
-- Name: idx_43_lngkursid1_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_43_lngkursid1_idx" ON "tblBdKvvArchivXLinks" USING "btree" ("lngID");


--
-- TOC entry 2377 (class 1259 OID 220553)
-- Dependencies: 172 2811
-- Name: idx_44_lnglinkid1_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_44_lnglinkid1_idx" ON "tblBdKvvArchivXLinks" USING "btree" ("lngLinkID");


--
-- TOC entry 2378 (class 1259 OID 220554)
-- Dependencies: 172 2811
-- Name: idx_45_tblbdkvvarchivtblbdxkvva; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_45_tblbdkvvarchivtblbdxkvva" ON "tblBdKvvArchivXLinks" USING "btree" ("lngID");


--
-- TOC entry 2381 (class 1259 OID 220555)
-- Dependencies: 173 2811
-- Name: idx_46_lngAblaufID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_46_lngAblaufID" ON "tblBdPruefungAblauf" USING "btree" ("lngAblaufID");


--
-- TOC entry 2382 (class 1259 OID 220556)
-- Dependencies: 173 2811
-- Name: idx_47_lngSdPruefungsID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_47_lngSdPruefungsID" ON "tblBdPruefungAblauf" USING "btree" ("lngSdPruefungsID");


--
-- TOC entry 2383 (class 1259 OID 220557)
-- Dependencies: 173 2811
-- Name: idx_48_lngSdSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_48_lngSdSeminarID" ON "tblBdPruefungAblauf" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2384 (class 1259 OID 220558)
-- Dependencies: 173 2811
-- Name: idx_49_strMatrikelnummer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_49_strMatrikelnummer" ON "tblBdPruefungAblauf" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2385 (class 1259 OID 220559)
-- Dependencies: 173 173 173 173 2811
-- Name: idx_50_tblBdStudentXPruefungtbl; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_50_tblBdStudentXPruefungtbl" ON "tblBdPruefungAblauf" USING "btree" ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount");


--
-- TOC entry 2386 (class 1259 OID 220560)
-- Dependencies: 173 173 173 2811
-- Name: idx_51_tblSdPruefungAblauftblBd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_51_tblSdPruefungAblauftblBd" ON "tblBdPruefungAblauf" USING "btree" ("lngSdSeminarID", "lngSdPruefungsID", "lngAblaufID");


--
-- TOC entry 2389 (class 1259 OID 220561)
-- Dependencies: 174 2811
-- Name: idx_52_{D881E80F-FEFE-46D5-856F; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_52_{D881E80F-FEFE-46D5-856F" ON "tblBdRaumplanExtern" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2390 (class 1259 OID 220562)
-- Dependencies: 174 2811
-- Name: idx_53_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_53_lngSeminarID" ON "tblBdRaumplanExtern" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2395 (class 1259 OID 220563)
-- Dependencies: 176 2811
-- Name: idx_54_mafopkey_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_54_mafopkey_idx" ON "tblBdStudent" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2396 (class 1259 OID 220564)
-- Dependencies: 176 2811
-- Name: idx_55_primarykey3_idx_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_55_primarykey3_idx_idx" ON "tblBdStudent" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2410 (class 1259 OID 220565)
-- Dependencies: 178 178 2811
-- Name: idx_57_AntragStatusDozent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_57_AntragStatusDozent" ON "tblBdStudentAntragStatus" USING "btree" ("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2344 (class 1259 OID 220566)
-- Dependencies: 165 165 2811
-- Name: idx_57_idx_fDozentXDozentBemer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_57_idx_fDozentXDozentBemer" ON "tblBdDozentBemerkung" USING "btree" ("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2413 (class 1259 OID 220567)
-- Dependencies: 181 181 2811
-- Name: idx_57_idx_fDozentXStudentBemer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_57_idx_fDozentXStudentBemer" ON "tblBdStudentBemerkung" USING "btree" ("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2397 (class 1259 OID 220568)
-- Dependencies: 176 2811
-- Name: idx_57_tblSdFachtblBdStudent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_57_tblSdFachtblBdStudent" ON "tblBdStudent" USING "btree" ("intStudentFach1");


--
-- TOC entry 2414 (class 1259 OID 220569)
-- Dependencies: 181 2811
-- Name: idx_58_idx_fStudentXStudentBeme; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_58_idx_fStudentXStudentBeme" ON "tblBdStudentBemerkung" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2398 (class 1259 OID 220571)
-- Dependencies: 176 2811
-- Name: idx_58_tblSdFachtblBdStudent1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_58_tblSdFachtblBdStudent1" ON "tblBdStudent" USING "btree" ("intStudentFach2");


--
-- TOC entry 2399 (class 1259 OID 220572)
-- Dependencies: 176 2811
-- Name: idx_59_tblSdFachtblBdStudent2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_59_tblSdFachtblBdStudent2" ON "tblBdStudent" USING "btree" ("intStudentFach3");


--
-- TOC entry 2337 (class 1259 OID 220573)
-- Dependencies: 163 2811
-- Name: idx_5_idx_Anmeldung_Matrikelnr; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_5_idx_Anmeldung_Matrikelnr" ON "tblBdAnmeldung" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2400 (class 1259 OID 220574)
-- Dependencies: 176 2811
-- Name: idx_60_tblSdFachtblBdStudent3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_60_tblSdFachtblBdStudent3" ON "tblBdStudent" USING "btree" ("intStudentFach4");


--
-- TOC entry 2401 (class 1259 OID 220575)
-- Dependencies: 176 2811
-- Name: idx_61_tblSdFachtblBdStudent4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_61_tblSdFachtblBdStudent4" ON "tblBdStudent" USING "btree" ("intStudentFach5");


--
-- TOC entry 2402 (class 1259 OID 220576)
-- Dependencies: 176 2811
-- Name: idx_62_tblSdFachtblBdStudent5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_62_tblSdFachtblBdStudent5" ON "tblBdStudent" USING "btree" ("intStudentFach6");


--
-- TOC entry 2419 (class 1259 OID 220577)
-- Dependencies: 183 2811
-- Name: idx_63_lngLeistungsID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_63_lngLeistungsID" ON "tblBdStudentPruefungDetail" USING "btree" ("lngLeistungsID");


--
-- TOC entry 2420 (class 1259 OID 220578)
-- Dependencies: 183 2811
-- Name: idx_64_lngModulID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_64_lngModulID" ON "tblBdStudentPruefungDetail" USING "btree" ("lngModulID");


--
-- TOC entry 2421 (class 1259 OID 220579)
-- Dependencies: 183 2811
-- Name: idx_65_lngSdPruefungsID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_65_lngSdPruefungsID" ON "tblBdStudentPruefungDetail" USING "btree" ("lngSdPruefungsID");


--
-- TOC entry 2422 (class 1259 OID 220580)
-- Dependencies: 183 2811
-- Name: idx_66_lngSdSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_66_lngSdSeminarID" ON "tblBdStudentPruefungDetail" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2423 (class 1259 OID 220581)
-- Dependencies: 183 2811
-- Name: idx_67_strMatrikelnummer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_67_strMatrikelnummer" ON "tblBdStudentPruefungDetail" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2424 (class 1259 OID 220582)
-- Dependencies: 183 183 183 183 2811
-- Name: idx_68_tblBdStudentXLeistungtbl; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_68_tblBdStudentXLeistungtbl" ON "tblBdStudentPruefungDetail" USING "btree" ("lngSdSeminarID", "strMatrikelnummer", "lngLeistungsID", "lngStudentLeistungCount");


--
-- TOC entry 2425 (class 1259 OID 220583)
-- Dependencies: 183 183 183 183 2811
-- Name: idx_69_tblBdStudentXPruefungtbl; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_69_tblBdStudentXPruefungtbl" ON "tblBdStudentPruefungDetail" USING "btree" ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount");


--
-- TOC entry 2338 (class 1259 OID 220584)
-- Dependencies: 163 163 163 2811
-- Name: idx_6_idx_fAnmeldung_KursXKurst; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_6_idx_fAnmeldung_KursXKurst" ON "tblBdAnmeldung" USING "btree" ("lngSdSeminarID", "lngKursID", "lngKurstypID");


--
-- TOC entry 2426 (class 1259 OID 220586)
-- Dependencies: 183 183 183 2811
-- Name: idx_70_tblSdPruefungXModultblBd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_70_tblSdPruefungXModultblBd" ON "tblBdStudentPruefungDetail" USING "btree" ("lngSdSeminarID", "lngSdPruefungsID", "lngModulID");


--
-- TOC entry 2427 (class 1259 OID 220587)
-- Dependencies: 183 2811
-- Name: idx_71_tblSdSeminartblBdStudent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_71_tblSdSeminartblBdStudent" ON "tblBdStudentPruefungDetail" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2431 (class 1259 OID 220589)
-- Dependencies: 184 184 2811
-- Name: idx_72_{2080F3A0-03C1-40D1-9B22; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_72_{2080F3A0-03C1-40D1-9B22" ON "tblBdStudentXLeistung" USING "btree" ("lngSdSeminarID", "lngLeistungsID");


--
-- TOC entry 2432 (class 1259 OID 220591)
-- Dependencies: 184 2811
-- Name: idx_73_{3F28E65E-47BE-4BFE-AE99; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_73_{3F28E65E-47BE-4BFE-AE99" ON "tblBdStudentXLeistung" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2433 (class 1259 OID 220592)
-- Dependencies: 184 2811
-- Name: idx_74_intNoteID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_74_intNoteID" ON "tblBdStudentXLeistung" USING "btree" ("intNoteID");


--
-- TOC entry 2434 (class 1259 OID 220595)
-- Dependencies: 184 2811
-- Name: idx_75_lngKlausuranmeldungKursI; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_75_lngKlausuranmeldungKursI" ON "tblBdStudentXLeistung" USING "btree" ("lngKlausuranmeldungKursID");


--
-- TOC entry 2435 (class 1259 OID 220597)
-- Dependencies: 184 2811
-- Name: idx_76_lngKlausuranmeldungKurst; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_76_lngKlausuranmeldungKurst" ON "tblBdStudentXLeistung" USING "btree" ("lngKlausuranmeldungKurstypID");


--
-- TOC entry 2436 (class 1259 OID 220599)
-- Dependencies: 184 2811
-- Name: idx_77_lngleistungsid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_77_lngleistungsid_idx" ON "tblBdStudentXLeistung" USING "btree" ("lngLeistungsID");


--
-- TOC entry 2437 (class 1259 OID 220600)
-- Dependencies: 184 2811
-- Name: idx_78_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_78_lngSeminarID" ON "tblBdStudentXLeistung" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2438 (class 1259 OID 220604)
-- Dependencies: 184 2811
-- Name: idx_79_lngStudentLeistungDozent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_79_lngStudentLeistungDozent" ON "tblBdStudentXLeistung" USING "btree" ("lngDozentID");


--
-- TOC entry 2339 (class 1259 OID 220605)
-- Dependencies: 163 2811
-- Name: idx_7_idx_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_7_idx_lngSeminarID" ON "tblBdAnmeldung" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2439 (class 1259 OID 220608)
-- Dependencies: 184 2811
-- Name: idx_80_strmatrikelnummer_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_80_strmatrikelnummer_idx" ON "tblBdStudentXLeistung" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2440 (class 1259 OID 220613)
-- Dependencies: 184 184 2811
-- Name: idx_81_tblSdDozenttblBdStudentX; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_81_tblSdDozenttblBdStudentX" ON "tblBdStudentXLeistung" USING "btree" ("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2441 (class 1259 OID 220615)
-- Dependencies: 184 184 2811
-- Name: idx_82_tblSdNotetblBdStudentXLe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_82_tblSdNotetblBdStudentXLe" ON "tblBdStudentXLeistung" USING "btree" ("lngSdSeminarID", "intNoteID");


--
-- TOC entry 2444 (class 1259 OID 220616)
-- Dependencies: 185 2811
-- Name: idx_83_{7E0C8C71-8D12-446B-B6F3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_83_{7E0C8C71-8D12-446B-B6F3" ON "tblBdStudentXPruefung" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2445 (class 1259 OID 220619)
-- Dependencies: 185 185 2811
-- Name: idx_84_{B6032CFB-A2D5-45B0-B0DE; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_84_{B6032CFB-A2D5-45B0-B0DE" ON "tblBdStudentXPruefung" USING "btree" ("lngSdSeminarID", "lngSdPruefungsID");


--
-- TOC entry 2446 (class 1259 OID 220621)
-- Dependencies: 185 2811
-- Name: idx_85_intNoteID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_85_intNoteID" ON "tblBdStudentXPruefung" USING "btree" ("intNoteID");


--
-- TOC entry 2447 (class 1259 OID 220623)
-- Dependencies: 185 2811
-- Name: idx_86_lngpruefungsid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_86_lngpruefungsid_idx" ON "tblBdStudentXPruefung" USING "btree" ("lngSdPruefungsID");


--
-- TOC entry 2448 (class 1259 OID 220624)
-- Dependencies: 185 2811
-- Name: idx_87_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_87_lngSeminarID" ON "tblBdStudentXPruefung" USING "btree" ("lngSdSeminarID");


--
-- TOC entry 2449 (class 1259 OID 220625)
-- Dependencies: 185 2811
-- Name: idx_88_strmatrikelnummer1_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_88_strmatrikelnummer1_idx" ON "tblBdStudentXPruefung" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2450 (class 1259 OID 220627)
-- Dependencies: 185 185 2811
-- Name: idx_89_tblSdNotetblBdStudentXPr; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_89_tblSdNotetblBdStudentXPr" ON "tblBdStudentXPruefung" USING "btree" ("lngSdSeminarID", "intNoteID");


--
-- TOC entry 2453 (class 1259 OID 220629)
-- Dependencies: 186 2811
-- Name: idx_90_{CC61F9DA-E247-49C5-8866; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_90_{CC61F9DA-E247-49C5-8866" ON "tblBdTermin" USING "btree" ("lngSeminarID");


--
-- TOC entry 2454 (class 1259 OID 220630)
-- Dependencies: 186 2811
-- Name: idx_91_lngSeminarID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_91_lngSeminarID" ON "tblBdTermin" USING "btree" ("lngSeminarID");


--
-- TOC entry 2405 (class 1259 OID 220637)
-- Dependencies: 177 2811
-- Name: idx_Antrag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_Antrag" ON "tblBdStudentAntrag" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2406 (class 1259 OID 220638)
-- Dependencies: 177 2811
-- Name: idx_AntragStatus; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_AntragStatus" ON "tblBdStudentAntrag" USING "btree" ("strMatrikelnummer");


--
-- TOC entry 2407 (class 1259 OID 220639)
-- Dependencies: 177 177 177 2811
-- Name: idx_AntragStatus2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_AntragStatus2" ON "tblBdStudentAntrag" USING "btree" ("lngSdSeminarID", "strMatrikelnummer", "lngStudentAntragID");


--
-- TOC entry 2570 (class 1259 OID 220652)
-- Dependencies: 208 2811
-- Name: idx_n1_strSeminarShort; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_n1_strSeminarShort" ON "tblSdSeminar" USING "btree" ("strSeminarShort");


--
-- TOC entry 2657 (class 2620 OID 220653)
-- Dependencies: 238 184 2811
-- Name: pruefung_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "pruefung_trigger" AFTER INSERT ON "tblBdStudentXLeistung" FOR EACH ROW EXECUTE PROCEDURE "triggerpruefungonleistungadd"();


--
-- TOC entry 2656 (class 2620 OID 220654)
-- Dependencies: 168 237 2811
-- Name: trigger_check_raumbuchung; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_check_raumbuchung" BEFORE INSERT OR UPDATE ON "tblBdKursTermin" FOR EACH ROW EXECUTE PROCEDURE "trigger_check_raumbuchung"();


--
-- TOC entry 2591 (class 2606 OID 220660)
-- Dependencies: 2563 168 207 207 168 2811
-- Name: raum_kurstermin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursTermin"
    ADD CONSTRAINT "raum_kurstermin" FOREIGN KEY ("lngSdSeminarID", "strRaumBezeichnung") REFERENCES "tblSdRaum"("lngSdSeminarID", "strRaumBezeichnung");


--
-- TOC entry 2622 (class 2606 OID 220670)
-- Dependencies: 2509 197 184 184 197 184 197 2811
-- Name: rel6-19ModulXLeistung-StudentXLeistung; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXLeistung"
    ADD CONSTRAINT "rel6-19ModulXLeistung-StudentXLeistung" FOREIGN KEY ("lngSdSeminarID", "lngLeistungsID", "lngModulID") REFERENCES "tblSdModulXLeistung"("lngSdSeminarID", "lngLeistungID", "lngModulID");


--
-- TOC entry 2612 (class 2606 OID 220675)
-- Dependencies: 178 178 2408 177 177 177 178 2811
-- Name: rel_Antrag_X_AntragStatus; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentAntragStatus"
    ADD CONSTRAINT "rel_Antrag_X_AntragStatus" FOREIGN KEY ("lngSdSeminarID", "strMatrikelnummer", "lngStudentAntragID") REFERENCES "tblBdStudentAntrag"("lngSdSeminarID", "strMatrikelnummer", "lngStudentAntragID");


--
-- TOC entry 2611 (class 2606 OID 220680)
-- Dependencies: 2395 177 176 2811
-- Name: rel_Antrag_X_Student; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentAntrag"
    ADD CONSTRAINT "rel_Antrag_X_Student" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2613 (class 2606 OID 220685)
-- Dependencies: 2395 178 176 2811
-- Name: rel_Antrag_X_Student; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentAntragStatus"
    ADD CONSTRAINT "rel_Antrag_X_Student" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2617 (class 2606 OID 220690)
-- Dependencies: 176 2395 182 2811
-- Name: rel_Antrag_X_Student; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentDokument"
    ADD CONSTRAINT "rel_Antrag_X_Student" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2584 (class 2606 OID 220695)
-- Dependencies: 2362 164 164 169 169 169 164 2811
-- Name: rel_KursXKurstypXAnmeldungSwap; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdAnmeldungSwap"
    ADD CONSTRAINT "rel_KursXKurstypXAnmeldungSwap" FOREIGN KEY ("lngSdSeminarID", "lngKursID", "lngKurstypID") REFERENCES "tblBdKursXKurstyp"("lngSeminarID", "lngKursID", "lngKurstypID");


--
-- TOC entry 2585 (class 2606 OID 220700)
-- Dependencies: 2362 164 164 169 169 169 164 2811
-- Name: rel_KursXKurstypXAnmeldungSwap2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdAnmeldungSwap"
    ADD CONSTRAINT "rel_KursXKurstypXAnmeldungSwap2" FOREIGN KEY ("lngSdSeminarID", "lngKursIDWunsch", "lngKurstypIDWunsch") REFERENCES "tblBdKursXKurstyp"("lngSeminarID", "lngKursID", "lngKurstypID");


--
-- TOC entry 2586 (class 2606 OID 220710)
-- Dependencies: 164 176 2395 2811
-- Name: rel_StudentXAnmeldungSwap; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdAnmeldungSwap"
    ADD CONSTRAINT "rel_StudentXAnmeldungSwap" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2587 (class 2606 OID 220730)
-- Dependencies: 165 2466 165 189 189 2811
-- Name: rel_rel_DozentXDozentBemerkung; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdDozentBemerkung"
    ADD CONSTRAINT "rel_rel_DozentXDozentBemerkung" FOREIGN KEY ("lngSdSeminarID", "lngDozentID") REFERENCES "tblSdDozent"("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2615 (class 2606 OID 220735)
-- Dependencies: 181 2466 189 189 181 2811
-- Name: rel_rel_DozentXStudentBemerkung; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentBemerkung"
    ADD CONSTRAINT "rel_rel_DozentXStudentBemerkung" FOREIGN KEY ("lngSdSeminarID", "lngDozentID") REFERENCES "tblSdDozent"("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2614 (class 2606 OID 220740)
-- Dependencies: 178 2466 189 189 178 2811
-- Name: rel_rel_DozentXStudentBemerkung; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentAntragStatus"
    ADD CONSTRAINT "rel_rel_DozentXStudentBemerkung" FOREIGN KEY ("lngSdSeminarID", "lngDozentID") REFERENCES "tblSdDozent"("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2582 (class 2606 OID 220745)
-- Dependencies: 163 163 163 169 169 169 2362 2811
-- Name: rel_rel_KursXKurstypXAnmeldung; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdAnmeldung"
    ADD CONSTRAINT "rel_rel_KursXKurstypXAnmeldung" FOREIGN KEY ("lngSdSeminarID", "lngKursID", "lngKurstypID") REFERENCES "tblBdKursXKurstyp"("lngSeminarID", "lngKursID", "lngKurstypID");


--
-- TOC entry 2583 (class 2606 OID 220750)
-- Dependencies: 2395 163 176 2811
-- Name: rel_rel_StudentXAnmeldung; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdAnmeldung"
    ADD CONSTRAINT "rel_rel_StudentXAnmeldung" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2616 (class 2606 OID 220755)
-- Dependencies: 2395 181 176 2811
-- Name: rel_rel_StudentXStudentBemerkun; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentBemerkung"
    ADD CONSTRAINT "rel_rel_StudentXStudentBemerkun" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2593 (class 2606 OID 220770)
-- Dependencies: 167 169 169 167 2353 2811
-- Name: rel_tblBdKurstblBdKursXKurstyp; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursXKurstyp"
    ADD CONSTRAINT "rel_tblBdKurstblBdKursXKurstyp" FOREIGN KEY ("lngSeminarID", "lngKursID") REFERENCES "tblBdKurs"("lngSdSeminarID", "lngKursID");


--
-- TOC entry 2618 (class 2606 OID 220775)
-- Dependencies: 183 183 183 183 184 184 184 2442 184 2811
-- Name: rel_tblBdStudentXLeistungtblBdS; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentPruefungDetail"
    ADD CONSTRAINT "rel_tblBdStudentXLeistungtblBdS" FOREIGN KEY ("lngSdSeminarID", "strMatrikelnummer", "lngLeistungsID", "lngStudentLeistungCount") REFERENCES "tblBdStudentXLeistung"("lngSdSeminarID", "strMatrikelnummer", "lngLeistungsID", "lngStudentLeistungCount");


--
-- TOC entry 2598 (class 2606 OID 220785)
-- Dependencies: 185 185 185 185 173 2451 173 173 173 2811
-- Name: rel_tblBdStudentXPruefungtblBdP; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdPruefungAblauf"
    ADD CONSTRAINT "rel_tblBdStudentXPruefungtblBdP" FOREIGN KEY ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount") REFERENCES "tblBdStudentXPruefung"("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount");


--
-- TOC entry 2619 (class 2606 OID 220790)
-- Dependencies: 185 183 183 183 183 185 2451 185 185 2811
-- Name: rel_tblBdStudentXPruefungtblBdS; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentPruefungDetail"
    ADD CONSTRAINT "rel_tblBdStudentXPruefungtblBdS" FOREIGN KEY ("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount") REFERENCES "tblBdStudentXPruefung"("lngSdSeminarID", "lngSdPruefungsID", "strMatrikelnummer", "intStudentPruefungCount");


--
-- TOC entry 2623 (class 2606 OID 220820)
-- Dependencies: 2466 189 189 184 184 2811
-- Name: rel_tblSdDozenttblBdStudentXLei; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXLeistung"
    ADD CONSTRAINT "rel_tblSdDozenttblBdStudentXLei" FOREIGN KEY ("lngSdSeminarID", "lngDozentID") REFERENCES "tblSdDozent"("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2605 (class 2606 OID 220825)
-- Dependencies: 2468 190 176 2811
-- Name: rel_tblSdFachtblBdStudent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudent"
    ADD CONSTRAINT "rel_tblSdFachtblBdStudent" FOREIGN KEY ("intStudentFach1") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2606 (class 2606 OID 220830)
-- Dependencies: 2468 176 190 2811
-- Name: rel_tblSdFachtblBdStudent1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudent"
    ADD CONSTRAINT "rel_tblSdFachtblBdStudent1" FOREIGN KEY ("intStudentFach2") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2607 (class 2606 OID 220835)
-- Dependencies: 190 176 2468 2811
-- Name: rel_tblSdFachtblBdStudent2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudent"
    ADD CONSTRAINT "rel_tblSdFachtblBdStudent2" FOREIGN KEY ("intStudentFach3") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2608 (class 2606 OID 220840)
-- Dependencies: 176 2468 190 2811
-- Name: rel_tblSdFachtblBdStudent3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudent"
    ADD CONSTRAINT "rel_tblSdFachtblBdStudent3" FOREIGN KEY ("intStudentFach4") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2609 (class 2606 OID 220845)
-- Dependencies: 2468 190 176 2811
-- Name: rel_tblSdFachtblBdStudent4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudent"
    ADD CONSTRAINT "rel_tblSdFachtblBdStudent4" FOREIGN KEY ("intStudentFach5") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2610 (class 2606 OID 220850)
-- Dependencies: 176 2468 190 2811
-- Name: rel_tblSdFachtblBdStudent5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudent"
    ADD CONSTRAINT "rel_tblSdFachtblBdStudent5" FOREIGN KEY ("intStudentFach6") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2646 (class 2606 OID 220855)
-- Dependencies: 190 2468 204 2811
-- Name: rel_tblSdFachtblSdPruefungXFach; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXFach"
    ADD CONSTRAINT "rel_tblSdFachtblSdPruefungXFach" FOREIGN KEY ("intFachID") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2654 (class 2606 OID 220860)
-- Dependencies: 190 2468 209 2811
-- Name: rel_tblSdFachtblSdSeminarXFach; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdSeminarXFach"
    ADD CONSTRAINT "rel_tblSdFachtblSdSeminarXFach" FOREIGN KEY ("intFachID") REFERENCES "tblSdFach"("intFachID");


--
-- TOC entry 2594 (class 2606 OID 220870)
-- Dependencies: 192 2480 192 169 169 2811
-- Name: rel_tblSdKurstyptblBdKursXKurst; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursXKurstyp"
    ADD CONSTRAINT "rel_tblSdKurstyptblBdKursXKurst" FOREIGN KEY ("lngSeminarID", "lngKurstypID") REFERENCES "tblSdKurstyp"("lngSdSeminarID", "lngKurstypID");


--
-- TOC entry 2633 (class 2606 OID 220875)
-- Dependencies: 195 192 192 195 2495 2811
-- Name: rel_tblSdLeistungtblSdKurstyp; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdKurstyp"
    ADD CONSTRAINT "rel_tblSdLeistungtblSdKurstyp" FOREIGN KEY ("lngSdSeminarID", "lngKurstypLeistungsID") REFERENCES "tblSdLeistung"("lngSdSeminarID", "lngLeistungID");


--
-- TOC entry 2638 (class 2606 OID 220880)
-- Dependencies: 197 197 195 195 2495 2811
-- Name: rel_tblSdLeistungtblSdModulXLei; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdModulXLeistung"
    ADD CONSTRAINT "rel_tblSdLeistungtblSdModulXLei" FOREIGN KEY ("lngSdSeminarID", "lngLeistungID") REFERENCES "tblSdLeistung"("lngSdSeminarID", "lngLeistungID");


--
-- TOC entry 2639 (class 2606 OID 220885)
-- Dependencies: 197 2501 196 196 197 2811
-- Name: rel_tblSdModultblSdModulXKursty; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdModulXLeistung"
    ADD CONSTRAINT "rel_tblSdModultblSdModulXKursty" FOREIGN KEY ("lngSdSeminarID", "lngModulID") REFERENCES "tblSdModul"("lngSdSeminarID", "lngModulID");


--
-- TOC entry 2648 (class 2606 OID 220890)
-- Dependencies: 196 196 205 205 2501 2811
-- Name: rel_tblSdModultblSdPruefungXMod; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXModul"
    ADD CONSTRAINT "rel_tblSdModultblSdPruefungXMod" FOREIGN KEY ("lngSdSeminarID", "lngModulID") REFERENCES "tblSdModul"("lngSdSeminarID", "lngModulID");


--
-- TOC entry 2624 (class 2606 OID 220900)
-- Dependencies: 184 184 198 198 2514 2811
-- Name: rel_tblSdNotetblBdStudentXLeist; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXLeistung"
    ADD CONSTRAINT "rel_tblSdNotetblBdStudentXLeist" FOREIGN KEY ("lngSdSeminarID", "intNoteID") REFERENCES "tblSdNote"("lngSdSeminarID", "intNoteID");


--
-- TOC entry 2627 (class 2606 OID 220905)
-- Dependencies: 198 2514 185 185 198 2811
-- Name: rel_tblSdNotetblBdStudentXPruef; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXPruefung"
    ADD CONSTRAINT "rel_tblSdNotetblBdStudentXPruef" FOREIGN KEY ("lngSdSeminarID", "intNoteID") REFERENCES "tblSdNote"("lngSdSeminarID", "intNoteID");


--
-- TOC entry 2599 (class 2606 OID 220910)
-- Dependencies: 173 2525 201 201 201 173 173 2811
-- Name: rel_tblSdPruefungAblauftblBdPru; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdPruefungAblauf"
    ADD CONSTRAINT "rel_tblSdPruefungAblauftblBdPru" FOREIGN KEY ("lngSdSeminarID", "lngSdPruefungsID", "lngAblaufID") REFERENCES "tblSdPruefungAblauf"("lngSdSeminarID", "lngPruefungID", "lngAblaufID");


--
-- TOC entry 2645 (class 2606 OID 220915)
-- Dependencies: 2530 203 203 203 202 202 202 2811
-- Name: rel_tblSdPruefungRegeltblSdPrue; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungRegelDetail"
    ADD CONSTRAINT "rel_tblSdPruefungRegeltblSdPrue" FOREIGN KEY ("lngSdSeminarID", "lngPruefungID", "lngRegelID") REFERENCES "tblSdPruefungRegel"("lngSdSeminarID", "lngPruefungID", "lngRegelID");


--
-- TOC entry 2620 (class 2606 OID 220920)
-- Dependencies: 205 183 183 183 205 205 2552 2811
-- Name: rel_tblSdPruefungXModultblBdStu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentPruefungDetail"
    ADD CONSTRAINT "rel_tblSdPruefungXModultblBdStu" FOREIGN KEY ("lngSdSeminarID", "lngSdPruefungsID", "lngModulID") REFERENCES "tblSdPruefungXModul"("lngSdSeminarID", "lngPruefungID", "lngModulID");


--
-- TOC entry 2643 (class 2606 OID 220925)
-- Dependencies: 2520 200 200 201 201 2811
-- Name: rel_tblSdPruefungtblSdPruefungA; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungAblauf"
    ADD CONSTRAINT "rel_tblSdPruefungtblSdPruefungA" FOREIGN KEY ("lngSdSeminarID", "lngPruefungID") REFERENCES "tblSdPruefung"("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2644 (class 2606 OID 220930)
-- Dependencies: 202 2520 200 200 202 2811
-- Name: rel_tblSdPruefungtblSdPruefungR; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungRegel"
    ADD CONSTRAINT "rel_tblSdPruefungtblSdPruefungR" FOREIGN KEY ("lngSdSeminarID", "lngPruefungID") REFERENCES "tblSdPruefung"("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2647 (class 2606 OID 220935)
-- Dependencies: 200 2520 204 204 200 2811
-- Name: rel_tblSdPruefungtblSdPruefungX; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXFach"
    ADD CONSTRAINT "rel_tblSdPruefungtblSdPruefungX" FOREIGN KEY ("lngSdSeminarID", "lngPruefungID") REFERENCES "tblSdPruefung"("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2649 (class 2606 OID 220940)
-- Dependencies: 200 205 2520 200 205 2811
-- Name: rel_tblSdPruefungtblSdPruefungX; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXModul"
    ADD CONSTRAINT "rel_tblSdPruefungtblSdPruefungX" FOREIGN KEY ("lngSdSeminarID", "lngPruefungID") REFERENCES "tblSdPruefung"("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2651 (class 2606 OID 220945)
-- Dependencies: 2520 206 200 200 206 2811
-- Name: rel_tblSdPruefungtblSdPruefungX; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXPruefung"
    ADD CONSTRAINT "rel_tblSdPruefungtblSdPruefungX" FOREIGN KEY ("lngSdSeminarID", "lngPruefungID") REFERENCES "tblSdPruefung"("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2621 (class 2606 OID 220950)
-- Dependencies: 2567 208 183 2811
-- Name: rel_tblSdSeminartblBdStudentPru; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentPruefungDetail"
    ADD CONSTRAINT "rel_tblSdSeminartblBdStudentPru" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2637 (class 2606 OID 220960)
-- Dependencies: 2567 208 196 2811
-- Name: rel_tblSdSeminartblSdModul; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdModul"
    ADD CONSTRAINT "rel_tblSdSeminartblSdModul" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2640 (class 2606 OID 220965)
-- Dependencies: 2567 208 197 2811
-- Name: rel_tblSdSeminartblSdModulXLeis; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdModulXLeistung"
    ADD CONSTRAINT "rel_tblSdSeminartblSdModulXLeis" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2641 (class 2606 OID 220970)
-- Dependencies: 198 208 2567 2811
-- Name: rel_tblSdSeminartblSdNote; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdNote"
    ADD CONSTRAINT "rel_tblSdSeminartblSdNote" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2650 (class 2606 OID 220975)
-- Dependencies: 2567 205 208 2811
-- Name: rel_tblSdSeminartblSdPruefungXM; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefungXModul"
    ADD CONSTRAINT "rel_tblSdSeminartblSdPruefungXM" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2655 (class 2606 OID 220980)
-- Dependencies: 208 209 2567 2811
-- Name: rel_tblSdSeminartblSdSeminarXFa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdSeminarXFach"
    ADD CONSTRAINT "rel_tblSdSeminartblSdSeminarXFa" FOREIGN KEY ("lngSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2601 (class 2606 OID 220995)
-- Dependencies: 175 199 2516 2811
-- Name: rel_tblsprechstunde_Nutzer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdSprechstunde"
    ADD CONSTRAINT "rel_tblsprechstunde_Nutzer" FOREIGN KEY ("strNutzerUniID") REFERENCES "tblSdNutzer"("strNutzerUniID");


--
-- TOC entry 2602 (class 2606 OID 221000)
-- Dependencies: 2567 175 208 2811
-- Name: rel_tblsprechstunde_Seminar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdSprechstunde"
    ADD CONSTRAINT "rel_tblsprechstunde_Seminar" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2603 (class 2606 OID 221005)
-- Dependencies: 176 2395 175 2811
-- Name: rel_tblsprechstunde_Student; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdSprechstunde"
    ADD CONSTRAINT "rel_tblsprechstunde_Student" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2604 (class 2606 OID 221010)
-- Dependencies: 189 175 2466 175 189 2811
-- Name: rel_tbltermin_Dozent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdSprechstunde"
    ADD CONSTRAINT "rel_tbltermin_Dozent" FOREIGN KEY ("lngSdSeminarID", "lngDozentID") REFERENCES "tblSdDozent"("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2635 (class 2606 OID 221015)
-- Dependencies: 192 194 194 2480 192 2811
-- Name: rel_{0903AB7C-45D9-4733-898B-1E; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdKvvInhaltXKurstyp"
    ADD CONSTRAINT "rel_{0903AB7C-45D9-4733-898B-1E" FOREIGN KEY ("lngSdSeminarID", "lngKurstypID") REFERENCES "tblSdKurstyp"("lngSdSeminarID", "lngKurstypID");


--
-- TOC entry 2625 (class 2606 OID 221020)
-- Dependencies: 2495 184 195 195 184 2811
-- Name: rel_{2080F3A0-03C1-40D1-9B22-37; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXLeistung"
    ADD CONSTRAINT "rel_{2080F3A0-03C1-40D1-9B22-37" FOREIGN KEY ("lngSdSeminarID", "lngLeistungsID") REFERENCES "tblSdLeistung"("lngSdSeminarID", "lngLeistungID");


--
-- TOC entry 2581 (class 2606 OID 221035)
-- Dependencies: 161 2567 208 2811
-- Name: rel_{300EC23C-198E-48D6-B86D-68; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdData"
    ADD CONSTRAINT "rel_{300EC23C-198E-48D6-B86D-68" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2626 (class 2606 OID 221050)
-- Dependencies: 184 176 2395 2811
-- Name: rel_{3F28E65E-47BE-4BFE-AE99-F6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXLeistung"
    ADD CONSTRAINT "rel_{3F28E65E-47BE-4BFE-AE99-F6" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2634 (class 2606 OID 221060)
-- Dependencies: 208 193 2567 2811
-- Name: rel_{40D0FEF4-7337-4E56-B05C-67; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdKvvInhalt"
    ADD CONSTRAINT "rel_{40D0FEF4-7337-4E56-B05C-67" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2632 (class 2606 OID 221075)
-- Dependencies: 191 2579 210 2811
-- Name: rel_{7311B5D6-7C0E-413A-9255-C8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdFakultaet"
    ADD CONSTRAINT "rel_{7311B5D6-7C0E-413A-9255-C8" FOREIGN KEY ("lngSdUniID") REFERENCES "tblSdUni"("lngSdUniID");


--
-- TOC entry 2628 (class 2606 OID 221090)
-- Dependencies: 2395 176 185 2811
-- Name: rel_{7E0C8C71-8D12-446B-B6F3-64; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXPruefung"
    ADD CONSTRAINT "rel_{7E0C8C71-8D12-446B-B6F3-64" FOREIGN KEY ("strMatrikelnummer") REFERENCES "tblBdStudent"("strMatrikelnummer");


--
-- TOC entry 2652 (class 2606 OID 221095)
-- Dependencies: 2567 208 207 2811
-- Name: rel_{7EFC5EE8-5CAA-4984-B4C1-32; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdRaum"
    ADD CONSTRAINT "rel_{7EFC5EE8-5CAA-4984-B4C1-32" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2588 (class 2606 OID 221110)
-- Dependencies: 167 207 2563 207 167 2811
-- Name: rel_{9A33D994-2D49-49F3-BBA0-13; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKurs"
    ADD CONSTRAINT "rel_{9A33D994-2D49-49F3-BBA0-13" FOREIGN KEY ("lngSdSeminarID", "strKursRaum2") REFERENCES "tblSdRaum"("lngSdSeminarID", "strRaumBezeichnung");


--
-- TOC entry 2595 (class 2606 OID 221120)
-- Dependencies: 170 170 167 167 2353 2811
-- Name: rel_{B0A4D71D-FDAB-4DB6-832F-EC; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursXLink"
    ADD CONSTRAINT "rel_{B0A4D71D-FDAB-4DB6-832F-EC" FOREIGN KEY ("lngSdSeminarID", "lngKursID") REFERENCES "tblBdKurs"("lngSdSeminarID", "lngKursID");


--
-- TOC entry 2589 (class 2606 OID 221125)
-- Dependencies: 189 2466 189 167 167 2811
-- Name: rel_{B2907D8C-81B8-4DBD-8665-13; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKurs"
    ADD CONSTRAINT "rel_{B2907D8C-81B8-4DBD-8665-13" FOREIGN KEY ("lngSdSeminarID", "lngDozentID") REFERENCES "tblSdDozent"("lngSdSeminarID", "lngDozentID");


--
-- TOC entry 2629 (class 2606 OID 221130)
-- Dependencies: 185 2520 200 200 185 2811
-- Name: rel_{B6032CFB-A2D5-45B0-B0DE-31; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdStudentXPruefung"
    ADD CONSTRAINT "rel_{B6032CFB-A2D5-45B0-B0DE-31" FOREIGN KEY ("lngSdSeminarID", "lngSdPruefungsID") REFERENCES "tblSdPruefung"("lngSdSeminarID", "lngPruefungID");


--
-- TOC entry 2636 (class 2606 OID 221140)
-- Dependencies: 194 2484 193 193 194 2811
-- Name: rel_{C3341EEC-A435-4C27-814A-F4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdKvvInhaltXKurstyp"
    ADD CONSTRAINT "rel_{C3341EEC-A435-4C27-814A-F4" FOREIGN KEY ("lngSdSeminarID", "intKvvInhaltNr") REFERENCES "tblSdKvvInhalt"("lngSdSeminarID", "intSdKvvInhaltNr");


--
-- TOC entry 2631 (class 2606 OID 221150)
-- Dependencies: 208 189 2567 2811
-- Name: rel_{C7C513FD-304D-4BA9-9007-D6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdDozent"
    ADD CONSTRAINT "rel_{C7C513FD-304D-4BA9-9007-D6" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2630 (class 2606 OID 221155)
-- Dependencies: 2567 208 186 2811
-- Name: rel_{CC61F9DA-E247-49C5-8866-31; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdTermin"
    ADD CONSTRAINT "rel_{CC61F9DA-E247-49C5-8866-31" FOREIGN KEY ("lngSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2597 (class 2606 OID 221170)
-- Dependencies: 2373 172 171 2811
-- Name: rel_{D3B80E22-282F-49DF-ADFD-08; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKvvArchivXLinks"
    ADD CONSTRAINT "rel_{D3B80E22-282F-49DF-ADFD-08" FOREIGN KEY ("lngID") REFERENCES "tblBdKvvArchiv"("lngID");


--
-- TOC entry 2600 (class 2606 OID 221175)
-- Dependencies: 208 174 2567 2811
-- Name: rel_{D881E80F-FEFE-46D5-856F-4F; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdRaumplanExtern"
    ADD CONSTRAINT "rel_{D881E80F-FEFE-46D5-856F-4F" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2653 (class 2606 OID 221180)
-- Dependencies: 2474 208 208 191 191 2811
-- Name: rel_{DE58899A-9A16-4EE5-B96D-5A; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdSeminar"
    ADD CONSTRAINT "rel_{DE58899A-9A16-4EE5-B96D-5A" FOREIGN KEY ("lngUniID", "lngFakultaetID") REFERENCES "tblSdFakultaet"("lngSdUniID", "lngSdFakultaetID");


--
-- TOC entry 2596 (class 2606 OID 221190)
-- Dependencies: 208 171 2567 2811
-- Name: rel_{E8BA05DA-E2A0-4458-9706-DA; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKvvArchiv"
    ADD CONSTRAINT "rel_{E8BA05DA-E2A0-4458-9706-DA" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2590 (class 2606 OID 221205)
-- Dependencies: 207 207 2563 167 167 2811
-- Name: rel_{F7B415C7-B1D1-4C99-B532-C0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKurs"
    ADD CONSTRAINT "rel_{F7B415C7-B1D1-4C99-B532-C0" FOREIGN KEY ("lngSdSeminarID", "strKursRaum") REFERENCES "tblSdRaum"("lngSdSeminarID", "strRaumBezeichnung");


--
-- TOC entry 2642 (class 2606 OID 221210)
-- Dependencies: 208 2567 200 2811
-- Name: rel_{FD4127D7-5829-4399-A210-53; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblSdPruefung"
    ADD CONSTRAINT "rel_{FD4127D7-5829-4399-A210-53" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2592 (class 2606 OID 221215)
-- Dependencies: 2567 168 208 2811
-- Name: seminar_kurstermin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "tblBdKursTermin"
    ADD CONSTRAINT "seminar_kurstermin" FOREIGN KEY ("lngSdSeminarID") REFERENCES "tblSdSeminar"("lngSeminarID");


--
-- TOC entry 2816 (class 0 OID 0)
-- Dependencies: 6
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- TOC entry 2818 (class 0 OID 0)
-- Dependencies: 234
-- Name: plpgsql_call_handler(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION "plpgsql_call_handler"() FROM PUBLIC;
REVOKE ALL ON FUNCTION "plpgsql_call_handler"() FROM "postgres";
GRANT ALL ON FUNCTION "plpgsql_call_handler"() TO PUBLIC;


--
-- TOC entry 2819 (class 0 OID 0)
-- Dependencies: 167
-- Name: tblBdKurs; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE "tblBdKurs" FROM PUBLIC;
REVOKE ALL ON TABLE "tblBdKurs" FROM "postgres";
GRANT ALL ON TABLE "tblBdKurs" TO "postgres";


--
-- TOC entry 2820 (class 0 OID 0)
-- Dependencies: 171
-- Name: tblBdKvvArchiv; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE "tblBdKvvArchiv" FROM PUBLIC;
REVOKE ALL ON TABLE "tblBdKvvArchiv" FROM "postgres";
GRANT ALL ON TABLE "tblBdKvvArchiv" TO "postgres";


--
-- TOC entry 2821 (class 0 OID 0)
-- Dependencies: 176
-- Name: tblBdStudent; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE "tblBdStudent" FROM PUBLIC;
REVOKE ALL ON TABLE "tblBdStudent" FROM "postgres";
GRANT ALL ON TABLE "tblBdStudent" TO "postgres";


--
-- TOC entry 2823 (class 0 OID 0)
-- Dependencies: 184
-- Name: tblBdStudentXLeistung; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE "tblBdStudentXLeistung" FROM PUBLIC;
REVOKE ALL ON TABLE "tblBdStudentXLeistung" FROM "postgres";
GRANT ALL ON TABLE "tblBdStudentXLeistung" TO "postgres";


--
-- TOC entry 2824 (class 0 OID 0)
-- Dependencies: 192
-- Name: tblSdKurstyp; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE "tblSdKurstyp" FROM PUBLIC;
REVOKE ALL ON TABLE "tblSdKurstyp" FROM "postgres";
GRANT ALL ON TABLE "tblSdKurstyp" TO "postgres";


-- Completed on 2016-06-27 20:20:24 CEST

--
-- PostgreSQL database dump complete
--


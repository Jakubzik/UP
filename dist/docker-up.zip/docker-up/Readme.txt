Docker für SignUp:

1) Docker muss installiert sein
2) Docker-Compose muss installiert sein

-> docker-compose up 
   startet UP auf localhost://UP
   
Backup im Prinzip über:
su -c 'pg_dump -p 5431 -h 127.0.0.1 --ignore-version SignUpXP > /home/heiko/development/dockertest/try-dump1.sql' postgres

==================
Automatisieren:
==================
- ./context.xml in WAR nach META-INF kopieren (liegt jetzt unter etc., brauchte: META-INF/context.xml braucht: jdbc:postgresql://up-postgres95:5432/UP_db)

- postgresql-Treiber unter WEB-INF/lib in .WAR kopieren.

==================
Lösen
==================
- Versionsnummern?
- Wo unter GitHUB?

==================
Wesentliche Befehle
==================
docker images 	(Listet die Images)
docker rmi [id] löscht das Image
docker ps -a    (listet die Container)
docker rm  [id] löscht den Container

tabula rasa mit:
docker rm $(docker ps -a -q)
docker rmi $(docker images -q) 

==================
Programmieren:
==================
seminar/fach/get
seminar/dozent/get
seminar/student/get
haben Probleme mit dem Casten von StudentBean zu StudentData!

Bei Login-Fehler liefert die Fehlermeldung 
das eingegebene Passwort im Klartext. Vermutlich 
egal, aber doch eher eine schlechte Idee?

Selbstausdruck der Transkripte tut nicht
Landing Page
Lizenzen (Bootstrap et al.?)



@TODO
- backup testen
- Skripte (backup, pull vom CVS etc.) einbinden
- Forks vom großen SignUp planen und umsetzen

- Image mit Studienführer
- Image mit ePhonetik

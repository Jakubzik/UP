#!/bin/sh
# this assumes webserver is running on port 8080
SERVER=/opt/jakarta/lib


CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/jaxrpc.jar

CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/axis.jar
CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/commons-discovery.jar
CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/commons-logging.jar
CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/saaj.jar
CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/wsdl4j.jar
CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/junit.jar

CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/xercesImpl.jar
CLASSPATH=${CLASSPATH}:/home/heiko/Tomcat/axis/WEB-INF/lib/xmlParserAPIs.jar

CLASSPATH=${CLASSPATH}:/root/bin/jakarta-tomcat-3.2.1/lib/jaxp.jar

echo
CLASSPATH=${CLASSPATH}:/root/bin/jakarta-tomcat-3.2.1/webapps/axis/WEB-INF/classes/

export CLASSPATH

echo "Deploy everything first, using no scope, currently"
java org.apache.axis.client.AdminClient deploy.wsdd $*

# Now undeploy everything
#java org.apache.axis.client.AdminClient undeploy.wsdd $*

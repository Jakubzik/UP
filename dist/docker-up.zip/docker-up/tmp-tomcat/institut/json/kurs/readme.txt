Liefert Kurse nach Volltextsuche (Kurstitel, 
Leistung, Dozent etc.) für Anmeldungen -- sowohl
aus Studierendensicht als auch aus Lehrendensicht.

Wird auch für die mobile Anwendung m2 benutzt.

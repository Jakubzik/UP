Benutzt wird im Moment (März 2016) nur kvv_1.jsp, 
und zwar aus kvv.js

@todo: Prüfen, ob kvv.jsp und kvv_o.jsp irgendwo 
auf der homepage verwendet werden.

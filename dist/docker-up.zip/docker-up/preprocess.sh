$!bin/sh

rm /home/heiko/development/docker-up/etc/tomcat/UP-6-2016.war
cp /home/heiko/workspace-current/UP/dist/UP.war /home/heiko/development/docker-up/etc/tomcat/UP-6-2016.war

# entpacke .war
cd /home/heiko/development/docker-up/
mkdir tmp-tomcat
cd /home/heiko/development/docker-up/tmp-tomcat

jar -xf /home/heiko/development/docker-up/etc/tomcat/UP-6-2016.war

cp /home/heiko/workspace-current/UP/web/institut/js/jszip-utils-ie.js /home/heiko/development/docker-up/tmp-tomcat/institut/js/
cp /home/heiko/workspace-current/UP/web/institut/js/jszip-utils.js /home/heiko/development/docker-up/tmp-tomcat/institut/js/
rm /home/heiko/development/docker-up/tmp-tomcat/META-INF/context.xml
cp /home/heiko/development/docker-up/etc/tomcat/context.xml /home/heiko/development/docker-up/tmp-tomcat/META-INF/

cd tmp-tomcat
jar cvf UP-6-2016.war *
rm /home/heiko/development/docker-up/etc/tomcat/UP-6-2016.war
cp UP-6-2016.war /home/heiko/development/docker-up/etc/tomcat/
cd ..
rmdir  tmp-tomcat
exit 0

# jar -cf c:\path\to\mynewwar.war .
